//app.js
const location = require("/utils/location.js");

App({
  onLaunch: function() {
    // 展示本地存储能力
    var logs = wx.getStorageSync('logs') || []
    logs.unshift(Date.now())
    wx.setStorageSync('logs', logs)

    // 登录
    wx.login({
      success: res => {
        // 发送 res.code 到后台换取 openId, sessionKey, unionId
      }
    })
    // 获取用户信息
    wx.getSetting({
      success: res => {
        if (res.authSetting['scope.userInfo']) {
          // 已经授权，可以直接调用 getUserInfo 获取头像昵称，不会弹框
          wx.getUserInfo({
            success: res => {
              // 可以将 res 发送给后台解码出 unionId
              this.globalData.userInfo = res.userInfo

              // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
              // 所以此处加入 callback 以防止这种情况
              if (this.userInfoReadyCallback) {
                this.userInfoReadyCallback(res)
              }
            }
          })
        }
      }
    })
    wx.getRequest = ({
      url,
      success
    }) => {
      wx.request({
        url: serviceApi + url,
        method: 'GET',
        header: {
          'content-type': 'application/json', // 默认值
          "channel": "wx"
        },
        success(res) {
          success(res.data.data)
        }
      })
    }
    wx.getNetworkType({
      success(res) {
        let networkType = res.networkType;
        if (networkType != "none") {
          let timer = setInterval(function () {
            let token = wx.getStorageSync("token");
            if (!token) {
              return false;
            }
            wx.getLocation({
              type: 'wgs84', //gps坐标
              isHighAccuracy: true,
              success(res) {
                let latitude = res.latitude;
                let speed = res.speed;
                let accuracy = res.accuracy;
                // let gcj02tobd09 = location.wgs84togcj02(res.longitude, res.latitude);

                let params = {
                  
                  longitude: res.longitude,
                  latitude: res.latitude,
                  deviceId: 'weChat',
                  channel: 3
                }
                wx.request({
                  url: getApp().config.baseApi + '/admin/user/location/v1/report',
                  header: {
                    "content-type": "application/json;charset=UTF-8",
                    "authentication": token,
                    "channel": "wx"
                  },
                  data: params,
                  method: 'POST',
                  success: function (res) {
                    if (res.code == 2010) {
                      wx.removeStorageSync("token")
                      wx.removeStorageSync("userInfo")
                      wx.reLaunch({
                        url: '/pages/auth/index',
                      })
                    }
                  },
                  fail: function (req) { },
                })
              }
            })
          }, 60000)
        }
      }
    })
  },
  globalData: {
    userInfo: null
  },
  config: {
    baseApi:'https://service.dva.gd.gov.cn/zfww/api'
    // baseApi: 'https://zyt.shuanghuaai.com/zfww-api'
    // baseApi: 'https://zyt.shuanghuaai.com/zfww'
    // baseApi: 'http://172.16.1.201:8886'
    // baseApi: 'http://172.16.1.84:8886'
    // baseApi: 'http://172.16.1.32:8886'
    // baseApi: 'https://service.dva.gd.gov.cn/zfww/test/api'
    // baseApi: 'https://zyt.shuanghuaai.com/zfww-demo'
    // baseApi: 'https://service.dva.gd.gov.cn/zfww/zfww/test/api/v2'
  }
})