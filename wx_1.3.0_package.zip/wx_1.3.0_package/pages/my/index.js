//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
    userInfo: {},
    interviews: {}
  },
  //事件处理函数
  bindViewTap: function() {
    wx.navigateTo({
      url: '../logs/logs'
    })
  },
  onLoad: function () {
    this.data.userInfo = wx.getStorageSync("userInfo")
    this.setData({
      userInfo: this.data.userInfo
    });

    let interviews = wx.getStorageSync("interviews")
    this.setData({
      interviews: interviews
    })
  },
  logout: function (e) {
    wx.removeStorageSync("token")
    wx.removeStorageSync("userInfo")

    wx.reLaunch({
      url: '/pages/auth/index',
    })
  }
})
