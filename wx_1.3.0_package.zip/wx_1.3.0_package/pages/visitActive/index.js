// pages/visitActive/index.js
const call = require("../../utils/request.js");
const callTime = require("../../utils/util.js");
let app = getApp();
import Toast from '../../vant-weapp/toast/toast';
Page({

  /**
   * 页面的初始数据
   */
  data: {
    isCreator:false,
    content: '', // 活动记录内容
    images: [], // 活动记录图片数组
    videos: [], // 活动记录视频数组
    showImgs: [], // 图片预览时需要的数组
    reportId: '', // 走访活动报告的id
    fileGuid: '',// 唯一ID
    cardId: '' // 身份证ID
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    wx.showLoading();
    let that = this;
    this.setData({
      reportId: e.reportId.trim() || '',
      fileGuid: e.fileGuid.trim() || '',
      cardId: e.cardId.trim() || ''
    })
    this.getData();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
   
  },
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  getData: function () {
    let that = this;
    call.getData('/interview/report/detail?id=' + this.data.reportId, function (res) {
      if (that.data) {
        wx.hideLoading();
      }
      that.data.content = res.data.content || ''; // 活动记录内容
      that.data.images = res.data.images || []; // 活动记录图片
      that.data.videos = res.data.videos || []; // 活动记录视频
      that.data.id = res.data.id || []; // 活动记录视频
      that.data.isCreator = res.data.isCreator || false; // 

      let imgArr = res.data.images || [];
      imgArr.map(function (item) {
        that.data.showImgs.push(item.url)
      })

      that.setData({
        content: that.data.content,
        images: that.data.images,
        videos: that.data.videos,
        id: that.data.id,
        isCreator: that.data.isCreator
      })
    }, function (req) { })
  },
  ImagePreviewShow: function (e) {
    let that = this;
    wx.previewImage({
      current: e.currentTarget.dataset.src, // 当前显示图片的http链接  
      urls: that.data.showImgs // 需要预览的图片http链接列表  
    })
  },
  contentChange: function (e) { // 输入框监听事件
    this.setData({
      content: e.detail.value || ''
    })
  },
  formSubmit: function (e) { // 保存走访活动记录内容
    let that = this;
    setTimeout(function () {
      let params = { id: e.currentTarget.dataset.id || '', content: e.currentTarget.dataset.value || '' }
      call.postData('/miniprogram/interview/report/update', params, function (res) {
        Toast({
          message: '保存成功',
          selector: '#van-toast',
          context: that
        });
      }, function (req) { })
    }, 600);
  }
 
})