// pages/statisticAnalysis/index.js
const call = require("../../utils/request.js");
const callTime = require("../../utils/util.js");
let app = getApp();
import Toast from '../../vant-weapp/toast/toast';
Page({

  /**
   * 页面的初始数据
   */
  data: {
    regionCode:'',
    list:[],
    codeList:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    const that = this;
    let userInfo = wx.getStorageSync("userInfo");
    let data = {
      regionCode:userInfo.regionCode
    }
    that.setData({
      codeList: [data]
    })
    this.getData(data)
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },
  getData(data) { // 获取列表数据
    let that = this;
    call.getData('/admin/user/location/list?regionCode='+ data.regionCode, function(res) {
      if( res.code == 200 ) {
        that.setData({
          list :res.data
        })
      }else{
        Toast(res.msg);
      }
      
    }, function(req) {})
  },
  getDataDetail(e) {
    let data = {
      regionCode:e.currentTarget.dataset.code
    }
    if( data.regionCode == this.data.codeList[this.data.codeList.length - 1].regionCode ) {
      return
    }
    this.setData({
      codeList:[...this.data.codeList,data]
    })
    this.getData(data)
  },
  goBack: function(){
    const that = this;
    let codeArr = this.data.codeList;
    if( codeArr.length > 1 ) {
      let data = codeArr.pop();
      that.data.codeList = codeArr
      if( data && data.regionCode  ) {
        this.getData(codeArr[codeArr.length-1])
      }
    }else{
      
    }

  },
  refresh: function() {
    let codeArr = this.data.codeList;
    this.getData(codeArr[codeArr.length-1])
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})