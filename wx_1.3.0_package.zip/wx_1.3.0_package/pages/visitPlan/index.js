// components/interviewList/index.js
const call = require("../../utils/request.js");
const callTime = require("../../utils/util.js");
let app = getApp();
import Toast from '../../vant-weapp/toast/toast';

Page({
  data: {
    calendarConfig: {
      theme: 'elegant', // 主题
      defaultDay: true, // 初始化选中当前日期
      highlightToday: true,
    },
    marker: [], // 当前月需要被标注的日期
    selectMonth: {}, // 当前区域内显示的年月
    interviewListInfo: [], // 走访计划列表数据
    hasMore: true,
    params: {
      startTime: '',
      endTime: '',
      pageable: {
        rows: 15,
        page: 1
      }
    },
    enrolStartTime: '',
    enrolEndTime: ''
  },
  //事件处理函数
  bindViewTap: function() {

  },
  onLoad: function() {
    let nowDate = this.getNowDateFn(); // 当前年月日
    this.setData({ // 请求数据之前先定义好当月的开始和结束时间
      selectMonth: {
        year: nowDate[0],
        month: nowDate[1]
      }
    })
  },
  onReady: function() {
    // wx.showLoading(); // 显示loading
    let formStartTime = "params.startTime";
    let formEndTime = "params.endTime";
    let nowDate = this.getNowDateFn(); // 当前年月日
    // let nowMonthDay = this.getCurrentMonthDayNum(); // 当前月所包含的天数
    let nowDay = nowDate[0] + '-' + nowDate[1] + '-' + nowDate[2] + ' ';
    this.setData({ // 请求数据之前先定义好当月的开始和结束时间
      [formStartTime]: nowDay + '00:00:00',
      [formEndTime]: nowDay + '23:59:59'
    })
    this.getData(); // 首次加载数据
  },
  /**
   * 加载数据
   */
  loadData: function() {

  },
  getUserInfo: function(e) {

  },
  getData() { // 获取列表数据
    let that = this;
    if (!that.data.hasMore) {
      return
    }
    call.postData('/interview/list', that.data.params, function(res) {
      if (res.code == 200) {
        if (that.data.params.pageable.page == 1) {
          wx.hideLoading();
          if (res.data && res.data.total <= that.data.params.pageable.rows) {
            that.setData({
              hasMore: false
            })
          }
        } else {
          if (res.data && that.data.params.pageable.page >= res.data.totalPages) {
            that.data.hasMore = false;
          }
        }
        that.data.params.pageable.page++;
        that.data.interviewListInfo = that.data.interviewListInfo.concat(res.data.content || []);
        that.setData({
          interviewListInfo: that.data.interviewListInfo,
          hasMore: that.data.hasMore
        })
      } else {
        Toast(res.msg);
      }

    }, function(req) {})
  },
  afterCalendarRender(e) { // 日历初次渲染完成后触发事件，如设置事件标记
    this.showMarkerDot();
  },
  whenChangeMonth: function(e) { // 点击切换月份的事件
    let that = this;
    let formStartTime = "params.startTime";
    let formEndTime = "params.endTime";
    let nowDate = e.detail.next || {}; // 当前年月日
    let nowMonthDay = that.mGetDate(nowDate.year, nowDate.month); // 返回所选择的月份的天数
    that.setData({ // 请求数据之前先定义好当月的开始和结束时间
      selectMonth: {
        year: nowDate.year,
        month: nowDate.month
      },
      [formStartTime]: nowDate.year + '-' + nowDate.month + '-' + '01' + ' ' + '00:00:00',
      [formEndTime]: nowDate.year + '-' + nowDate.month + '-' + nowMonthDay + ' ' + '23:59:59'
    })
    that.data.params.pageable.page = 1; // 每次切换日期的时候将页码重置归1
    that.data.interviewListInfo = []; // 切换之后清空数据列表
    that.data.hasMore = true;
    that.showMarkerDot(); // 回显标记圆点
    // that.getData(); // 切换月份 更新数据
  },
  afterTapDay: function(currentSelect) { // 日历的日期点击事件
    let year = currentSelect.detail.year || ''; // 年
    let month = currentSelect.detail.month || ''; // 月
    let day = currentSelect.detail.day || ''; // 日
    let clickDay = year + '-' + month + '-' + day;
    this.data.params.startTime = clickDay + ' ' + '00:00:00'; // 查询的开始时间
    this.data.params.endTime = clickDay + ' ' + '23:59:59'; // 查询的结束时间
    this.data.params.pageable.page = 1; // 每次点击日期的时候将页码重置归1
    this.data.hasMore = true;
    this.data.interviewListInfo = []; // 点击之后清空数据列表
    this.showLoadingMore(); // 显示加载图标
    this.getData(); // 重新渲染列表数据
  },
  showLoadingMore: function() {
    this.setData({
      hasMore: this.data.hasMore
    })
  },
  hideLoadingMore: function() {
    this.setData({
      hasMore: this.data.hasMore
    })
  },
  onReachBottom: function() {
    // 触底时父页面调用
    var that = this;
    // 显示加载图标
    this.showLoadingMore();
    this.getData();
  },
  checkDetails(e) {
    // 判断是否是创建者，创建者有权限修改活动情况
    let isCreator = e.currentTarget.dataset.iscreator ? '1' : '0';
    wx.navigateTo({
      url: '/pages/visitPlanDetail/index?id=' + e.currentTarget.dataset.id + '&isCreator=' + isCreator
    })
  },
  showMarkerDot: function() { // 渲染页面回显日历上的日期数据标记点
    let that = this;
    // 根据接口获取当前日历上有计划的日期进行圆点标注
    let times = that.data.selectMonth;
    let nowMonthDay = that.mGetDate(times.year, times.month); // 返回所选择的月份的天数
    let datas = {
      startTime: times.year + '-' + times.month + '-' + '01' + ' ' + '00:00:00',
      endTime: times.year + '-' + times.month + '-' + nowMonthDay + ' ' + '23:59:59'
    }
    call.postData('/interview/count', datas, function(res) {
      if (res.code != 200) {
        Toast(res.msg);
        return false;
      }; 
      if (!res.data) return;
      let data = res.data;
      let marker = [];
      data.map(function(item, index) {
        if (item) {
          let timeLis = {};
          timeLis.year = times.year;
          timeLis.month = times.month;
          timeLis.day = (index + 1);
          marker.push(timeLis)
        }
      })
      that.calendar.setTodoLabels({ // 待办点标记设置
        pos: 'bottom', // 待办点标记位置 ['top', 'bottom']
        dotColor: '#EE7621', // 待办点标记颜色
        dot: true, // 待办标记设置样式
        showLabelAlways: true, // 点击时是否显示待办事项圆点
        days: marker
      });
    }, function(req) {})
  },
  getCurrentMonthDayNum: function() { // 计算当前月有多少天
    let today = new Date();
    let dayAllThisMonth = 31;
    if (today.getMonth() + 1 != 12) {
      let currentMonthStartDate = new Date(today.getFullYear() + "/" + (today.getMonth() + 1) + "/01"); // 本月1号的日期
      let nextMonthStartDate = new Date(today.getFullYear() + "/" + (today.getMonth() + 2) + "/01"); // 下个月1号的日期
      dayAllThisMonth = (nextMonthStartDate - currentMonthStartDate) / (24 * 3600 * 1000);
    }
    return dayAllThisMonth;
  },
  mGetDate: function(year, month) { // 传入年和月  获取天数
    var d = new Date(year, month, 0);
    return d.getDate();
  },
  getNowDateFn: function() { // 获取当前年月日
    let timestamp = Date.parse(new Date());
    let date = new Date(timestamp);
    //获取年份  
    let Y = date.getFullYear();
    //获取月份  
    let M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1);
    //获取当日日期 
    let D = date.getDate() < 10 ? '0' + date.getDate() : date.getDate();
    return [Y + '', M + '', D + ''];
  },
})