//index.js
//获取应用实例
const app = getApp();
Page({
  data: {
    interviewBar: 0,
    slidingListShow: false,
    slidingInOffShow: false,
    slidingDownShow: false,
    slidingsSixShow:false
  },
  // 切换不同的tab
  onChange(event) {
    this.setData({
      interviewBar: event.detail.index
    });
    if (this.data.interviewBar == 0 && !this.data.slidingListShow) {
      // 人员列表 触底加载更多
      this.selectComponent('#interviewList').getData();
      this.setData({
        slidingListShow: true
      });
    } else if (this.data.interviewBar == 1 && !this.data.slidingInOffShow) {
      //  * 在办 触底加载更多
      this.selectComponent('#interviewInOffice').getData();
      this.setData({
        slidingInOffShow: true
      });
    } else if (this.data.interviewBar == 2 && !this.data.slidingDownShow) {
      // 在办 触底加载更多
      this.selectComponent('#interviewHaveDone').getData();
      this.setData({
        slidingDownShow: true
      });
    }
  },
  //事件处理函数
  bindViewTap: function() {

  },
  onLoad: function(e) {
    this.setData({
      interviewBar: e.tabs || 0
    });
    if (this.data.interviewBar == 0) {
      // 人员列表 触底加载更多
      wx.showLoading();
      this.selectComponent('#interviewList').getData();
      this.setData({
        slidingListShow: true
      });
    } else if (this.data.interviewBar == 1) {
      //  * 在办 触底加载更多
      this.selectComponent('#interviewInOffice').getData();
      this.setData({
        slidingInOffShow: true
      });
    } else if (this.data.interviewBar == 2) {
      // 在办 触底加载更多
      this.selectComponent('#interviewHaveDone').getData();
      this.setData({
        slidingDownShow: true
      });
    }
  },
	shows: function(){
		this.selectComponent('#interviewList').getData();
		// this.selectComponent('#interviewSixVisit').getData();
		this.selectComponent('#interviewInOffice').getData();
		this.selectComponent('#interviewHaveDone').getData();
	},
  onReady: function() {
    //  页面初次渲染完成后，使用选择器选择组件实例节点，返回匹配到组件实例对象  
    this.interviewList = this.selectComponent('#interviewList');
    // this.interviewSixVisit = this.selectComponent('#interviewSixVisit');
    this.interviewInOffice = this.selectComponent('#interviewInOffice');
    this.interviewHaveDone = this.selectComponent('#interviewHaveDone');
    // 首次加载数据

  },
  /**
   * 加载数据
   */
  loadData: function() {

  },
  getUserInfo: function(e) {

  },
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {
    if (this.data.interviewBar == 0) {
      // 人员列表 触底加载更多
      this.selectComponent('#interviewList').onContactButton();
    }else if (this.data.interviewBar == 1) {
      //  * 在办 触底加载更多
      this.selectComponent('#interviewInOffice').onContactButton();
    } else if (this.data.interviewBar == 2) {
      // 在办 触底加载更多
      this.selectComponent('#interviewHaveDone').onContactButton();
    }
  },
  /**
   * 页面滑动处理函数
   */
  onPageScroll: function (ev) {
    // let that = this;
    // if (that.data.interviewBar == 0) {
      // 人员列表 滑动
    //   if (ev.scrollTop <= 50 && !that.data.slidingListShow) {
    //     that.setData({
    //       slidingListShow: true
    //     })
    //   } else {
    //     that.setData({
    //       slidingListShow: false
    //     })
    //   }

    // } else if (that.data.interviewBar == 1) {
      //  * 六必访 滑动
      // if (ev.scrollTop <= 50 && !that.data.slidingListShow) {
      //   that.setData({
      //     slidingListShow: true
      //   })
      // } else {
      //   that.setData({
      //     slidingListShow: false
      //   })
      // }

    // } else if (that.data.interviewBar == 2) {
    //   //  * 在办 滑动
    //   if (ev.scrollTop <= 50 && !that.data.slidingInOffShow) {
    //     that.setData({
    //       slidingInOffShow: true
    //     })
    //   } else {
    //     that.setData({
    //       slidingInOffShow: false
    //     })
    //   }
    // } else if (that.data.interviewBar == 3) {
    //   // 已办 滑动
    //   if (ev.scrollTop <= 50 && !that.data.slidingDownShow) {
    //     that.setData({
    //       slidingDownShow: true
    //     })
    //   } else {
    //     that.setData({
    //       slidingDownShow: false
    //     })
    //   }

    // }

  },
})