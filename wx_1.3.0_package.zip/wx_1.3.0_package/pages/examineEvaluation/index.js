// pages/examineEvaluation/index.js
//index.js
//获取应用实例
const app = getApp();
Page({
  data: {
    interviewBar: 0,
    slidingListShow: false,
    slidingInOffShow: false,
    slidingDownShow: false,
    slidingsSixShow:false
  },
  // 切换不同的tab
  onChange(event) {
    this.setData({
      interviewBar: event.detail.index
    });
    if (this.data.interviewBar == 0 && !this.data.slidingListShow) {
      // 人员列表 触底加载更多
      this.selectComponent('#evaluationNorm').getData();
      this.setData({
        slidingListShow: true
      });
    } else if (this.data.interviewBar == 1 && !this.data.slidingInOffShow) {
      //  * 在办 触底加载更多
      this.selectComponent('#evaluationAnalyze').getData();
      this.setData({
        slidingInOffShow: true
      });
    } else if (this.data.interviewBar == 2 && !this.data.slidingDownShow) {
      // 在办 触底加载更多
      this.selectComponent('#evaluationResult').getData();
      this.setData({
        slidingDownShow: true
      });
    }
  },
  //事件处理函数
  bindViewTap: function() {

  },
  onLoad: function(e) {
    this.setData({
      interviewBar: e.tabs || 0
    });
    if (this.data.interviewBar == 0) {
      // 人员列表 触底加载更多
      wx.showLoading();
      this.selectComponent('#evaluationNorm').getData();
      this.setData({
        slidingListShow: true
      });
    } else if (this.data.interviewBar == 1) {
      //  * 在办 触底加载更多
      this.selectComponent('#evaluationAnalyze').getData();
      this.setData({
        slidingInOffShow: true
      });
    } else if (this.data.interviewBar == 2) {
      // 在办 触底加载更多
      this.selectComponent('#evaluationResult').getData();
      this.setData({
        slidingDownShow: true
      });
    }
  },
	shows: function(){
		this.selectComponent('#evaluationNorm').getData();
		this.selectComponent('#evaluationAnalyze').getData();
		this.selectComponent('#evaluationResult').getData();
	},
  onReady: function() {
    //  页面初次渲染完成后，使用选择器选择组件实例节点，返回匹配到组件实例对象  
    this.evaluationNorm = this.selectComponent('#evaluationNorm');
    this.interviewInOffice = this.selectComponent('#evaluationAnalyze');
    this.evaluationResult = this.selectComponent('#evaluationResult');
    // 首次加载数据

  },
  /**
   * 加载数据
   */
  loadData: function() {

  },
  getUserInfo: function(e) {

  },
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {
    if (this.data.interviewBar == 0) {
      // 人员列表 触底加载更多
      this.selectComponent('#evaluationNorm').onContactButton();
    }else if (this.data.interviewBar == 1) {
      //  * 在办 触底加载更多
      this.selectComponent('#evaluationAnalyze').onContactButton();
    } else if (this.data.interviewBar == 2) {
      // 在办 触底加载更多
      this.selectComponent('#evaluationResult').onContactButton();
    }
  },
  /**
   * 页面滑动处理函数
   */
  onPageScroll: function (ev) {

  },
})