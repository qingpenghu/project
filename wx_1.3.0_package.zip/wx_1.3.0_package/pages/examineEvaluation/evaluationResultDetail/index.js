// pages/examineEvaluation/evaluationResultDetail/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    baseInfoVO: {}
  },
  onLoad: function (e) {
    const that = this;
    wx.getStorage({
      key: 'evaluationResultDetail',
      success (res) {
        res.data.examineType = (res.data.examineType == '1' || res.data.examineType == '0') ? (res.data.examineType == '1' ? '年度考核':'月度考核') :''
        that.setData({
          baseInfoVO:res.data
        })
      }
    })
  }
})