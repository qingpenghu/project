// 考核指标详情
const call = require("../../../utils/request.js");
const callData = require("../../../utils/util.js");
let app = getApp();
import Toast from '../../../vant-weapp/toast/toast';

Page({
  /**
   * 组件的初始数据
   */
  data: {
    id:'',
    baseInfoVO: {}
  },
  onLoad: function (e) {
    const that = this;
    wx.getStorage({
      key: 'evaluationAnalyzeDetail',
      success (res) {
        res.data.examineType = (res.data.examineType == '1' || res.data.examineType == '0') ? (res.data.examineType == '1' ? '年度考核':'月度考核') :''
        that.setData({
          baseInfoVO:res.data
        })
      }
    })
  },
  
  

})