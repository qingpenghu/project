//index.js
//获取应用实例

const call = require("../../utils/request.js");
const callData = require("../../utils/util.js");
const md5 = require("../../utils/md5.js");
const app = getApp()

import Toast from '../../vant-weapp/toast/toast';

Page({
  data: {
    isLogin: true,
    showCode: false, // 是否展示验证码
    formData: {
      username: "",
      password: ""
    }
  },
  onReady: function () {
    let that = this
    wx.showLoading()
    let token = wx.getStorageSync("token")
    if (token) {
      wx.hideLoading()
      wx.reLaunch({
        url: '/pages/index/index',
      })
    } else {
      wx.hideLoading()
      this.setData({
        isLogin: false
      });
    }
  },
  onLoad: function () {
  },
  onUsernameChange: function (ev) {
    let key = "formData.username"
    this.setData({
      [key]: ev.detail
    });
  },
  onPasswordChange: function (ev) {
    let key = "formData.password"
    this.setData({
      [key]: ev.detail
    });
  },
  onUsernameBlur: function (ev) {
    let key = "formData.username"
    this.setData({
      [key]: ev.detail.value
    });
  },
  onPasswordBlur: function (ev) {
    let key = "formData.password"
    this.setData({
      [key]: ev.detail.value
    });
  },
  onCodeChange: function (ev) {
    let key = "formData.imageCode"
    this.setData({
      [key]: ev.detail
    });
  },
  onCodeBlur: function (ev) {
    let key = "formData.imageCode"
    this.setData({
      [key]: ev.detail.value
    });
  },
  loadToken: function () {
    let that = this;
    call.getData('/checkcode/token', function (res) {
      let key = "formData.token"
      that.setData({
        [key]: res.token
      });
      that.loadImageCode(res.token);
    })
  },
  loadImageCode: function (token) {
    let imgUrl = app.config.baseApi + "/checkcode/image?token=" + token
    this.setData({
      showCode: imgUrl
    })
  },
  onChangeCodeImg: function() {
    this.loadToken()
  },
  login: function () {
    let that = this;
    // let md5_password = md5.hexMD5(this.data.formData.password);
    let params = {
      userName: this.data.formData.username,
      // password: md5_password,
      password: this.data.formData.password,
      token: this.data.formData.token,
      imageCode: this.data.formData.imageCode
    }
    if (!this.data.formData.username
      || !this.data.formData.password) {
      Toast("请输入账号或密码")
      return
    }
    call.postData('/login/myself', params, function (res) { //  请求成功
      if (res.code == 200) {
        if (res.data.status != 0) {
          wx.setStorage({
            key: 'token',
            data: res.data.token
          })
          wx.setStorage({
            key: 'userInfo',
            data: res.data,
          })
          wx.reLaunch({
            url: '/pages/index/index',
          })
        } else {
          wx.reLaunch({
            url: '/pages/active/index',
          })
        }
      } else if (res.code == 2016) {
        that.loadToken();
      } else {
        Toast(res.msg)
      }
    },function(req){
      Toast(req.msg)
    })
  },
  loginAll: function () { // 综合管理平台登录
    let that = this;
    // let md5_password = md5.hexMD5(this.data.formData.password);
    let params = {
      userName: this.data.formData.username,
      // password: md5_password,
      password: this.data.formData.password,
      token: this.data.formData.token,
      imageCode: this.data.formData.imageCode
    }
    if (!this.data.formData.username
      || !this.data.formData.password) {
      Toast("请输入账号或密码")
      return
    }
    call.postData('/login/username', params, function (res) { //  请求成功
      if (res.code == 200) {
        if (res.data.status != 0) {
          wx.setStorage({
            key: 'token',
            data: res.data.token
          })
          wx.setStorage({
            key: 'userInfo',
            data: res.data,
          })
          wx.reLaunch({
            url: '/pages/index/index',
          })
        } else {
          wx.reLaunch({
            url: '/pages/active/index',
          })
        }
      } else if (res.code == 2016) {
        that.loadToken();
      } else {
        Toast(res.msg)
      }
    },function(req){
      Toast(req.msg)
    })
  }
})
