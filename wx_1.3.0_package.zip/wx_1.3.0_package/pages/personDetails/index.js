const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    detailsBar:0,
    detailsId:'',
    detailCard:'',
    veteransId:'',
    name:'',
  },
  // 切换不同的tab
  onChange(event) {
    this.setData({
      detailsBar: event.detail.index
    })
    if( event.detail.index == 3  ) {
      if(  this.appealOrderInfo ) {
        this.appealOrderInfo.getNewData()
      }
    }
    if( event.detail.index == 2  ) {
      if(  this.petitionInfo ) {
        this.petitionInfo.getData()
      }
      
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    // 获取url中file_guid的值
    this.setData({
      detailsId:e.id,
      detailCard:e.cardId,
      veteransId: e.veteransId || '',
      detailsBar: e.tabs || 0,
      name: e.name,
    })
  },
	shows: function(){
    this.selectComponent('#visitInfo').getNewData();
    this.selectComponent('#meritoriousInfo').loadDataUpdate() // 立功喜报
	},
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    //  页面初次渲染完成后，使用选择器选择组件实例节点，返回匹配到组件实例对象  
    this.basicInfo = this.selectComponent('#basicInfo');
    this.visitInfo = this.selectComponent('#visitInfo');
    this.activeInfo = this.selectComponent('#activeInfo');
    // this.appealOrderInfo = this.selectComponent('#appealOrderInfo') // 个人信息中的诉求工单
    this.petitionInfo = this.selectComponent('#petitionInfo')
    this.meritoriousInfo = this.selectComponent('#meritoriousInfo') // 立功喜报 获取实例
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    if (this.data.detailsBar == 1) {
      // 走访记录 触底加载更多
      this.selectComponent('#visitInfo').onContactButton();
    } else if (this.data.detailsBar == 2) {
      //  * 活动记录 触底加载更多
      this.selectComponent('#activeInfo').onContactButton();
    }
  },

})