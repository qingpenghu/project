// pages/policies/child/detail/index.js
var WxParse = require('../../../../libs/wxParse/wxParse.js');
const call = require("../../../../utils/request.js");
const callData = require("../../../../utils/util.js");
const app = getApp()
import Toast from '../../../../vant-weapp/toast/toast';


Page({

  /**
   * 页面的初始数据
   */
  data: {
    id: ""
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.data.id = options.id
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    this.loadData()
  },
  loadData() {
    var that = this;
    call.getData('/policy/info?id=' + this.data.id, function (res) { //  请求成功
      if( res.code != 200){
        Toast(res.msg);
        return false;
      }

      var article = res.data.content;
      /**
      * WxParse.wxParse(bindName , type, data, target,imagePadding)
      * 1.bindName绑定的数据名(必填)
      * 2.type可以为html或者md(必填)
      * 3.data为传入的具体数据(必填)
      * 4.target为Page对象,一般为this(必填)
      * 5.imagePadding为当图片自适应是左右的单一padding(默认为0,可选)
      */
      WxParse.wxParse('article', 'html', article, that, 5);
    })
  }
})