//index.js 工作总结
//获取应用实例
const call = require("../../../utils/request.js");
const callData = require("../../../utils/util.js");
const app = getApp()
import Toast from '../../../vant-weapp/toast/toast';



Page({
  data: {
    params: {
      title: "",
      pageable: {
        page: 1,
        rows: 15
      },
      num:1,
      size:15,
      shareStatus:'1'
    },
    hasMore: true,
    lists: [
    ],
  },
  //事件处理函数
  bindViewTap: function() {
    wx.navigateTo({
      url: '../logs/logs'
    })
  },
  onLoad: function () {
  },
  onReady: function() {
    // 首次加载数据
    this.loadData();
  },
  showLoadingMore: function() {
    this.setData({
      hasMore: this.data.hasMore
    })
  },
  hideLoadingMore: function () {
    this.setData({
      hasMore: this.data.hasMore
    })
  },
  onChangeTitle(event) {
    this.data.params.title = event.detail.value
    this.setData({
      title: event.detail.value
    });
  },
  primary: function () {
    this.data.hasMore = true
    this.data.params.pageable.page = 1
    this.loadData();
  },
  loadDataUpdate() {
    this.data.hasMore = true
    this.data.params.pageable.page = 1
    this.data.params.title = ''
    this.loadData();
  },
  /**
   * 加载数据
   */
  loadData: function(data) {
    var that = this
    if (!that.data.hasMore) {
      return
    }
    this.data.params.num = this.data.params.pageable.page
    call.postData('/admin/report/shareList', this.data.params, function (res) { //  请求成功
      if (res.code == 200) {
        if (that.data.params.pageable.page == 1) {
          that.data.lists = []
        }
        if (res.data.page < res.data.totalPages) {
          that.data.params.pageable.page++
        }
        that.data.hasMore = res.data.page < res.data.totalPages
        if (res.data.content && res.data.content.length > 0) {
          that.data.lists = that.data.lists.concat(res.data.content)
        }
        that.setData({
          lists: that.data.lists,
          hasMore: that.data.hasMore
        })
      } else {
        Toast(res.msg);
      }
    })
  },
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom () {
    var that = this;
    
    // 显示加载图标
    this.showLoadingMore()
    this.loadData()
  },
  jumpDetail(e) {
    let id = e.currentTarget.dataset.id
    if( id ) {
      wx.navigateTo({
        url: '/pages/workSummary/shareInterFlowDetail/index?type=detail&source=share&id='+id,
      })
    }else{
      Toast("参数缺失");
    }
  }
})
