// 考核指标详情
const call = require("../../../utils/request.js");
const callData = require("../../../utils/util.js");
let app = getApp();
import Toast from '../../../vant-weapp/toast/toast';

Page({
  /**
   * 组件的初始数据
   */
  data: {
    id:'',
    baseInfoVO: {
      examineName: '',
      examineType:'',
      startDate:  '',
      endDate:  '',
      date:'',
      visitNumber:  '',
      gloryCardNumber: '',
      returnHomeNum: '',
      targetName:'',
      statusName:''
    }
  },
  onLoad: function (e) {
    wx.showLoading();
    let that = this;
    this.setData({
      id:e.id ? e.id : '',
    })
    this.getData();
  },
    getData() {
      let that = this;
      call.getData('/admin/examine/detail?id='+that.data.id, function(res) { //  请求成功
        if (res.code == 200) {
          wx.hideLoading();
          if (res.data) {
            that.setData({
              baseInfoVO: {
                examineName: res.data.examineName || '',
                examineType:(res.data.examineType == '1' || res.data.examineType == '0') ? (res.data.examineType == '1' ? '月度考核':'年度考核') : '' ,
                startDate: res.data.startDate || '',
                endDate: res.data.endDate || '',
                date:res.data.startDate +  "至" + res.data.endDate ,
                visitNumber: res.data.visitNumber || '',
                gloryCardNumber: res.data.gloryCardNumber || '',
                returnHomeNum:res.data.returnHomeNum || '',
                targetName: res.data.target === 1 ? '下级服务站' : res.data.target === 0 ? '本级服务站' :'',
                statusName: res.data.status === 1 ? '已发布' : res.data.status === 0 ? '未发布' :'',
                targetStationName: res.data.targetStationName || ''
              }
            })
          }
        } else {
          Toast(res.msg)
        }

      }, function(req) {}) //  请求失败
    }
  

})