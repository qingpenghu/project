// 新增工作总结
const call = require("../../../utils/request.js");
const callTime = require("../../../utils/util.js");
let app = getApp();
import Toast from '../../../vant-weapp/toast/toast';
Page({

  /**
   * 页面的初始数据
   */
  data: {
    id:'',
    content: '', // 活动记录内容
    images: [], // 活动记录图片数组
    videos: [], // 活动记录视频数组
    showImgs: [], // 图片预览时需要的数组
    active: '1', // 工作总结类型
    title:'', // 标题
    isDetail:false,
    headTitle:'新增工作总结',
    hasImage: true,
    radio: '',
    show:false,
    addShow:1,
    objectResultDetail:[],// 已选对象详细信息集合
    objectResult: [], // 已选对象id集合
    activeList: [],
    activeResultDetail:[],
    activeResult: [],
    toView: 'green',
    source:false,
    selectObjectList:["22","333"],
    isCreator:'1'
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    wx.showLoading();
    let that = this;
    this.setData({
      isDetail: e.type == 'detail' ? true:false,
      headTitle: e.type == 'detail' ? '工作总结详情': '新增工作总结',
      id:e.id ? e.id : '',
      source: e.source == 'share' ? true : false
    })
    if( e.type == 'detail'  ) {
      this.getData();
    }else{
      wx.hideLoading();
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
     // if( this.selectComponent('#activeListView') ) {
      this.activeListView = this.selectComponent('#activeListView'); //获取活动列表子组件实例
      this.activePeopleListView = this.selectComponent('#activePeopleListView');//获取对象子组件实例

  },
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  getData: function () {
    let that = this;
    call.getData('/admin/report/detailById?id=' + this.data.id, function (res) {
      if (res && res.code == 200) {
        wx.hideLoading();
        let imgArr = res.data.imageMap || [];
        imgArr.map(function (item) {
          that.data.showImgs.push(item.url)
        })
        let videosArr = res.data.videos || []
        that.data.videos = res.data.videos || []; // 活动记录视频
        that.setData({
          content: res.data.content || '', // 内容
          id: res.data.id || '', // id
          title: res.data.title || '',
          radio: res.data.type ? res.data.type :'0',
          objectResultDetail:res.data.personnelList ? res.data.personnelList:[],// 已选对象详细信息集合
          objectResult: res.data.fileGuids ? res.data.fileGuids.split(','):[], // 已选对象id集合S
          activeResultDetail:res.data.planList ? res.data.planList:[],
          activeResult: res.data.planId ? res.data.planId.split(','):[],
          showImgs: that.data.showImgs,
          hasImage:imgArr.length > 0 ? true:false,
          images:res.data.imageMap || [],
          videos :  res.data.videos || [],
          hasVideos: videosArr.length > 0 ? true:false,
          isCreator: res.data.isCreator || '0'
        })
      }else{
        Toast(res.msg)
      }

      
    }, function (req) { })
  },
  ImagePreviewShow: function (e) {
    let that = this;
    wx.previewImage({
      current: e.currentTarget.dataset.src, // 当前显示图片的http链接  
      urls: that.data.showImgs // 需要预览的图片http链接列表  
    })
  },
  contentChange: function (e) { // 输入框监听事件
    console.log( e)
    this.setData({
      content: e.detail.value || ''
    })
  },
  formEdit(){ // 编辑
    const that = this;
    that.setData({
      isDetail: false
    })
  },
  formSubmit: function (e) { // 保存走访活动记录内容
    let that = this;
    if( that.data.radio == '2' && that.data.activeResult.length > 1 ) {
      Toast({
        message: '工作总结类型为活动总结时关联活动数量不能超过一个',
        selector: '#van-toast',
        context: that
      });
      return
    }
    let data = {
      id: that.data.id,
      type: that.data.radio,
      title: that.data.title,
      content: that.data.content,
      planId: that.data.activeResult.join(","),
      fileGuids: that.data.objectResult.join(",")
    }
    // console.log(data)
    // return 
    
    wx.showLoading()
    setTimeout(function () {
      data.content = that.data.content;
      call.postData('/admin/report/save', data, function (res) {
        if( res.code == 200  ) {
          Toast({
            message: '保存成功',
            selector: '#van-toast',
            context: that
          });
          let pages =getCurrentPages();//当前页面栈
          if (pages.length >1) {
            let beforePage = pages[pages.length- 2];//获取上一个页面实例对象
            beforePage.loadDataUpdate();//触发父页面中的方法
          }
          wx.hideLoading();
          wx.navigateBack();
        }else{
          Toast({
            message: '保存失败',
            selector: '#van-toast',
            context: that
          });
        }
        
      }, function (req) { })
    }, 600);
  },
  onChangeType(event) { // 工作总结类型
    if( this.data.isDetail ) {
      return
    }
    this.setData({
      radio: event.detail
    });
  },
  onTitleChange (e) { // 标题
    this.setData({
      title:e.detail || ''
    })
  },
  activeSelect () {
    const that = this;
    if(this.activeListView && this.activeListView.updateData ) {
      this.activeListView.updateData({
        activeResultDetail:that.data.activeResultDetail,
        activeResult:that.data.activeResult,
      })
    }
    this.setData({
      addShow:2
    })

  },
  delectActive(e){ // 删除活动
    const that = this;
    // console.log(e.currentTarget.dataset.id// 当前显示图片的http链接  )
    let delectId = e.currentTarget.dataset.id
    that.setData({
      activeResult:that.data.activeResult.filter(item => item != delectId) ,
      activeResultDetail:that.data.activeResultDetail.filter(item => item.id != delectId) 
    })
  },
  delectObject(e) { // 删除人物
    const that = this;
    // console.log(e.currentTarget.dataset.id// 当前显示图片的http链接  )
    let delectId = e.currentTarget.dataset.id
    that.setData({
      objectResult:that.data.objectResult.filter(item => item != delectId) ,
      objectResultDetail:that.data.objectResultDetail.filter(item => item.fileGuid != delectId) 
    })
  },
  reportContentCopy(e) { // 复制活动内容至总结内容
    const that = this;
    let content = e.currentTarget.dataset.content;
    console.log("content",content)
    let workContent =String(that.data.content)  + String(content)  ;
    that.setData({
      content: workContent
    })
  },
  activePeopleSelect(){
    const that = this;
    if( this.activePeopleListView.updateData ) {
      this.activePeopleListView.updateData({
        objectResult:that.data.objectResult,
        objectResultDetail:that.data.objectResultDetail
      })
    }
    that.setData({
      addShow:3
    })
  },
  getObjectSelectData(data) { // 获取已选择对象数据
    // console.log('获取已选择对象数据',data)
    this.setData({
      objectResultDetail:data.detail.objectResultDetail,
      objectResult:data.detail.objectResult,
      addShow:data.detail.addShow
    })
  },
  getActiveSelectData(data) { // 获取已选择对象数据
    // console.log("活动确认", data )
    this.setData({
      activeResultDetail:data.detail.activeResultDetail,
      activeResult:data.detail.activeResult,
      addShow:data.detail.addShow
    })
  },

})