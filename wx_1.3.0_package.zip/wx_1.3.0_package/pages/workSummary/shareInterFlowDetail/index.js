
const call = require("../../../utils/request.js");
const callTime = require("../../../utils/util.js");
let app = getApp();
import Toast from '../../../vant-weapp/toast/toast';
Page({

  /**
   * 页面的初始数据
   */
  data: {
    id:'',
    content: '', // 活动记录内容
    images: [], // 活动记录图片数组
    videos: [], // 活动记录视频数组
    showImgs: [], // 图片预览时需要的数组
    active: '1', // 工作总结类型
    title:'', // 标题
    unWorkType:'', // 详情类型
    isDetail:false,
    hasImage: false,
    radio: '',
    radioName:'个人总结', // 工作总结名称
    show:false,
    addShow:1,
    objectResultDetail:[],// 已选对象详细信息集合
    activeResultDetail:[],
    activeResult: [],
    toView: 'green',
    source:false,
    color:'#99a9bf',
    likeNum:'',// 点赞数量
    showoVerlay:true,
    commentList:[],
    commentContent:"", // 评论内容
    pageable: {
      num:1,
      size:10
    },
    hasMore:true,
    placeholder:'请输入内容',
    contentItem:{}, // 回复的 评论详情
    inputType:'1', // 1 为评论 2 为回复
    isArgee:'1', //是否已经点赞 1未点赞 0 已点赞
    isCreater:false,
    userInfo:{},
    editFlag:false,
    allData:{}
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    // wx.showLoading();
    let userInfo =  wx.getStorageSync("userInfo");
    let that = this;
    this.setData({
      isDetail: e.type == 'detail' ? true:false,
      id:e.id ? e.id : '',
      source: e.source == 'share' ? true : false,
      userInfo:userInfo
    })
    if( e.type == 'detail'  ) {
      wx.showLoading();
      this.getData();
      this.getcommentList()
    }else{
      wx.hideLoading();
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  getData: function () {
    let that = this;
    call.getData('/admin/report/detailById?id=' + this.data.id, function (res) {
      if (res && res.code == 200) {
        wx.hideLoading();
        let imgArr = res.data.imageMap || [];
        imgArr.map(function (item) {
          that.data.showImgs.push(item.url)
        })
        let videosArr = res.data.videos || []
        that.data.videos = res.data.videos || []; // 活动记录视频
        that.setData({
          content: res.data.content || '', // 内容
          id: res.data.id || '', // id
          title: res.data.title || '',
          likeNum:res.data.likes || '', // 点赞数量
          isArgee:res.data.isArgee === 0 ? 0:1,
          unWorkType: res.data.unWorkType || '',
          isCreater: res.data.isCreator == 1 ? true:false, // 是否是作者
          radio: res.data.type ? res.data.type :'0',
          radioName: res.data.type == 1 ? '个人总结': (res.data.type == 2 ? '活动总结': res.data.type == 3 ? '部门总结':'' ),
          objectResultDetail:res.data.personnelList ? res.data.personnelList:[],// 已选对象详细信息集合
          activeResultDetail:res.data.planList ? res.data.planList:[],
          showImgs: that.data.showImgs,
          hasImage:imgArr.length > 0 ? true:false,
          images:res.data.imageMap || [],
          videos :  res.data.videos || [],
          hasVideos: videosArr.length > 0 ? true:false,
          allData:res.data,
        })
      }else{
        Toast(res.msg)
      }

      
    }, function (req) { })
  },
  loadDataUpdate() {
    let that = this;
    wx.showLoading();
    this.getData();
  },
  getcommentList() {
    let that = this;
    if (!that.data.hasMore) {
      return
    }
    let data = {
      articleId:that.data.id,
      num: that.data.pageable.num,
      size: that.data.pageable.size,
    }
    call.postData("/admin/report/commentList",data,function(res){
      if (res.code == 200) {
        if (that.data.pageable.num == 1) {
          that.data.commentList = []
        }
        if (res.data.page < res.data.totalPages) {
          that.data.pageable.num++
        }
        that.data.hasMore = res.data.page < res.data.totalPages
        if (res.data.content && res.data.content.length > 0) {
          that.data.commentList = that.data.commentList.concat(res.data.content)
        }
        that.setData({
          commentList: that.data.commentList,
          hasMore: that.data.hasMore
        })
      } else {
        Toast(res.msg);
      }
    })
  },
  reportListLower(e){
    console.log('滚动到底部',e)
    this.getcommentList()
  },
  ImagePreviewShow: function (e) {
    let that = this;
    wx.previewImage({
      current: e.currentTarget.dataset.src, // 当前显示图片的http链接  
      urls: that.data.showImgs // 需要预览的图片http链接列表  
    })
  },


  onChangeType(event) { // 工作总结类型
    if( this.data.isDetail ) {
      return
    }
    this.setData({
      radio: event.detail
    });
  },

 
  likeOrunLike(data) {
    let that = this;
    console.log("点赞",that.data.isArgee)
    let likeType =  that.data.isArgee == '1' ? '0' : '1'; // likeType 0 点赞 1 取消点赞
   
    call.getData("/admin/report/likeOrunLike?id="+ that.data.id + '&likeType=' + likeType, function(res) {
      if(res.code == 200) {
        if( likeType == 1 ) {
          Toast({
            message: '取消点赞成功',
            selector: '#van-toast',
            context: that
          });
          that.setData({
            likeNum:res.data.likes || '',
            isArgee:likeType
          })
        }else{
          Toast({
            message: '点赞成功',
            selector: '#van-toast',
            context: that
          });
          
          that.setData({
            likeNum:res.data.likes || '',
            isArgee:likeType
          })
        } 
      }else{
        Toast({
          message: res.msg,
          selector: '#van-toast',
          context: that
        });
      }
    })
    
  },
  addReport() {
    console.log("评论")
    const that = this;
    if( that.data.isCreater ) {
      Toast({
        message: '文章作者不能进行评论！',
        selector: '#van-toast',
        context: that
      });
      return 
    }
    this.setData({
      showoVerlay:false,
      commentContent:'',
      inputType:'1',
      placeholder:'请输入内容'
    })
  },
  addPublish() { // 发表评论
    let that = this;
    let commentContent = this.data.commentContent;
    if( that.data.inputType == 1) {
      let postData = {
        content:commentContent,
        articleId: that.data.id
      }
      if( commentContent ) {
        call.postData("/admin/report/comment",postData,function (res) { 
            if(res.code == 200) {
              console.log(res)
              that.data.pageable.num = 1
              that.setData({
                showoVerlay:true,
                hasMore: true
              })
              that.getcommentList()
            }
         })
      }
    }else{
      let postData = {
        content:commentContent,
        commentId: that.data.contentItem.id,
        articleId: that.data.id
      }
      if( commentContent ) {
        call.postData("/admin/report/commentRelpy",postData,function (res) { 
            if(res.code == 200) {
              console.log(res)
              that.data.pageable.num = 1
              that.setData({
                showoVerlay:true,

                hasMore: true
              })
              that.getcommentList()
            }
         })
      }
    }
    
    
    
  },
  onClickHide() {
    this.setData({ showoVerlay: true });
  },
  onReportChange(e) {

  },
  noop() {},
  onReply (e) {
    this.setData({
      showoVerlay:false,
      commentContent:'',
      inputType:'2',
      contentItem: e.currentTarget.dataset.items,
      placeholder:'回复@'+ e.currentTarget.dataset.items.userVO.userName
    })
  },
  onReportChange(ev) { // 评论输入框事件
		this.setData({
		  commentContent: ev.type == "blur" ? ev.detail.value : ev.detail
		});
  },
  onTitleChange (e) { // 标题
    this.setData({
      title:e.detail || ''
    })
  },
  contentChange: function (e) { // 输入框监听事件
    console.log( e)
    this.setData({
      content: e.detail.value || ''
    })
  },
  editFn() {
    wx.navigateTo({
      url: '/pages/workSummary/addShareFlow/index?type=detail&id='+this.data.id,
    })
  },
  deleteFn() {
    const that = this;
    wx.showModal({
      title:'提示',
      content: '您确定要删除吗？',
      success (res) {
        if( res.confirm ) { // 确定
          call.deleteData('/admin/report/del?id='+ that.data.id,(res) => {
            if(res.code == 200 ) {
                Toast({
                  message: '删除成功',
                  selector: '#van-toast',
                  context: that
                });
                let pages =getCurrentPages();//当前页面栈
                if (pages.length >1) {
                  let beforePage = pages[pages.length- 2];//获取上一个页面实例对象
                  
                    if( beforePage.loadDataUpdate ) {
                      beforePage.loadDataUpdate();//触发父页面中的方法
                    }  
                }
                wx.hideLoading();
                wx.navigateBack();
              }
            })
        }else if( res.cancel ) { // 取消
          
        }
      }
    })
  }


})