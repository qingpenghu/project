// 新增工作总结
const call = require("../../../utils/request.js");
const callTime = require("../../../utils/util.js");
let app = getApp();
import Toast from '../../../vant-weapp/toast/toast';
Page({

  /**
   * 页面的初始数据
   */
  data: {
    id:'',
    content: '', // 活动记录内容
    title:'', // 标题
    isDetail:false,
    show:false,
    addShow:1,
    toView: 'green',
    source:false,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
   
    let that = this;
    this.setData({
      isDetail: e.type == 'detail' ? true:false,
      id:e.id ? e.id : '',
    })
    if( e.type == 'detail'  ) {
      wx.showLoading();
      this.getData();
      wx.setNavigationBarTitle({title: '编辑分享交流'});
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
     

  },
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  contentChange: function (e) { // 输入框监听事件
    console.log( e)
    this.setData({
      content: e.detail.value || ''
    })
  },
  getData: function () {
    let that = this;
    call.getData('/admin/report/detailById?id=' + this.data.id, function (res) {
      if (res && res.code == 200) {
        wx.hideLoading();
        that.setData({
          content: res.data.content || '', // 内容
          id: res.data.id || '', // id
          title: res.data.title || '',
        })
      }else{
        Toast(res.msg)
      }
    }, function (req) { })
  },

  formSubmit: function (e) { // 保存走访活动记录内容
    let that = this;
    let data = {
      title: that.data.title,
      content: e.detail.value.textarea || that.data.content,
      unWorkType:'1', // 不是工作总结
    }
    if( that.data.id ) {
      data.id = that.data.id
    }
    console.log(data)
    if ( !data.title ) {
      Toast({
        message: '标题不能为空',
        selector: '#van-toast',
        context: that
      });
      return
    }
    if ( !data.content ) {
      Toast({
        message: '内容不能为空',
        selector: '#van-toast',
        context: that
      });
      return
    }
    wx.showLoading()
      call.postData('/admin/report/save', data, function (res) {
        if( res.code == 200  ) {
          Toast({
            message: '保存成功',
            selector: '#van-toast',
            context: that
          });
          let pages =getCurrentPages();//当前页面栈
          
          if (pages.length >1) {
            let beforePage = pages[pages.length- 2];//获取上一个页面实例对象
            
              if( beforePage.loadDataUpdate ) {
                beforePage.loadDataUpdate();//触发父页面中的方法
              }  
          }
          wx.hideLoading();
          wx.navigateBack();
        }else{
          wx.hideLoading();
          Toast({
            message: '保存失败',
            selector: '#van-toast',
            context: that
          });
        }
        
      }, function (req) { 
        wx.hideLoading();
        Toast({
          message: req.msg,
          selector: '#van-toast',
          context: that
        });
       })
   
  },

  onTitleChange (e) { // 标题
    this.setData({
      title:e.detail || ''
    })
  },

})