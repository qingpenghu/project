// pages/workSummary/addMeritorious/index.js
// 立功喜报
const call = require("../../../utils/request.js");
const callTime = require("../../../utils/util.js");
let app = getApp();
import Toast from '../../../vant-weapp/toast/toast';
Page({

  /**
   * 页面的初始数据
   */
  data: {
    id:'',
    content: '', // 活动记录内容
    images: [], // 活动记录图片数组
    videos: [], // 活动记录视频数组
    showImgs: [], // 图片预览时需要的数组
    title:'', // 标题
    isDetail:false,
    hasImage: true,
    show:false,
    addShow:1, // 1 未关联走访对象
    fileId:[],
    objectResultDetail:[],// 已选对象详细信息集合
    objectResult: [], // 已选对象id集合
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    wx.showLoading();
    let that = this;
    let item = {};
    if( e.cardId ) {
      item = {
        name: decodeURI(e.name),
        cardId: e.cardId,
        fileGuid:e.fileGuid
      }
      this.getObjectDetail(item)
    }
    this.setData({
      isDetail: e.type == 'detail' ? true:false,
      id:e.id ? e.id : '',
      cardId: e.cardId ? e.cardId:'',
      objectResultDetail: e.cardId ? [item]:[]
    })
    if( e.type == 'detail'  ) {
      this.getData();
    }else{
      wx.hideLoading();
      wx.setNavigationBarTitle({title: '新增立功喜报'});
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    this.activePeopleListView = this.selectComponent('#activePeopleListView');//获取对象子组件实例
  },
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },
  getObjectDetail: function(e){
    let that = this;
    // call.postData('/admin/personalFilesBase/detail', params, function (res) {
    call.getData('/admin/OnePersonOneFile/querySorlderRecorderByNamaAndCradId?name='+ e.name + '&sfzhm=' + e.cardId,  function(res) { //  请求成功
      if (res.code == 200 && res.data && res.data.baseInfoVO ) {
        let objData = res.data.baseInfoVO || {};
        let item = {};
        that.setData({
          objectResultDetail: [objData] || [],
        })
      } else {
        return;
      }
    }, function (req) {});
    
  },

  getData: function () {
    let that = this;
    call.getData('/admin/typical/commendationDetailById?id=' + this.data.id, function (res) {
      if (res && res.code == 200) {
        wx.hideLoading();
        let imgArr = res.data.imageMap || [];
        imgArr.map(function (item) {
          that.data.showImgs.push(item.url)
          that.data.fileId.push(item.fileId)
        })
        let videosArr = res.data.videos || []
        that.data.videos = res.data.videos || []; // 活动记录视频
        let fileGuids = [];
        if(res.data.extVeteransDTOList && res.data.extVeteransDTOList.length > 0 ) {
          res.data.extVeteransDTOList.map(item => {
            fileGuids.push(item.fileGuid)
          })
        }
        that.setData({
          content: res.data.content || '', // 内容
          id: res.data.id || '', // id
          title: res.data.title || '',
          showImgs: that.data.showImgs,
          fileId: that.data.fileId,
          hasImage:imgArr.length > 0 ? true:false,
          images:res.data.imageMap || [],
          videos :  res.data.videos || [],
          hasVideos: videosArr.length > 0 ? true:false,
          objectResultDetail: res.data.extVeteransDTOList || [],
          objectResult:fileGuids
        })
      }else{
        Toast(res.msg)
      }

      
    }, function (req) { })
  },
  ImagePreviewShow: function (e) {
    let that = this;
    wx.previewImage({
      current: e.currentTarget.dataset.src, // 当前显示图片的http链接  
      urls: that.data.showImgs // 需要预览的图片http链接列表  
    })
  },
  contentChange: function (e) { // 输入框监听事件
    console.log( e)
    this.setData({
      content: e.detail.value || ''
    })
  },
  formEdit(){ // 编辑
    const that = this;
    that.setData({
      isDetail: false
    })
    wx.setNavigationBarTitle({title: '编辑立功喜报'});
  },
  formSubmit: function (e) { // 保存走访活动记录内容
    let that = this;
    let names = [],cardIds=[],fileGuids=[];
    if( that.data.objectResultDetail.length > 0  ) {
      that.data.objectResultDetail.map(item => {
        names.push(item.name)
        cardIds.push(item.cardId)
        fileGuids.push(item.fileGuid )
      })
    }
    
    let data = {
      id: that.data.id,
      title: that.data.title,
      content: that.data.content,
      fuids: fileGuids.join(),
      name:names.join(),
      cardId:cardIds.join(),
    }
    wx.showLoading()
    setTimeout(function () {
      data.content = that.data.content;
      // if( !data.content || !data.title || !that.data.objectResultDetail.length  ) {
      //   Toast("标题,内容,关联对象不能为空")
      //   wx.hideLoading()
      //   return
      // }
      if( !data.content || !data.title   ) {
        Toast("标题,内容不能为空")
        wx.hideLoading()
        return
      }
      
      call.postData('/admin/typical/commendationSave', data, function (res) {
        wx.hideLoading()
        if(res.code == 200) {
          Toast({
            message: '保存成功',
            selector: '#van-toast',
            context: that
          });
          let pages =getCurrentPages();//当前页面栈
          if (pages.length >1) {
            let beforePage = pages[pages.length- 2];//获取上一个页面实例对象
            if( beforePage.loadDataUpdate ) {
              beforePage.loadDataUpdate();//触发父页面中的方法
            }
            if(  beforePage.shows ) {
              beforePage.shows()
            }
          }
          wx.hideLoading();
          wx.navigateBack();
        }else{
          Toast({
            message: '保存失败',
            selector: '#van-toast',
            context: that
          });
        }
        
      }, function (req) { })
    }, 600);
  },
  onTitleChange (e) { // 标题
    this.setData({
      title:e.detail || ''
    })
  },
  delectObject(e) { // 删除人物
    const that = this;
    let delectId = e.currentTarget.dataset.id
    that.setData({
      objectResult:that.data.objectResult.filter(item => item != delectId) ,
      objectResultDetail:that.data.objectResultDetail.filter(item => item.fileGuid != delectId) 
    })
  },
  activePeopleSelect(){
    const that = this;
    if( this.activePeopleListView.updateData ) {
      this.activePeopleListView.updateData({
        objectResult:that.data.objectResult,
        objectResultDetail:that.data.objectResultDetail
      })
    }
    that.setData({
      addShow:3
    })
  },
  getObjectSelectData(data) { // 获取已选择对象数据
    // console.log('获取已选择对象数据',data)
    this.setData({
      objectResultDetail:data.detail.objectResultDetail,
      objectResult:data.detail.objectResult,
      addShow:data.detail.addShow
    })
  },
  

})