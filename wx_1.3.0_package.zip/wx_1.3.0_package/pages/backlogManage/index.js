// pages/backlogManage/index.js
//index.js
//获取应用实例
const call = require("../../utils/request.js");
const callData = require("../../utils/util.js");
const app = getApp()
import Toast from '../../vant-weapp/toast/toast';



Page({
  data: {
    params: {
      matterName: "",
      matterType:'',
      pageable: {
        page: 1,
        rows: 20
      }
    },
    hasMore: true,
    lists: [
    ],
    selectList:[],
    defaultOption:{
      id:'',
      name:'全部'
    }
  },
  //事件处理函数
  bindViewTap: function() {
    wx.navigateTo({
      url: '../logs/logs'
    })
  },
  onLoad: function () {
  },
  onReady: function() {
    this.select = this.selectComponent('#select');//获取对象子组件实例
    // 首次加载数据
    this.loadData();
    this.loadSelectData();
  },
  showLoadingMore: function() {
    this.setData({
      hasMore: this.data.hasMore
    })
  },
  hideLoadingMore: function () {
    this.setData({
      hasMore: this.data.hasMore
    })
  },
  onChangeTitle(event) {
    this.data.params.matterName = event.detail.value
    this.setData({
      matterName: event.detail.value
    });
  },
  primary: function () {
    this.data.hasMore = true
    this.data.params.pageable.page = 1
    this.loadData();
  },
  /**
   * 加载数据
   */
  loadData: function(data) {
    var that = this
    if (!that.data.hasMore) {
      return
    }
    call.postData('/admin/matterinfo/list', this.data.params, function (res) { //  请求成功
      if (res.code == 200) {
        if (that.data.params.pageable.page == 1) {
          that.data.lists = []
        }
        if (res.data.page < res.data.totalPages) {
          that.data.params.pageable.page++
        }
        that.data.hasMore = res.data.page < res.data.totalPages
        if (res.data.content && res.data.content.length > 0) {
          that.data.lists = that.data.lists.concat(res.data.content)
        }
        that.setData({
          lists: that.data.lists,
          hasMore: that.data.hasMore
        })
      } else {
        Toast(res.msg);
      }
    })
  },
  loadSelectData: function(data) {
    var that = this
    call.postData('/api/common/commonDropDownList', {typeCode: "MATTER_TYPE"}, function (res) { //  请求成功
      if (res.code == 200) {
        that.setData({
          selectList:res.data
        })
        that.select.updatedData(res.data)
      } else {
        Toast(res.msg);
      }
    })
  },
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom () {
    var that = this;
    
    // 显示加载图标
    this.showLoadingMore()
    this.loadData()
  },
  selcteChange(data){
    // console.log("select",data)
    this.data.params.matterType = data.detail.id
    this.setData({
      matterType:data.detail.id
    })
  },
  jumpDetail(e) {
    let index = e.currentTarget.dataset.index
    let detail = this.data.lists[index]
    wx.navigateTo({
      url: '/pages/backlogManage/detail/index?id=' + detail.no,
    })
    // if (detail.type == 0) {
    //   wx.navigateTo({
    //     url: '/pages/backlogManage/detail/index?id=' + detail.id,
    //   })
    // } else {
    //   wx.showLoading({
    //     title: '下载中',
    //   })
    //   wx.downloadFile({
    //     url: detail.content,
    //     success: function (res) {
    //       var Path = res.tempFilePath              //返回的文件临时地址，用于后面打开本地预览所用
    //       wx.openDocument({
    //         filePath: Path,
    //         success: function (res) {
    //           wx.hideLoading()
    //         }
    //       })
    //     },
    //     fail: function (res) {
    //     }
    //   })
    // }
  }
})
