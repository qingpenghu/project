//获取应用实例
const call = require("../../../utils/request.js");
const callData = require("../../../utils/util.js");
const app = getApp()
import Toast from '../../../vant-weapp/toast/toast';

Page({
  data: {
    params: {
      name: "",
      pageable: {
        page: 1,
        rows: 10
      }
    },
    hasMore: true,
    lists: [
    ],
  },
  //事件处理函数
  bindViewTap: function() {
    wx.navigateTo({
      url: '../logs/logs'
    })
  },
  onLoad: function () {
  },
  onReady: function() {
    // 首次加载数据
    this.loadData();
  },
  showLoadingMore: function() {
    this.setData({
      hasMore: this.data.hasMore
    })
  },
  hideLoadingMore: function () {
    this.setData({
      hasMore: this.data.hasMore
    })
  },
  onChangeTitle(event) {
    this.data.params.name = event.detail.value
    this.setData({
      name: event.detail.value
    });
  },
  primary: function () {
    this.data.hasMore = true
    this.data.params.pageable.page = 1
    this.loadData();
  },
  loadDataUpdate: function() { //刷新数据
    this.setData({
      params: {
        name: "",
        pageable: {
          page: 1,
          rows: 10
        },
        
      },
      hasMore: true
    })
    this.loadData()
  },
  /**
   * 加载数据
   */
  loadData: function(data) {
    var that = this
    if (!that.data.hasMore) {
      return
    }
    call.postData('/admin/itemRegistration/list', this.data.params, function (res) { //  请求成功
      if (res.code == 200) {
        if (that.data.params.pageable.page == 1) {
          that.data.lists = []
        }
        if (res.data.page < res.data.totalPages) {
          that.data.params.pageable.page++
        }
        that.data.hasMore = res.data.page < res.data.totalPages
        
        if (res.data.content && res.data.content.length > 0) {
          that.data.lists = that.data.lists.concat(res.data.content)
        }
        that.setData({
          lists: that.data.lists,
          hasMore: that.data.hasMore
        })
      } else {
        Toast(res.msg);
      }
    })
  },
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom () {
    var that = this;
    // 显示加载图标
    this.showLoadingMore()
    this.loadData()
  },
  jumpDetail(e) {
    let id = e.currentTarget.dataset.no
    if( id ) {
      wx.navigateTo({
        url: '/pages/backlogManage/creatBacklogRegister/index?type=detail&id=' + id + '&handling=' + e.currentTarget.dataset.handling
      })
    }else{
      Toast("参数缺失");
    }
  }
})
