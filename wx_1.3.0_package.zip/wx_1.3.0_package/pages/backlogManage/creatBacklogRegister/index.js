// pages/backlogManage/creatBacklogRegister/index.js
//获取应用实例
const call = require("../../../utils/request.js");
const callData = require("../../../utils/util.js");
const app = getApp()
import Toast from '../../../vant-weapp/toast/toast';

Page({
  data: {
    id:'',
    params: {
      page:1,
      pageSize:15,
      name:'',
      cardId:'',
    },
    handlingFalg:false, // 判断按钮显隐
    isDetail:false,
    editFlag:false,
    submitFlag: true,
    formData: {
      telephone:'', // 手机号
      eventContents:'', // 事项内容
      remark:'', // 备注
      handledUser: '', // 经办人
      eventCategory: "", // 事项类别
      handling: '', // 办理情况
      source: '', // 来源
    },
    eventContentsInfo:'',
    remarkInfo:'',
    telError:'',// 手机号错误提示
    sourceInfo: { // 来源渠道
      index: '',
      value: ''
    },
    object:{},
    sourceShow:false,
    sourceArray:['来源渠道1','来源渠道2'],
    eventCategoryInfo: { // 事项类别
      index: '',
      value: ''
    },
    eventCategoryShow:false,
    eventCategoryArray:['事项1','事项2'],
    handlingInfo: { // 办理情况
      index: '',
      value: ''
    },
    handlingShow:false,
    handlingArray:['未办理','已办理'],

    hasMore: true,
    lists: [
    ],
    threshold:30
  },
  //事件处理函数
  bindViewTap: function() {
    wx.navigateTo({
      url: '../logs/logs'
    })
  },
  onLoad: function (e) {
    // console.log(e)
    let type = e.type || ''
    let editFlag = e.id ? true:false;
    let hangling = 'formData.handling';

    this.setData({
      id:e.id ? e.id : '',
      isDetail: type == 'detail' ? true:false,
      editFlag:editFlag,
      handlingFalg : e.handling ? (e.handling == 1 ? true:false):false
    })
    if(e.id) {
      this.getData();
    }else{
      wx.setNavigationBarTitle({title: '新增代办事项登记'});
    }
    this.getCommonDropDrwnList()
    
  },
  getData() { // 获取详情
    let that = this;
    wx.showLoading();
    call.getData('/admin/itemRegistration/detail?no='+that.data.id, function(response) { //  请求成功
      if (response.code == 200) {
        let handlingInfoValue = 'handlingInfo.value';
        let eventCategoryInfoValue = 'eventCategoryInfo.value';
        let sourceInfoValue = 'sourceInfo.value';
        if (response.data) {
          that.setData({
            id: that.data.id || '',
            object:{
              name: response.data.name,
              fileGuid: response.data.personNo
            },
            formData:response.data,
            [eventCategoryInfoValue]:response.data.eventCategoryName || '',
            [sourceInfoValue]:response.data.sourceName || '',
            [handlingInfoValue]:response.data.handling == '1' ? '已办理': '未办理',
          })
        }
        wx.hideLoading();
      } else {
        wx.hideLoading();
        Toast(response.msg)
      }

    }, function(req) {
      wx.hideLoading();
      Toast("请求失败")
    }) //  请求失败
  },
  primary: function () { // 人员列表搜索
    this.data.hasMore = true
    this.data.params.page = 1
    this.loadData();
  },
  onReady: function() {
    // 首次加载数据
    // this.loadData();
  },
  // 申请人电话
	ontelephoneChange: function(ev) {
    let data = "formData.telephone"
    let reg=/^1[3456789][0-9]{9}$/;
    let phone = '';
    phone = ev.type == "blur" ? ev.detail.value : ev.detail;
    if( phone.length <10 ) {
      return
    }
    if ( reg.test(phone) ) {
      this.setData({
        telError:''
      })
    }else{
      this.setData({
        telError:'手机号输入有误！'
      })
      return
    }
		this.setData({
		  [data]: phone
		});
  },
  clearPhone() { // 清空手机号
    let data = "formData.telephone"
    this.setData({
      [data]:''
    })
  },
  clearHandledUser() { // 清空手机号
    let data = "formData.handledUser"
    this.setData({
      [data]:''
    })
  },
  onHandledUserChange: function(ev) { // 经办人
    let data = "formData.handledUser"
		this.setData({
		  [data]: ev.type == "blur" ? ev.detail.value : ev.detail
		});
  },
    // 事项内容收缩面板打开
    setEventContents: function(event) {
      // console.log("event",event)
      this.setData({
        eventContentsInfo: event.detail
      });
    },
    // 事项内容
    onEventContentsChange: function(ev) {
      let data = "formData.eventContents";
      this.setData({
        [data]: ev.type == "blur" ? ev.detail.value : ev.detail
      });
    },
    // 备注
    setRemark: function(event) {
      this.setData({
        remarkInfo: event.detail
      });
    },
    // 事项内容
    onRemarkChange: function(ev) {
      let data = "formData.remark";
      this.setData({
        [data]: ev.type == "blur" ? ev.detail.value : ev.detail
      });
    },
  selectObjiec() {
    let that = this;
    if(that.data.handlingFalg ) {
      return 
    }
    this.loadData();
    this.setData({ show: true });
  },

  onClose() {
    this.setData({ show: false });
  },
  objectListLower(e) {
    // console.log("e",e)
    this.loadData()
  },
  selectObject(e) {
    let item = e.currentTarget.dataset.item;
    this.setData({
      object:item,
      show:false
    })

  },
  onChangeTitle(event) {
    this.data.params.name = event.detail.value
    this.setData({
      name: event.detail.value
    });
  },
  primary: function () {
    this.data.hasMore = true
    this.data.params.pageable.page = 1
    this.loadData();
  },
  /**
   * 加载走访对象数据
   */
  loadData(data) {
    var that = this
    if (!that.data.hasMore) {
      return
    }
    if( this.data.params.page == 1 ) {
      wx.showLoading()
    }
    that.data.hasMore = false
    call.postData('/admin/OnePersonOneFile/queryOnePersonOneFileList', this.data.params, function (res) { //  请求成功
      if (res.code == 200) {
        if (that.data.params.page == 1) {
          wx.hideLoading()
          that.data.objectList = []
        }
        if (res.data.page < res.data.totalPages) {
          that.data.params.page++
        }
        that.data.hasMore = res.data.page < res.data.totalPages
        if (res.data.content && res.data.content.length > 0) {
          that.data.objectList = that.data.objectList.concat(res.data.content)
        }
        that.setData({
          objectList: that.data.objectList,
          hasMore: that.data.hasMore
        })
      } else {
        Toast(res.msg);
      }
    })
  },
 

  sourceSelect() { // 渠道弹窗
    let that = this;
    if(that.data.handlingFalg ) {
      return 
    }
    this.setData({
      sourceShow: !that.data.sourceShow
    });
  },
  onSourceChange(e) { // 来源渠道选择
    let sourceInfoVal = 'sourceInfo.value';
    let sourceInfoIndex = 'sourceInfo.index';
    let paramsSource = 'formData.source';
    this.setData({
      [sourceInfoVal]: e.detail.value,
      [sourceInfoIndex]: e.detail.index,
      [paramsSource]: e.detail.index + 1,
      sourceShow: false
    });
  },
  eventCategorySelect () { // 事项类别
    let that = this;
    if(that.data.handlingFalg ) {
      return 
    }
    this.setData({
      eventCategoryShow: !that.data.eventCategoryShow
    });
  },
  onEventCategoryChange(e) { // 来源渠道选择
    let eventCategoryInfoVal = 'eventCategoryInfo.value';
    let eventCategoryInfoIndex = 'eventCategoryInfo.index';
    let paramsEventCategory = 'formData.eventCategory';
    this.setData({
      [eventCategoryInfoVal]: e.detail.value,
      [eventCategoryInfoIndex]: e.detail.index,
      [paramsEventCategory]: e.detail.index + 1,
      eventCategoryShow: false
    });
  },
  handlingSelect () { // 办理情况
    let that = this;
    if(that.data.handlingFalg ) {
      return 
    }
    this.setData({
      handlingShow: !that.data.handlingShow
    });
  },
  onHandlingChange(e) { // 办理情况
    let handlingInfoVal = 'handlingInfo.value';
    let handlingInfoIndex = 'handlingInfo.index';
    let paramsHandling = 'formData.handling';
    this.setData({
      [handlingInfoVal]: e.detail.value,
      [handlingInfoIndex]: e.detail.index,
      [paramsHandling]: e.detail.index ,
      handlingShow: false
    });
  },
  formSubmit: function () { // 保存代办事项登记
    let that = this;
    if( !that.data.submitFlag ) {
      return 
    }
    // console.log(this.data.formData)
    let formDataObj = this.data.formData;
    let data = {
          telephone: formDataObj.telephone, // 手机号
          eventContents:formDataObj.eventContents, // 事项内容
          remark:formDataObj.remark, // 备注
          handledUser: formDataObj.handledUser, // 经办人
          eventCategory: formDataObj.eventCategory, // 事项类别
          handling: formDataObj.handling, // 办理情况
          source: formDataObj.source, // 来源
        };
    if( data.source > 0  ){}else {
      Toast("来源渠道未选择！")
      return 
    }
    if( !that.data.object.fileGuid ) {
      Toast("未选择申请人！")
      return 
    }
    data.name = that.data.object.name;// 申请人姓名
    data.personNo = that.data.object.fileGuid; // 申请人id
    if( data.telephone ){}else {
      Toast("申请人手机号未填写！")
      return 
    }
    
    if( data.eventCategory > 0  ){}else {
      Toast("事项类别未选择！")
      return 
    }
    if( data.handling === '0' || data.handling === 0 || data.handling  >  0 ){}else {
      Toast("办理情况未选择")
      return 
    }
    if( data.handledUser ){}else {
      Toast("经办人姓名未填写！")
      return 
    }
    wx.showLoading();

    that.setData({
      submitFlag:false
    })
    let url = '';


    if( that.data.id ) {
      url = '/admin/itemRegistration/update' // 编辑
      data.no = that.data.id;
    }else{
      url = '/admin/itemRegistration/insert' // 新增代办登记
    }
    setTimeout(function () {
      // data.content = that.data.content;
      // if( !data.content ) {
      //   Toast("诉求事项不能为空！")
      //   wx.hideLoading()
      //   that.setData({
      //     submitFlag:true
      //   })
      //   return 
      // }
      
      call.postData(url, data, function (res) {
        if( res.code == 200 ) {
          Toast({
            message: '保存成功',
            selector: '#van-toast',
            context: that
          });
          let pages =getCurrentPages();//当前页面栈
          if (pages.length >1) {
            var beforePage = pages[pages.length- 2];//获取上一个页面实例对象
            if( beforePage.loadDataUpdate ) {
              beforePage.loadDataUpdate();//触发父页面中的方法
            }
          }
          wx.hideLoading()
          that.setData({
            submitFlag:true
          })
          wx.navigateBack({
            delta:1
          })
        }else{
          Toast({
            message: '保存失败',
            selector: '#van-toast',
            context: that
          });
          that.setData({
            submitFlag:true
          })
        }
      }, function (req) {
        wx.hideLoading()
        that.setData({
          submitFlag:true
        })
       })
    }, 20);
  },
//  call.deleteData()
formDelete() {
  let that = this;
  wx.showModal({
    title: '提示',
    content: '您确定要删除这条代办事项吗？',
    success (ress) {
      if (ress.confirm) {
        wx.showLoading()
        call.deleteData("/admin/itemRegistration/delete?no="+that.data.id, function (res) { 
            if(res.code == 200) {
              Toast({
                message: '保存成功',
                selector: '#van-toast',
                context: that
              });
              let pages =getCurrentPages();//当前页面栈
              if (pages.length >1) {
                var beforePage = pages[pages.length- 2];//获取上一个页面实例对象
                if( beforePage.loadDataUpdate ) {
                  beforePage.loadDataUpdate();//触发父页面中的方法
                }
              }
              wx.hideLoading()
              that.setData({
                submitFlag:true
              })
              wx.navigateBack({
                delta:1
              })
            }
          })
      } else if (ress.cancel) {
        
      }
    }
  })
  
},
  getCommonDropDrwnList() {
    this.commonDropDrwnList({typeCode:'SOURCE_TYPE',name:'sourceArray'})
    this.commonDropDrwnList({typeCode:'EVENTCATEGORY_TYPE',name:'eventCategoryArray'})
  },
  commonDropDrwnList(data) {
    let that = this
    let url="/api/common/commonDropDownList";

    call.postData(url,{typeCode:data.typeCode},function(res) {
        if( res.code == 200 ) {
          let arr = [];
          res.data.map( item => {
            arr.push(item.name)
          })
          // console.log('arr',arr)
          that.setData({
            [data.name]:arr
          })
        }
    })
  }

})
