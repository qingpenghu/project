// pages/hangGloryDetail/index.js
//获取应用实例
const call = require("../../utils/request.js");
const callData = require("../../utils/util.js");
const callTime = require("../../utils/util.js");
const app = getApp()
import Toast from '../../vant-weapp/toast/toast';
const QQMapWX = require("../../libs/qqmap-wx-jssdk.js");
var qqmapsdk = new QQMapWX({
	key: 'NT2BZ-FEZKJ-TRYF4-K3Q4A-W3SCE-SIBEN' // 必填
});

Page({

  /**
   * 页面的初始数据
   */
  data: {
    id:'',
    baseInfoVO:{},
    gloryData:{}, // 光荣牌悬挂信息
    show:false,
    radio:'',
    status:'',
    name:'',
    queryInputStartTime:'',
    pickerTimeStartFlag:false,
    datetimeStartPicker: {
      currentDate: new Date().getTime(),
      minDate: new Date(1949, 10, 1).getTime(), // 1949-09-30凌晨24点整
      maxDate: new Date().getTime()
    },
    pickerTimeFormatter(type, value) {
      if (type === 'year') {
        return `${value}年`;
      } else if (type === 'month') {
        return `${value}月`;
      }
      return value;
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let id = options.id;
    this.setData({
      id:id
    })
    this.getDetail()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },
  onFocusStartTime(event) {
    //  开始时间获取焦点 打开底部时间选择弹出层
    this.setData({
      pickerTimeStartFlag: true
    });
  },
  onStartTimeClose() {
    // 关闭底部时间弹出层
    this.setData({
      pickerTimeStartFlag: false
    });
  },
  onStartTimeClose() {
    // 关闭底部时间弹出层
    this.setData({
      pickerTimeStartFlag: false
    });
  },
  onConfirmStartTime(event) {
    // 时间选择 完成的确定
    let that = this;
    this.setData({
      datetimeStartPicker: {
        currentDate: event.detail,
        minDate: new Date(1949, 10, 1).getTime(), // 1949-09-30凌晨24点整
        maxDate: new Date().getTime()
      },
      queryInputStartTime: callTime.timestampFn(event.detail, 'Y-M-D h:m:s'),
      pickerTimeStartFlag: false
    });
  },
  getDetail() {
    let that = this;
    call.getData('/api/suspend/detail?id=' + that.data.id, function (res) { //  请求成功
      if (res.code == 200) {
        // that.baseInfoFn(res.data.veteransGatherVO.baseInfoVO)
        that.baseInfoFn(res.data.apiVeteransDTO)
        let response= {};
        response.statusText = '';
        response.detailStatusText = '';
        if(res.data.status == 1){
          response.statusText = '已申请';
          response.handlerName = res.data.applicantUserName || '';
          response.handleTime = res.data.applicantDate || '';
          response.detailStatusText = '申请';
        }else if(res.data.status == 2){
          response.statusText = '已制作';
          response.handlerName = res.data.producerUser || '';
          response.handleTime = res.data.producerDate || '';
          response.detailStatusText = '制作';
        }else if(res.data.status == 3){
          response.statusText = '已领取';
          response.handlerName = res.data.receiverUser || '';
          response.handleTime = res.data.receiverDate || '';
          response.detailStatusText = '领取';
        }else if(res.data.status == 4){
          response.statusText = '已悬挂';
          response.handlerName = res.data.suspendUser || '';
          response.handleTime = res.data.suspendDate || '';
          response.detailStatusText = '悬挂';
        }
        that.setData({
          gloryData:response,
          status: res.data.status,
          radio:res.data.status
        })
      } else {
        Toast(res.msg);
      }
    })
  },

  baseInfoFn(data) {
    let baseInfoVO = data;
    baseInfoVO.sex = data.sex == 1 ? "男" : data.sex == 2 ? "女" : "-"; // 性别
    baseInfoVO.otherCard =
      data.otherCard == 1 ? "是" : data.otherCard == 0 ? "否" : "-"; // 是否港澳
    baseInfoVO.gloryCard =
      data.gloryCard == 1 ? "是" : data.gloryCard == 0 ? "否" : "-"; // 是否申请悬挂光荣牌
    baseInfoVO.agent =
      data.agent == 1 ? "是" : data.agent == 0 ? "否" : "-"; // 是否代办
    baseInfoVO.hasDisGrant =
      data.hasDisGrant == 1 ? "是" : data.hasDisGrant == 0 ? "否" : "-"; // 享受残疾人两项补贴
    baseInfoVO.hasPenGrant =
      data.hasPenGrant == 1 ? "是" : data.hasPenGrant == 0 ? "否" : "-"; // 享受国家抚恤补助金情况
    baseInfoVO.narDisabled =
      data.narDisabled == 1 ? "是" : data.narDisabled == 0 ? "否" : "-"; // 是否伤残
    baseInfoVO.orph =
      data.orph == 1 ? "是" : data.orph == 0 ? "否" : "-"; // 孤儿情况：
    baseInfoVO.alold =
      data.alold == 1 ? "是" : data.alold == 0 ? "否" : "-"; // 孤老

    baseInfoVO.zzmm = callData.makeSelectOrChecked(
      data.zzmm,
      callData.dataDictionary().politicalStatus
    ); //政治面貌
    baseInfoVO.nation = callData.makeSelectOrChecked(
      data.nation,
      callData.dataDictionary().nationMap
    ); //民族
    baseInfoVO.household = callData.makeSelectOrChecked(
      data.household,
      callData.dataDictionary().registrationMap
    ); //户籍类别
    baseInfoVO.health = callData.makeSelectOrChecked(
      data.health,
      callData.dataDictionary().healthStatus
    ); //健康状况
    baseInfoVO.marState = callData.makeSelectOrChecked(
      data.marState,
      callData.dataDictionary().marriageStatus
    ); //婚姻状况
    baseInfoVO.education = callData.makeSelectOrChecked(
      data.education,
      callData.dataDictionary().cultureMap
    ); //文化程度
    baseInfoVO.empStatus = callData.makeSelectOrChecked(
      data.empStatus,
      callData.dataDictionary().empStatus
    ); //就业情况
    baseInfoVO.personType = callData.makeSelectOrChecked(
      data.personType,
      callData.dataDictionary().perCategory
    ); //人员类别

 
    let personnelType = [];
    personnelType[0] = callData.makeSelectOrChecked(
      data.f1,
      callData.dataDictionary().perCategory
    ); //人员类别
    personnelType[1] = callData.makeSelectOrChecked(
      data.f2,
      callData.dataDictionary().perCategory
    ); //人员类别
    personnelType[2] = callData.makeSelectOrChecked(
      data.f3,
      callData.dataDictionary().perCategory
    ); //人员类别
    personnelType[3] = callData.makeSelectOrChecked(
      data.f4,
      callData.dataDictionary().perCategory
    ); //人员类别
    personnelType[4] = callData.makeSelectOrChecked(
      data.f5,
      callData.dataDictionary().perCategory
    ); //人员类别
    personnelType[5] = callData.makeSelectOrChecked(
      data.f6,
      callData.dataDictionary().perCategory
    ); //人员类别
    personnelType = personnelType.filter(function(s) {
      return s && s.trim();
    });
    baseInfoVO.personnelType = personnelType.join(",");

    this.setData({
      baseInfoVO: baseInfoVO
    })
  },
  changeStatus(){
    console.log("更改状态")
    this.setData({
      show:true
    })
  },
  onClose() {
    this.setData({
      show:false
    })
  },
  onChange(e) {
    console.log("e",e)
    this.setData({
      radio: e.detail
    });
  },
  onChangePeople(e){
    // console.log(event.detail);
    this.setData({
      name: e.detail
    })
  },
  onSure() { // 确定
    let that = this;
    // let startTimeArr, startTimeStr;
    // console.log( that.data.queryInputStartTime )
    // if (that.data.queryInputStartTime) {
    //   startTimeArr = that.data.queryInputStartTime.split('/');
    //   startTimeStr = startTimeArr.join('-');
    // }
    // console.log( startTimeStr,that.data.queryInputStartTime )
    
    // return 
    
    if(  this.data.name && that.data.queryInputStartTime ) {
      let data = {
        status :'4' ,
        suspendUser: that.data.name,
        no:that.data.id,
        suspendDate:that.data.queryInputStartTime,
      }
      
      call.postData('/api/suspend/update',data ,function (res) { 
        if(res.code == 200) {
          Toast("成功")
          that.setData({
            show:false,
            name:'',
            status:'',
            radio:''
          })
          that.getDetail()
        }else{
          Toast(res.msg)
        }
      }, function (req) {
        Toast(req.msg)
       })

    }else{
      Toast("工作人员名字和悬挂时间必填!")
    }
  },
  goToHere(e){ // 地图
    let that= this;
			let location = e.currentTarget.dataset.location || '';
			console.log('location', location)
			
			//调用地址解析接口
			qqmapsdk.geocoder({
				//获取表单传入地址
				address: location, //地址参数，例：固定地址，address: '北京市海淀区彩和坊路海淀西大街74号'
				success: function(res) {//成功后的回调
					var res = res.result;
					var latitude = res.location.lat;
					var longitude = res.location.lng;
					console.log('res', res)
					wx.openLocation({
						latitude,
						longitude,
						name: location,
						scale: 18
					})
					
					//根据地址解析在地图上标记解析地址位置
					// _this.setData({ // 获取返回结果，放到markers及poi中，并在地图展示
					// 	markers: [{
					// 		id: 0,
					// 		title: res.title,
					// 		latitude: latitude,
					// 		longitude: longitude,
					// 		iconPath: './resources/placeholder.png',//图标路径
					// 		width: 20,
					// 		height: 20,
					// 		callout: { //可根据需求是否展示经纬度
					// 			content: latitude + ',' + longitude,
					// 			color: '#000',
					// 			display: 'ALWAYS'
					// 		}
					// 	}],
					// 	poi: { //根据自己data数据设置相应的地图中心坐标变量名称
					// 		latitude: latitude,
					// 		longitude: longitude
					// 	}
					// });
				},
				fail: function(error) {
					Toast({
						// message: '目标地址过于精简无法定位',
						message: error.message,
						selector: '#van-toast',
						context: that
					});
				},
				complete: function(res) {
				}
			})

  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})