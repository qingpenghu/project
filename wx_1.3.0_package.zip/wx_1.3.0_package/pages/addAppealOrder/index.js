// pages/addAppealOrder/index.js
// 诉求工单详情
const call = require("../../utils/request.js");
const callData = require("../../utils/util.js");
const app = getApp()
import Toast from '../../vant-weapp/toast/toast';

Page({
  /**
   * 组件的初始数据
   */
  data: {
    id:'',
    status:'', // 办理状态
    handover:'', // 移交状态
    statusValue:'',
    handoverValue:'',
    content:'', // 诉求内容
    isDetail:false,
    editFlag:false,
    submitFlag: true, // 避免重复提交
    show: false , // 弹出层开关
    params:{
      page:1,
      pageSize:15,
      name:'',
      cardId:'',
    },
    objectList:[], // 对象列表
    object:{}, // 关联对象
    hasMore: true,
    threshold:30
  },
  onLoad: function (e) {
    console.log(e)
    let type = e.type || ''
    let editFlag = e.id ? true:false;
    this.setData({
      id:e.id ? e.id : '',
      isDetail: type == 'detail' ? true:false,
      editFlag:editFlag
    })
    if(e.id) {
      this.getData();
    }else{
      wx.setNavigationBarTitle({title: '新增诉求工单'});
    }
  },
    getData() {
      let that = this;
      wx.showLoading();
      call.getData('/admin/personalFilesRecord/getSingleMajorElement?id='+that.data.id, function(response) { //  请求成功
        if (response.code == 200) {
          
          if (response.data) {
            that.setData({
              id: that.data.id || '',
              content: response.data.content || '', // 诉求内容
              status: (response.data.status == 0 || response.data.status == 1) ? response.data.status.toString():response.data.status, // 办理状态
              handover:(response.data.handover == 0 || response.data.handover == 1 ) ? response.data.handover.toString() : response.data.handover , // 移交状态
              object:{
                name: response.data.name,
                cardId: response.data.cardId,
                visionId: response.data.visionId,
                fileGuid: response.data.recordId
              }
            })
          }
          wx.hideLoading();
        } else {
          wx.hideLoading();
          Toast(response.msg)
        }

      }, function(req) {
        wx.hideLoading();
        Toast("请求失败")
      }) //  请求失败
    },
    contentChange: function (e) { // 输入框监听事件
      this.setData({
        content: e.detail.value || ''
      })
    },
    onChangeType(event) { // 办理状态
      if( this.data.isDetail ) {
        return
      }
      this.setData({
        status: event.detail
      });
    },
    onHandoverType(event) { // 移交状态
      if( this.data.isDetail ) {
        return
      }
      this.setData({
        handover: event.detail
      });
    },
    formEdit(){ // 编辑
      const that = this;
      wx.setNavigationBarTitle({title: '编辑诉求工单'});
      that.setData({
        isDetail: false
      })
    },
    formDelete() { // 删除
      let that = this;
      wx.showLoading();
      let data = {
        id: that.data.id
      }
      call.postData('/admin/personalFilesRecord/deleteSingleMajorElement',data, function(response) { //  请求成功
        if (response.code == 200) {
          wx.hideLoading();
          Toast("删除成功")
          let pages =getCurrentPages();//当前页面栈
            if (pages.length >1) {
              var beforePage = pages[pages.length- 2];//获取上一个页面实例对象
              if( beforePage.loadDataUpdate ) {
                beforePage.loadDataUpdate();//触发父页面中的方法
              }
            }
            wx.hideLoading()
            wx.navigateBack({
              delta:1
            })
          
        } else {
          wx.hideLoading();
          Toast(response.msg)
        }

      }, function(req) {
        wx.hideLoading();
        Toast("请求失败")
      }) //  请求失败
    },
    formSubmit: function (e) { // 保存走访内容
      let that = this;
      if( !that.data.submitFlag ) {
        return 
      }
      if( !that.data.object.cardId ) {
        Toast("未选择对象！")
        return 
      }
      let data = {
        id: that.data.id || '',
        content:  that.data.content,
        status:  that.data.status,
        handover:  that.data.handover,
        name: that.data.object.name,
        cardId:that.data.object.cardId,
        recordId: that.data.object.fileGuid
      }
      if( data.status === '0' || data.status === '1' ){}else {
        Toast("办理状态未选！")
        return 
      }
      
      if( data.handover === '0' || data.handover === '1' ){}else {
        Toast("移交状态未选！")
        return 
      }
      wx.showLoading();
      that.setData({
        submitFlag:false
      })
      let url = '';
      if( that.data.id ) {
        url = '/admin/personalFilesRecord/updateMajorElementInfo' // 编辑
      }else{
        url = '/admin/personalFilesRecord/insertMajorElementInfoVO' // 新增
      }
      setTimeout(function () {
        data.content = that.data.content;
        if( !data.content ) {
          Toast("诉求事项不能为空！")
          wx.hideLoading()
          that.setData({
            submitFlag:true
          })
          return 
        }
        
        call.postData(url, data, function (res) {
          if( res.code == 200 ) {
            Toast({
              message: '保存成功',
              selector: '#van-toast',
              context: that
            });
            let pages =getCurrentPages();//当前页面栈
            if (pages.length >1) {
              var beforePage = pages[pages.length- 2];//获取上一个页面实例对象
              if( beforePage.loadDataUpdate ) {
                beforePage.loadDataUpdate();//触发父页面中的方法
              }
            }
            wx.hideLoading()
            that.setData({
              submitFlag:true
            })
            wx.navigateBack({
              delta:1
            })
          }else{
            Toast({
              message: '保存失败',
              selector: '#van-toast',
              context: that
            });
            that.setData({
              submitFlag:true
            })
          }
        }, function (req) {
          wx.hideLoading()
          that.setData({
            submitFlag:true
          })
         })
      }, 600);
    },
    selectObjiec() {
      this.loadData();
      this.setData({ show: true });
    },
  
    onClose() {
      this.setData({ show: false });
    },
    objectListLower(e) {
      // console.log("e",e)
      this.loadData()
    },
    selectObject(e) {
      let item = e.currentTarget.dataset.item;
      this.setData({
        object:item,
        show:false
      })

    },
    loadData(data) {
      var that = this
      if (!that.data.hasMore) {
        return
      }
      if( this.data.params.page == 1 ) {
        wx.showLoading()
      }
      that.data.hasMore = false
      // call.postData('/admin/personalFilesBase/list', this.data.params, function (res) { //  请求成功
      call.postData('/admin/OnePersonOneFile/queryOnePersonOneFileList', this.data.params, function (res) { //  请求成功
        if (res.code == 200) {
          if (that.data.params.page == 1) {
            that.data.objectList = [];
            wx.hideLoading()
          }
          if (res.data.page < res.data.totalPages) {
            that.data.params.page++
          }
          that.data.hasMore = res.data.page < res.data.totalPages
          if (res.data.content && res.data.content.length > 0) {
            that.data.objectList = that.data.objectList.concat(res.data.content)
          }
          that.setData({
            objectList: that.data.objectList,
            hasMore: that.data.hasMore
          })
        } else {
          Toast(res.msg);
        }
      })
    },
    primary: function () { // 人员列表搜索
      this.data.hasMore = true
      this.data.params.page = 1
      this.loadData();
    },

})