//index.js
//获取应用实例
const app = getApp();
Page({
  data: {
		planId: '', //计划的id
    interviewBar: 0
  },
  // 切换不同的tab
  onChange(event) {
    this.setData({
      interviewBar: event.detail.index
    })
  },
  //事件处理函数
  bindViewTap: function() {

  },
  onLoad: function(e) {
		// 获取url中传过来的值 id
		this.setData({ // 计划的id
		  planId:e.id,
			isCreator: e.isCreator
		})
	},
  onReady: function() {
    // 页面初次渲染完成后，使用选择器选择组件实例节点，返回匹配到组件实例对象  
    this.visitObjectList = this.selectComponent('#visitObject');
    this.goWithPeopleList = this.selectComponent('#goWithPeople');
    this.visitGoodsList = this.selectComponent('#visitGoods');
    this.visitActivityList = this.selectComponent('#visitActivity');
    // 首次加载数据

  },
  /**
   * 加载数据
   */
  loadData: function() {

  },
  getUserInfo: function(e) {

  },
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {
    if (this.data.interviewBar == 0) {
      // 走访对象 触底加载更多
      // this.selectComponent('#visitObject').onContactButton();
    } else if (this.data.interviewBar == 1) {
      // 随同人员 触底加载更多
      // this.selectComponent('#goWithPeople').onContactButton();
    }else if (this.data.interviewBar == 2) {
      // 走访物资 触底加载更多
      // this.selectComponent('#visitGoods').onContactButton();
    } else if (this.data.interviewBar == 3) {
      // 走访活动 触底加载更多
      // this.selectComponent('#visitActivity').onContactButton();
    }
  },
  /**
   * 页面滑动处理函数
   */
  onPageScroll: function (ev) {

  },
})