const call = require("../../utils/request.js");
const callTime = require("../../utils/util.js");
const app = getApp();
import Toast from '../../vant-weapp/toast/toast';
Page({

  /**
   * 页面的初始数据1
   */
  data: {
    visitTime:'', // 来访时间
    flag:true,
    photoArray:[],
    fileGuid: '',
    addVisitSteps: [{
      text: '第一步'
    }, {
      text: '第二步'
    }, {
      text: '第三步'
    }],
    addVisitActive: 0,
    healthArray: [ '良好', '一般', '差'],
    healthShow: false,
    healthInfo: {
      index: '',
      value: ''
    },
    faceArray: ['中国共产党党员', '中国共产党预备党员', '中国共产主义青年团团员', '中国国民党革命委员会会员', '中国民主同盟盟员', '中国民主建国会会员', '中国民主促进会会员', '中国农工民主党党员', '中国致公党党员', '九三学社社员', '台湾民主自治同盟盟员', '无党派民主人士', '群众'],
    faceShow: false,
    faceInfo: {
      index: '',
      value: ''
    },
    maritalArray: ['未婚', '已婚', '丧偶', '离婚'],
    maritalShow: false,
    maritalInfo: {
      index: '',
      value: ''
    },
    workArray: ['在职', '无业', '务农','自主创业','继续教育'],
    workShow: false,
    onWorkArray: ['政府扶持就业','自主就业','灵活就业'], // 在职工作类型选择
    onWorkTypeCellShow: false,
    noWorkTypeCellShow: false,
    onWorkShow: false,
    workTypeInfo: { // 在职工作类别
      index:'',
      value:''
    },
    noWorkArray: ['下岗','失业','待业','离休','退休'], // 无业类型
    noWorkShow: false,
    noWorkHalfYearArray:['否','是'],
    noWorkHalfYearInfo: {
      index:'',
      value:''
    },
    noWorkHalfYearShow: false,
    unitPropertiesShow: false, // 工作性质开关
    unitPropertiesArray:['党政机关','事业单位','国有企业','民营企业','民营企业','其他'],
    unitPropertiesInfo: { // 行业类别
      index: '',
      value: ''
    },
    occupationShow: false, // 职业性质开关
    occupationArray:[],
    occupationInfo: { // 职业类别
      index: '',
      value: ''
    },
    professionShow: false, // 从事行业开关
    professionArray:[],
    professionInfo: { // 从事行业
      index: '',
      value: ''
    },
    workInfo: {
      index: '',
      value: ''
    },
		trainArray: ['无培训','全员适应性培训', '就业前培训'],
		trainShow: false,
		trainInfo: {
		  index: '',
		  value: ''
		},
		personalStateArray: ['正常', '去世', '迁出'],
		personalStateShow: false,
		personalStateInfo: {
		  index: '',
		  value: ''
		},
    lossReasonInfo: '', // 下岗原因
    healthRemarkInfo: '', // 健康情况详情
    employmentDetailInfo:'', // 就业情况详情
    housingStatusInfo:'', // 住房状况详情
    houseActive: '',
    houseResult: [],
    houseArea: {
      house1: '',
      house2: '',
      house3: '',
      house4: '',
      house5: '',
      house6: '',
      house7: '',
      house8: ''
    },
    jobDemandAct: '',
    intentionAct: '',
    incomeArray: ['0-10000元', '10001-30000元', '30001-50000元', '50001-120000元', '120000元以上'],
    incomeShow: false,
    incomeInfo: {
      index: '',
      value: ''
    },
    oldAgeArray: ['否', '是'],
    oldAgeShow: false,
    oldAgeInfo: {
      index: '',
      value: ''
    },
		personalStateArray: ['正常', '去世', '迁出'],
		personalStateShow: false,
		personalStateInfo: {
		  index: '',
		  value: ''
		},
    isSlavaArray: ['否', '是'],
    isSlavaShow: false,
    isSlavaInfo: {
      index: '',
      value: ''
    },
    applyTimeShow: false,
    hangShow: false,
    capitalVisitShow: false, // 进京上访时间弹框开关 
    provincialVisitShow: false, // 到省上访时间弹框开关
    provincialVisitDate: new Date().getTime(), // 到省上访时间显示
    capitalVisitDate: new Date().getTime(), // 进京上访时间显示
    applyCurrentDate: new Date().getTime(),
    minDate: new Date(1949, 10, 1).getTime(), // 1949-09-30凌晨24点整
    maxDate: new Date().getTime(),
    hangCurrentDate: new Date().getTime(),
    formatter(type, value) {
      if (type === 'year') {
        return `${value}年`;
      } else if (type === 'month') {
        return `${value}月`;
      }
      return value;
    },
    assisActive: '',
    assisResult: [],
    childrenAct: '',
    mainDiffAct: '',
    thoughtAct: '',
    thePartyAct: '',
    welfareAct: '',
    contentsAct: '',
		capitalVisitAct: '', // 进京上访回访情况
    provincialVisitAct: '', // 到省上访回访情况
    visitAct:'', // 回访情况
		supportAct: '', // 供养情况
		quitTypeAct: '', // 退役方式
		question1Act: '', // 问题1
		question2Act: '', // 问题2
		question3Act: '', // 问题3
		question4Act: '', // 问题4
    visitArray: ['在办', '已办'],
    visitShow: false,
    visitInfo: {
      index: '',
      value: ''
    },
    typeArray: ['现场走访', '电话走访'],
    typeShow: false,
    typeInfo: {
      index: '1',
      value: '现场走访'
    },
    accidentArray: ['否', '是'],
    accidentShow: false,
    accidentInfo: {
      index: '',
      value: ''
    },
    accDetaAct: '',
    suppliesArray: ['否', '是'],
    suppliesShow: false,
    suppliesInfo: {
      index: '',
      value: ''
    },
    suppliesAct: '',
    bjHave: '', // 是否进京上访
    gdHave: '', // 是否到省上访
    bjVisitTimeAll: '', // 进京上访时间
    gdVisitTimeAll: '', // 到省上访时间
    treatmentInfo:'', // 60岁退役士兵待遇
    socialAssistanceInfo:'', // 社会救助
    mainAppealInfo:'', // 主要诉求
    feedbackResultsInfo:'',// 反馈结果
    formData: {
      name: '', // 姓名
      cardId: '', // 身份证
      phone: '', // 联系电话
			personalTel: '', // 本人电话
      health: '', // 健康状况
      face: '', //  政治面貌
      marital: '', //  婚姻状况
      address: '', // 家庭住址
      employment: '', // 就业情况
      empStatusExtraI:'', // 就业情况1级
      empStatusExtraII:'', // 无业情况
      profession: '',  // 行业类别
      occupation: '', // 职业类别
      unitProperties: '',  // 工作单位性质
      workUnits: '', // 工作单位
			workPosition: '', // 工作职位
			lossDuration: '', // 下岗时长
			lossReason: '', // 下岗原因
      room: '', // 房间数
      house: '', // 住房状况 复选
      houseArea: '', // 住房面积 
      jobDemand: '', //就业需求
      intention: '', // 创业意向
			train: '', // 参加培训
			schoolName: '', // 学校名称
			major: '', // 就读专业
			studyDuration: '', // 就读时间
      income: '', // 个人年收入
      isSlava: '', // 是否申请悬挂光荣牌
      applyTime: '', // 申请时间
      hangTime: '', // 悬挂时间
      oldAge: '', // 孤老情况
      assis: '', // 社会救助
      children: '', // 子女情况
      capitalVisit: '', // 进京上访回访情况
      capitalVisitFlag: '', // 是否进京上访
      capitalVisitTime: '', // 进京上访时间
      provincialVisit: '', // 到省上访回访情况
      provincialVisitFlag: '', // 是否到省上访开关
      provincialVisitTime: '', // 到省上访时间
      provincialName: '', // 上访的省份
      mainDiff: '', // 主要困难
      thought: '', //思想状况
      theParty: '', // 参加党组织活动
      welfare: '', // 参加公益活动
      majorFlag: '', // 是否有服务内容选择
      contents: [], // 主要内容
			personalState: '', // 人员状态
			support: '', // 供养情况
			quitType: '', // 退役方式
			question1: '', // 问题1
			question2: '', // 问题2
			question3: '', // 问题3
			question4: '', // 问题4
      visit: '', // 走访状态
      accident: '', //  是否重大事故
      accDeta: '', // 重大事故详情
      sympathySupplies: '', // 是否有慰问物资
      suppliesContent: '', // 慰问物质详情
      suppliesMoney: '',// 慰问物资合计金额
      visitType: '1',// 走访形式
      spotImages:[],//现场照片,
      monthlyAllowance:'', // 月生活津贴
      householdIncome: '', // 家庭年收入
      familyPopulation:'', // 家庭人口
      housingStatus: '', // 住房状况详情
      healthRemark:'', // 健康状况详情
      employmentDetail:'', // 就业情况详情
      treatment:'', // 60岁退役士兵待遇
      socialAssistance:'', // 社会救助
      mainAppeal:'', // 主要诉求
      feedbackResults:'',// 反馈结果

    },
    numberIndex:0


  },
  inputEidt(e){  // 主要事项
    let that = this;
    let infoArr = this.data.formData.contents;
    let contInfo = "formData.contents";
    let even = {
      content: e.detail.value
    };
    infoArr.forEach((item,index) => {
      if (index == e.currentTarget.dataset.idx){
        infoArr.splice(index, 1, even);
      }
    })
    this.setData({
      [contInfo]: infoArr
    })
  },
  delThisMaterials(e){  //点击尾部图标删除
    let that = this;
    let contInfo = "formData.contents";
    this.data.formData.contents.splice(e.currentTarget.dataset.idx, 1);
    this.setData({
      [contInfo]: that.data.formData.contents
    })
  },
  addGoodsItem() {
    // 添加主要事项事件
    let serviceItem = "formData.contents";
    let that = this;
    if (this.data.formData.contents.length >= 10) {
      Toast("最多添加10条！");
      return false;
    }
    this.data.formData.contents.push({content: ''});
    that.data.numberIndex++;
    this.setData({
      [serviceItem]: that.data.formData.contents
    })
  },
/**
   * 删除图片
   */
  closeImgFn:function(e){
    let that = this;
    let index = e.currentTarget.dataset.dix;
    this.data.photoArray.splice(index,1);
    this.setData({
      photoArray: that.data.photoArray
    })
  },

  /**
   * 预览图片
   */
  previewImage: function (e) {
    var current = e.target.dataset.src;
    wx.previewImage({
      current: current, // 当前显示图片的http链接  
      urls: this.data.photoArray // 需要预览的图片http链接列表  
    })
  }, 

  /**
   *  调用相机  相册
   */
  openCamera: function(){
    let that = this;
    let count = 3-this.data.photoArray.length;
    wx.chooseImage({
      count: count,
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera'],
      success(res) {
        // tempFilePath可以作为img标签的src属性显示图片
        let tempFilePaths = res.tempFilePaths;
        tempFilePaths.forEach(function(item,index){
          wx.showLoading()
          wx.uploadFile({
            url: call.hostUrl + '/admin/image/uploadFile', //仅为示例，非真实的接口地址
            header: call.getHeader(),
            filePath: item,
            name: 'file',
            success(res) {
              wx.hideLoading()
              let data = JSON.parse(res.data);
              if (data.code != 200) {
                Toast("上传失败，" + data.msg + "！");
                return false;
              }
              let img = data.data.url;
              that.data.photoArray.push(img);
              if (that.data.photoArray.length > 3){
                that.data.photoArray = that.data.photoArray.slice(0, 2);
              }
              that.setData({
                photoArray: that.data.photoArray
              });
            },
            fail(req) {
              wx.hideLoading()
              Toast(req.msg);
            }
          })
        });
      }, fail(){
        wx.hideLoading()
      }
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    // console.log("opt",options)
    if(this.data.occupationArray.length < 1 ) {
      this.occproArray()
    }
    
    if (options.id != undefined) {
      this.setData({ flag: false});
    } else {
      this.setData({ flag: true });
      this.visitRecordAdd(options);
      return false;
    }
    let that = this;
    let params = {
      fileGuid: options.id
    }
    
    call.postData('/admin/personalFilesRecord/detail', params, function (res) {
      if (res.code == 200 && res.data) {
        that.onCardIdInit(res.data);
        that.visitInfoReturn(res.data)
        that.setData({ 
          fileGuid: res.data.fileGuid,
          visitTime: res.data.visitTime ? res.data.visitTime : ''
         });
      } else {
        return;
      }
    }, function (req) {});
  },
  // 行业 职位 数组处理
  occproArray: function() {
    let occupationArr = [], professionArr = [];
    callTime.dataDictionary().occupationStatus.forEach(item => {
      occupationArr.push(item.title)
    })
    callTime.dataDictionary().professionStatus.forEach(item => {
      professionArr.push(item.title)
    })
    this.setData({
      occupationArray: occupationArr,
      professionArray: professionArr
    })

  },
  // 走访记录新增回显
  visitRecordAdd: function(e){
    let that = this;
    let params = {
      cardId: e.cardId
    }
    // call.postData('/admin/personalFilesBase/detail', params, function (res) {
    call.getData('/admin/OnePersonOneFile/querySorlderRecorderByNamaAndCradId?name='+ e.name + '&sfzhm=' + e.cardId,  function(res) { //  请求成功
      if (res.code == 200 && res.data) {
        that.onCardIdInit(res.data.baseInfoVO);
        that.visitInfoReturn(res.data)
      } else {
        return;
      }
    }, function (req) {});
    // call.postData('/admin/personalFilesBase/detail', params, function (res) {
    //   if (res.code == 200 && res.data) {
    //     that.onCardIdInit(res.data.baseInfoVO);
    //     that.visitInfoReturn(res.data)
    //   } else {
    //     return;
    //   }
    // }, function (req) {});
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },
  // 姓名内容
  onNameChange: function(ev) {
    let data = "formData.name"
    this.setData({
      [data]: ev.type == "blur" ? ev.detail.value : ev.detail
    });
  },
  // 身份证号内容
  onCardIdChange: function(ev) {
    let data = "formData.cardId"
    this.setData({
      [data]: ev.type == "blur" ? ev.detail.value : ev.detail
    });
  },
  // 联系电话内容
  onPhoneChange: function(ev) {
    let data = "formData.phone"
    this.setData({
      [data]: ev.type == "blur" ? ev.detail.value : ev.detail
    });
  },
	// 本人电话内容
	onPersonalTelChange: function(ev) {
		let data = "formData.personalTel"
		this.setData({
		  [data]: ev.type == "blur" ? ev.detail.value : ev.detail
		});
	},
  // 健康状况弹出层打开
  setHealth: function() {
    this.setData({
      healthShow: true
    });
  },
  // 健康状况弹出层关闭
  onHealthClose: function() {
    this.setData({
      healthShow: false
    });
  },
  // 健康状况选择确定
  onHealthChange: function(e) {
    let healthInfoVal = 'healthInfo.value';
    let healthInfoInd = 'healthInfo.index';
    let formHealth = 'formData.health';
    this.setData({
      [healthInfoVal]: e.detail.value,
      [healthInfoInd]: "0" + (e.detail.index + 1),
      [formHealth]: "0" + (e.detail.index + 1),
      healthShow: false
    });
  },
  // 政治面貌弹出层打开
  setPolicFace: function() {
    this.setData({
      faceShow: true
    });
  },
  // 政治面貌弹出层关闭
  onFaceClose: function() {
    this.setData({
      faceShow: false
    });
  },
  // 政治面貌选择确定
  onFaceChange: function(e) {
    let faceInfoVal = 'faceInfo.value';
    let faceInfoInd = 'faceInfo.index';
    let formFace = 'formData.face';
    if (e.detail.index + 1 <= 9) {
      this.setData({
        [faceInfoVal]: e.detail.value,
        [faceInfoInd]: '0' + (e.detail.index + 1),
        [formFace]: '0' + (e.detail.index + 1),
        faceShow: false
      });
    } else {
      this.setData({
        [faceInfoVal]: e.detail.value,
        [faceInfoInd]: e.detail.index + 1,
        [formFace]: e.detail.index + 1,
        faceShow: false
      });
    }

  },
  // 婚姻状况弹出层打开
  setMaritalStatus: function() {
    this.setData({
      maritalShow: true
    });
  },
  // 婚姻状况弹出层关闭
  onMaritalClose: function() {
    this.setData({
      maritalShow: false
    });
  },
  // 婚姻状况选择确定
  onMaritalChange: function(e) {
    let maritalInfoVal = 'maritalInfo.value';
    let maritalInfoInd = 'maritalInfo.index';
    let formMarital = 'formData.marital';
    this.setData({
      [maritalInfoVal]: e.detail.value,
      [maritalInfoInd]: (e.detail.index + 1) * 10,
      [formMarital]: (e.detail.index + 1) * 10,
      maritalShow: false
    });
  },
  onAddressChange: function(ev) {
    let data = "formData.address";
    this.setData({
      [data]: ev.type == "blur" ? ev.detail.value : ev.detail
    });
  },
  setUnitPropertiesStatus: function() { // 工作性质弹出层打开
    this.setData({
      unitPropertiesShow: true
    });
  },
  onUnitPropertiesClose: function() { // 工作性质弹出层关闭
    this.setData({
      unitPropertiesShow: false
    });
  },
  // 工作性质选择确定
  onUnitPropertiesChange: function(e) {
    let unitPropertiesInfoVal = 'unitPropertiesInfo.value';
    let unitPropertiesInfoInd = 'unitPropertiesInfo.index';
    let formWork = 'formData.unitProperties';
    this.setData({
      [unitPropertiesInfoVal]: e.detail.value,
      [unitPropertiesInfoInd]: e.detail.index,
      [formWork]: e.detail.index  + 1,
      unitPropertiesShow: false
    });
    // console.log("工作性质",e)
  },

  setOccupationStatus: function() { // 职业弹出层打开
    this.setData({
      occupationShow: true
    });
  },
  onOccupationClose: function() { // 职业弹出层关闭
    this.setData({
      occupationShow: false
    });
  },
  // 职业选择确定  occupation
  onOccupationChange: function(e) {
    let occupationInfoVal = 'occupationInfo.value';
    let occupationInfoInd = 'occupationInfo.index';
    let formWork = 'formData.occupation';
    this.setData({
      [occupationInfoVal]: e.detail.value,
      [occupationInfoInd]: e.detail.index,
      [formWork]: e.detail.index + 1,
      occupationShow: false
    });
  },


  setProfessionStatus: function() { // 行业弹出层打开
    this.setData({
      professionShow: true
    });
  },
  onProfessionClose: function() { // 行业弹出层关闭
    this.setData({
      professionShow: false
    });
  },
  // 行业选择确定  occupation
  onProfessionChange: function(e) {
    let professionInfoVal = 'professionInfo.value';
    let professionInfoInd = 'professionInfo.index';
    let formWork = 'formData.profession';
    this.setData({
      [professionInfoVal]: e.detail.value,
      [professionInfoInd]: e.detail.index,
      [formWork]: e.detail.index + 1,
      professionShow: false
    });
    // console.log("行业",e)
  },

  // 就业情况弹出层打开
  setEmployStatus: function() {
    this.setData({
      workShow: true
    });
  },
  // 就业情况弹出层关闭
  onWorkClose: function() {
    this.setData({
      workShow: false
    });
  },
  // 就业情况选择确定
  onWorkChange: function(e) {
    // console.log('就业情况',e.detail.index)
    let that = this;
    let workInfoVal = 'workInfo.value';
    let workInfoInd = 'workInfo.index';
    let formWork = 'formData.employment';
    let empStatusExtraI = 'formData.empStatusExtraI';
    let empStatusExtraII = 'formData.empStatusExtraII';
    let noWorkHalfYearInfo = 'noWorkHalfYearInfo.value';
    let workTypeInfo = 'workTypeInfo.value';
    this.setData({
      [workInfoVal]: e.detail.value,
      [workInfoInd]: e.detail.index,
      [formWork]: e.detail.index + 1,
      workShow: false,
      onWorkTypeCellShow: e.detail.index == 0 ? true:false,
      noWorkTypeCellShow: e.detail.index == 1 ? true:false,
      [empStatusExtraI]: that.data.formData.employment == e.detail.index + 1 ? that.data.formData.empStatusExtraI :'' ,
      [empStatusExtraII]: that.data.formData.employment == e.detail.index + 1 ? that.data.formData.empStatusExtraII :'' ,
      [noWorkHalfYearInfo]:that.data.formData.employment == e.detail.index + 1 ? that.data.noWorkHalfYearInfo.value :'' ,
      [workTypeInfo]:that.data.formData.employment == e.detail.index + 1 ? that.data.workTypeInfo.value :'' ,
    });
  },
  // 在职弹出层打开
  setOnWorkStatus: function() {
    this.setData({
      onWorkShow: true
    });
  },
  // 就业情况弹出层关闭
  onWorkTypeClose: function() {
	  // console.log("在职情况关闭")
    this.setData({
      onWorkShow: false
    });
  },
  // 在职类型选择确定
  onWorkTypeChange: function(e) {
	  // console.log("在职情况确认")
    let workInfoVal = 'workTypeInfo.value';
    let workInfoInd = 'workTypeInfo.index';
    let formWork = 'formData.empStatusExtraI';
    this.setData({
      [workInfoVal]: e.detail.value,
      [workInfoInd]: e.detail.index,
      [formWork]: e.detail.index + 1,
      onWorkShow: false
    });
  },
    // 无业情况弹出层打开
    setNoWorkStatus: function() {
      this.setData({
        noWorkShow: true
      });
    },
    // 无业情况弹出层关闭
    noWorkClose: function() {
      this.setData({
        noWorkShow: false
      });
    },
    // 无业情况选择确定
    noWorkChange: function(e) {
      // console.log("无业情况确定",e)
      let workInfoVal = 'workTypeInfo.value';
      let workInfoInd = 'workTypeInfo.index';
      let formWork = 'formData.empStatusExtraI';
      this.setData({
        [workInfoVal]: e.detail.value,
        [workInfoInd]: e.detail.index,
        [formWork]: e.detail.index + 4,
        noWorkShow: false
      });
    },

     // 半年内失业弹出层打开
     setNoWorkHalfYearStatus: function() {
      this.setData({
        noWorkHalfYearShow: true
      });
    },
    // 半年内失业弹出层关闭
    noWorkHalfYearClose: function() {
      this.setData({
        noWorkHalfYearShow: false
      });
    },
    // 半年内失业选择确定
    noWorkHalfYearChange: function(e) {
      let workInfoVal = 'noWorkHalfYearInfo.value';
      let workInfoInd = 'noWorkHalfYearInfo.index';
      let formWork = 'formData.empStatusExtraII';
      this.setData({
        [workInfoVal]: e.detail.value,
        [workInfoInd]: e.detail.index,
        [formWork]: e.detail.index,
        noWorkHalfYearShow: false
      });
    },
	// 工作单位 
	onWorkUnitsChange: function(ev) {
		let data = "formData.workUnits"
		this.setData({
		  [data]: ev.type == "blur" ? ev.detail.value : ev.detail
		});
	},
	// 工作职位 
	onWorkPositionChange: function(ev) {
		let data = "formData.workPosition"
		this.setData({
		  [data]: ev.type == "blur" ? ev.detail.value : ev.detail
		});
	},
	// 下岗时长 
	onLossDurationChange: function(ev) {
		let data = "formData.lossDuration"
		this.setData({
		  [data]: ev.type == "blur" ? ev.detail.value : ev.detail
		});
	},
  // 下岗原因收缩面板打开
  setJobUnitsOrWhy: function(event) {
    this.setData({
      lossReasonInfo: event.detail
    });
  },
  // 健康状况详情收缩面板
  setHealthDetail: function(event) {
    this.setData({
      healthRemarkInfo: event.detail
    });
  },
  // 就业情况详情 
  setemploymentDetail: function(event) {
    this.setData({
      employmentDetailInfo: event.detail
    });
  },
  // 下岗原因内容
  onLossReasonChange: function(ev) {
    let data = "formData.lossReason"
    this.setData({
      [data]: ev.type == "blur" ? ev.detail.value : ev.detail
    });
  },
  
  // 健康状况详情内容
  onHealthDetailChange: function(ev) {
    let data = "formData.healthRemark"
    console.log(ev)
    this.setData({
      [data]: ev.type == "blur" ? ev.detail.value : ev.detail
    });
  },

  // employmentDetail 就业状况详请内容
  onEmploymentDetailChange: function(ev) {
    let data = "formData.employmentDetail"
    this.setData({
      [data]: ev.type == "blur" ? ev.detail.value : ev.detail
    });
  },

  // treatment:'', // 60岁退役士兵待遇
  //     socialAssistance:'', // 社会救助
  //     mainAppeal:'', // 主要诉求
  //     feedbackResults:'',// 反馈结果
  // 60岁退役士兵
  setTreatmentDetail: function(event) {
    this.setData({
      treatmentInfo: event.detail
    });
  },
  onTreatmentDetailChange: function(ev) {
    let data = "formData.treatment"
    this.setData({
      [data]: ev.type == "blur" ? ev.detail.value : ev.detail
    });
  },
  // 社会救助
  setSocialAssistanceDetail: function(event) {
    this.setData({
      socialAssistanceInfo: event.detail
    });
  },
  onSocialAssistanceDetailChange: function(ev) {
    let data = "formData.socialAssistance"
    this.setData({
      [data]: ev.type == "blur" ? ev.detail.value : ev.detail
    });
  },
  // 主要诉求
  setMainAppealDetail: function(event) {
    this.setData({
      mainAppealInfo: event.detail
    });
  },
  onMainAppealDetailChange: function(ev) {
    let data = "formData.mainAppeal"
    this.setData({
      [data]: ev.type == "blur" ? ev.detail.value : ev.detail
    });
  },
  // 反馈结果
  setFeedbackResultsDetail: function(event) {
    this.setData({
      feedbackResultsInfo: event.detail
    });
  },
  onFeedbackResultsDetailChange: function(ev) {
    let data = "formData.feedbackResults"
    this.setData({
      [data]: ev.type == "blur" ? ev.detail.value : ev.detail
    });
  },
  // 房屋状况及面积收缩面板控制
  setHouse: function(event) {
    // console.log('setHouse' ,event )
    let obj = '';
    let areaObj = '';
    if (event.detail == '') {
      let data = this.compare(this.data.houseResult);
      obj = data.join(',');
      var dataArr = [this.data.houseArea.house1, this.data.houseArea.house2, this.data.houseArea.house3, this.data.houseArea.house4, this.data.houseArea.house5, this.data.houseArea.house6, this.data.houseArea.house7, this.data.houseArea.house8];
      areaObj = dataArr.join(',');
    }
    let formHouse = 'formData.house';
    let formHouseArea = 'formData.houseArea';
    this.setData({
      houseActive: event.detail,
      [formHouse]: obj,
      [formHouseArea]: areaObj
    });
  },
  // 房间数
  setRoomBlur: function(ev) {
    let formInfo = 'formData.room';
    this.setData({
      [formInfo]: ev.detail.value
    })
  },
  setHouse1Blur: function(ev) {
    let houseArea = "houseArea.house1"
    this.setData({
      [houseArea]: ev.detail.value
    })
  },
  setHouse2Blur: function(ev) {
    let houseArea = "houseArea.house2"
    this.setData({
      [houseArea]: ev.detail.value
    })
  },
  setHouse3Blur: function(ev) {
    let houseArea = "houseArea.house3"
    this.setData({
      [houseArea]: ev.detail.value
    })
  },
  setHouse4Blur: function(ev) {
    let houseArea = "houseArea.house4"
    this.setData({
      [houseArea]: ev.detail.value
    })
  },
  setHouse5Blur: function(ev) {
    let houseArea = "houseArea.house5"
    this.setData({
      [houseArea]: ev.detail.value
    })
  },
  setHouse6Blur: function(ev) {
    let houseArea = "houseArea.house6"
    this.setData({
      [houseArea]: ev.detail.value
    })
  },
  setHouse7Blur: function(ev) {
    let houseArea = "houseArea.house7"
    this.setData({
      [houseArea]: ev.detail.value
    })
  },
  setHouse8Blur: function(ev) {
    let houseArea = "houseArea.house8"
    this.setData({
      [houseArea]: ev.detail.value
    })
  },
  compare: function(arr) {
    for (var i = 0; i < arr.length - 1; i++) {
      for (var j = 0; j < arr.length - i - 1; j++) {
        if (arr[j] > arr[j + 1]) { // 相邻元素两两对比
          var hand = arr[j];
          arr[j] = arr[j + 1];
          arr[j + 1] = hand;
        }
      }
    }
    return arr;
  },
  // 房屋状况及面积 复选框
  onHouseChange: function(event) {
    let dataEv = event.detail[event.detail.length - 1];
    if (dataEv == '0') {
      this.setData({
        houseResult: ['0']
      });
    } else {
      let data = event.detail;
      let index = data.indexOf('0');
      if (index > -1) {
        data.splice(index, 1);
      }
      // console.log(  '房屋',data)
      this.setData({
        houseResult: data
      });
    }
  },
  // 住房状况详情 
  setHousingStatusDetail: function(event) {
    this.setData({
      housingStatusInfo: event.detail
    });
  },
  // 住房状况详情情况
  onHousingStatusDetailChange: function (ev) {  
    let data = "formData.housingStatus"
    this.setData({
      [data]: ev.type == "blur" ? ev.detail.value : ev.detail
    });
  },
  // 就业需求收缩面板
  setJobDemandAct: function(event) {
    this.setData({
      jobDemandAct: event.detail
    });
  },
  // 就业需求内容
  onDemandChange: function(ev) {
    let data = "formData.jobDemand"
    this.setData({
      [data]: ev.type == "blur" ? ev.detail.value : ev.detail
    });
  },
  // 创业意向收缩面板
  setIntentionAct: function(event) {
    this.setData({
      intentionAct: event.detail
    });
  },
  // 创业意向内容
  onIntentionChange: function(ev) {
    let data = "formData.intention"
    this.setData({
      [data]: ev.type == "blur" ? ev.detail.value : ev.detail
    });
  },
	// 参加培训弹出层打开
	setTrain: function() {
	  this.setData({
	    trainShow: true
	  });
	},
	// 参加培训弹出层关闭
	onTrainClose: function() {
	  this.setData({
	    trainShow: false
	  });
	},
	// 参加培训选择确定
	onTrainChange: function(e) {
	  let trainVal = 'trainInfo.value';
	  let trainInd = 'trainInfo.index';
	  let formTrain = 'formData.train';
	  this.setData({
	    [trainVal]: e.detail.value,
	    [trainInd]: e.detail.index,
	    [formTrain]: e.detail.index,
	    trainShow: false
	  });
	},
	// 学校名称 
	onSchoolNameChange: function(ev) {
		let data = "formData.schoolName"
		this.setData({
		  [data]: ev.type == "blur" ? ev.detail.value : ev.detail
		});
	},
	// 就读专业 
	onMajorChange: function(ev) {
		let data = "formData.major"
		this.setData({
		  [data]: ev.type == "blur" ? ev.detail.value : ev.detail
		});
	},
	// 就读时间 
	onStudyDurationChange: function(ev) {
		let data = "formData.studyDuration"
		this.setData({
		  [data]: ev.type == "blur" ? ev.detail.value : ev.detail
		});
  },
  // 月生活补贴 
	onMonthlyAllowanceChange: function(ev) {
		let data = "formData.monthlyAllowance"
		let dataValue = ev.type == "blur" ? ev.detail.value : ev.detail
    dataValue = dataValue.replace(/[^\d.]/g, "");
		this.setData({
		  [data]: dataValue
		});
  },// 家庭年收入
	onHouseholdIncomeChange: function(ev) {
		let data = "formData.householdIncome"
		let dataValue = ev.type == "blur" ? ev.detail.value : ev.detail
    dataValue = dataValue.replace(/[^\d.]/g, "");
		this.setData({
		  [data]: dataValue
		});
  },// 家庭人口
	onFamilyPopulationChange: function(ev) {
    let data = "formData.familyPopulation"
    let dataValue = ev.type == "blur" ? ev.detail.value : ev.detail
    dataValue = dataValue.replace(/[^\d.]/g, "");
		this.setData({
		  [data]: dataValue
		});
  },
  // 个人年收入弹出层打开
  setIncome: function() {
    this.setData({
      incomeShow: true
    });
  },
  // 个人年收入弹出层关闭
  onIncomeClose: function() {
    this.setData({
      incomeShow: false
    });
  },
  // 个人年收入选择确定
  onIncomeChange: function(e) {
    let incomeInfoVal = 'incomeInfo.value';
    let incomeInfoInd = 'incomeInfo.index';
    let formIncome = 'formData.income';
    this.setData({
      [incomeInfoVal]: e.detail.value,
      [incomeInfoInd]: e.detail.index + 1,
      [formIncome]: e.detail.index + 1,
      incomeShow: false
    });
  },
  // 是否光荣牌弹出层打开
  setSlava: function() {
    this.setData({
      isSlavaShow: true
    });
  },
  // 是否光荣牌弹出层关闭
  onSlavaClose: function() {
    this.setData({
      isSlavaShow: false
    });
  },
  // 是否光荣牌选择确定
  onSlavaChange: function(e) {
    let isSlavaInfoVal = 'isSlavaInfo.value';
    let isSlavaInfoInd = 'isSlavaInfo.index';
    let formIsSlava = 'formData.isSlava';
    this.setData({
      [isSlavaInfoVal]: e.detail.value,
      [isSlavaInfoInd]: e.detail.index,
      [formIsSlava]: e.detail.index,
      isSlavaShow: false
    });
  },
  // 申请时间弹层打开
  setApplyTime: function() {
    this.setData({
      applyTimeShow: true
    })
  },
  // 申请时间弹层关闭
  onApplyClose: function() {
    this.setData({
      applyTimeShow: false
    })
  },
  // 申请时间 确定时间
  onApplyTimeChange: function(event) {
    let that = this;
    let formApply = "formData.applyTime";
    this.setData({
      applyCurrentDate: event.detail,
      minDate: new Date(1949, 10, 1).getTime(), // 1949-09-30凌晨24点整
      maxDate: new Date().getTime(),
      [formApply]: callTime.timestampFn(event.detail, 'Y/M/D'),
      applyTimeShow: false
    });
  },

/***
 * 
 * 
 * 
 * 
*/
  // 进京上访时间弹层打开
  setCapitalVisitTime: function() {
    this.setData({
      capitalVisitShow: true
    })
  },
  // 进京上访时间层关闭
  onCapitalTimeClose: function() {
    this.setData({
      capitalVisitShow: false
    })
  },
  // 上京时间 确定时间
  onCapitalTimeChange: function(event) {
    let that = this;
    let formCapital = "formData.capitalVisitTime";
    this.setData({
      capitalVisitDate: event.detail,
      minDate: new Date(1949, 10, 1).getTime(), // 1949-09-30凌晨24点整
      maxDate: new Date().getTime(),
      [formCapital]: callTime.timestampFn(event.detail, 'Y/M/D'),
      capitalVisitShow: false
    });
  },

    // 到省上访时间弹层打开
    setProvincialVisitTime: function() {
      this.setData({
        provincialVisitShow: true
      })
    },
    // 到省上访时间层关闭
    onProvincialTimeClose: function() {
      this.setData({
        provincialVisitShow: false
      })
    },
    // 到省时间 确定时间
    onProvincialTimeChange: function(event) {
      let that = this;
      let formCapital = "formData.provincialVisitTime";
      this.setData({
        provincialVisitDate: event.detail,
        minDate: new Date(1949, 10, 1).getTime(), // 1949-09-30凌晨24点整
        maxDate: new Date().getTime(),
        [formCapital]: callTime.timestampFn(event.detail, 'Y/M/D'),
        provincialVisitShow: false
      });
    },
    onProvincialNameChange: function(ev) {
      let data = "formData.provincialName";
      this.setData({
        [data]: ev.type == "blur" ? ev.detail.value : ev.detail
      });
    },
  
  // 悬挂时间弹层打开
  setHangTime: function() {
    this.setData({
      hangShow: true
    })
  },
  // 悬挂时间弹层关闭
  onHangClose: function() {
    this.setData({
      hangShow: false
    })
  },
  // 悬挂时间 确定时间
  onHangTimeChange: function(event) {
    let that = this;
    let formHang = "formData.hangTime";
    this.setData({
      hangCurrentDate: event.detail,
      minDate: new Date(1949, 10, 1).getTime(), // 1949-09-30凌晨24点整
      maxDate: new Date().getTime(),
      [formHang]: callTime.timestampFn(event.detail, 'Y/M/D'),
      hangShow: false
    });
  },
  // 是否孤老弹出层打开
  setOldAge: function() {
    this.setData({
      oldAgeShow: true
    });
  },
  // 是否孤老弹出层关闭
  onOldAgeClose: function() {
    this.setData({
      oldAgeShow: false
    });
  },
  // 是否孤老选择确定
  onOldAgeChange: function(e) {
    let oldAgeVal = 'oldAgeInfo.value';
    let oldAgeInd = 'oldAgeInfo.index';
    let formOldAge = 'formData.oldAge';
    this.setData({
      [oldAgeVal]: e.detail.value,
      [oldAgeInd]: e.detail.index,
      [formOldAge]: e.detail.index,
      oldAgeShow: false
    });
  },
  // 社会救助收缩面板
  setAssis: function(event) {
    this.setData({
      assisActive: event.detail
    })
  },
  //社会救助多选
  onAssisChange: function(event) {
    let dataEv = event.detail[event.detail.length - 1];
    if (dataEv == '0') {
      this.setData({
        assisResult: ['0'],
      });
    } else {
      let data = event.detail;
      let index = data.indexOf('0');
      if (index > -1) {
        data.splice(index, 1);
      }
      this.setData({
        assisResult: data
      });
    }
    let formAssis = "formData.assis";
    let assisData = this.compare(this.data.assisResult);
    let obj = assisData.join(',');
    this.setData({
      [formAssis]: obj
    });
  },
  // 子女情况 收缩面板
  setChildrenAct: function(event) {
    this.setData({
      childrenAct: event.detail
    })
  },
  // 子女情况内容
  onChildrenChange: function(event) {
    let formInfo = 'formData.children';
    this.setData({
      [formInfo]: event.type == "blur" ? event.detail.value : event.detail
    });
  },
  capitalVisitSelect: function(event) {
    let formInfor = 'formData.capitalVisitFlag';
    // this.setData({
    //   [formInfor]:event.detail
    // })
  },
	// 进京上访回访情况 收缩面板
	setCapitalVisitAct: function(event) {
	  this.setData({
	    capitalVisitAct: event.detail
	  })
  },
  setVisitAct: function(event) {
	  this.setData({
	    visitAct: event.detail
	  })
  },
  
	// 进京上访回访情况内容
	onCapitalVisitChange: function(event) {
	  let formInfo = 'formData.capitalVisit';
	  this.setData({
	    [formInfo]: event.type == "blur" ? event.detail.value : event.detail
	  });
	},
	// 到省上访回访情况 收缩面板
	setProvincialVisitAct: function(event) {
	  this.setData({
	    provincialVisitAct: event.detail
	  })
  },
  // 到省上访单选
  provincialVisitSelect: function(event) {
    let formInfor = 'formData.provincialVisitFlag';
    // this.setData({
    //   [formInfor]:event.detail
    // })
  },
	// 到省上访回访情况内容
	onProvincialVisitChange: function(event) {
	  let formInfo = 'formData.provincialVisit';
	  this.setData({
	    [formInfo]: event.type == "blur" ? event.detail.value : event.detail
	  });
	},
  // 主要困难 收缩面板
  setMainDiffAct: function(event) {
    this.setData({
      mainDiffAct: event.detail
    })
  },
  // 主要困难 内容
  onMainDiffChange: function(event) {
    let formInfo = 'formData.mainDiff';
    this.setData({
      [formInfo]: event.type == "blur" ? event.detail.value : event.detail
    });
  },
  // 思想状况 收缩面板
  setThoughtAct: function(event) {
    this.setData({
      thoughtAct: event.detail
    })
  },
  // 思想状况 内容
  onThoughtChange: function(event) {
    let formInfo = 'formData.thought';
    this.setData({
      [formInfo]: event.type == "blur" ? event.detail.value : event.detail
    });
  },
  // 参加党组织活动情况 收缩面板
  setThePartyAct: function(event) {
    this.setData({
      thePartyAct: event.detail
    })
  },
  // 参加党组织活动情况 内容
  onThePartyChange: function(event) {
    let formInfo = 'formData.theParty';
    this.setData({
      [formInfo]: event.type == "blur" ? event.detail.value : event.detail
    });
  },
  // 参加公益活动情况 收缩面板
  setWelfareAct: function(event) {
    this.setData({
      welfareAct: event.detail
    })
  },
  // 参加公益活动情况 内容
  onWelfareChange: function(event) {
    let formInfo = 'formData.welfare';
    this.setData({
      [formInfo]: event.type == "blur" ? event.detail.value : event.detail
    });
  },
  // 服务事项主要内容 收缩面板
  setContentsAct: function(event) {
    this.setData({
      contentsAct: event.detail
    })
  },
  // 是否服务事项选择
  majorFlagChange: function(event) { 
    // majorFlag
    let formInfor = 'formData.majorFlag';
    this.setData({
      [formInfor]:event.detail
    })
  },
	// 人员现状弹出层打开
	setPersonalState: function() {
	  this.setData({
	    personalStateShow: true
	  });
	},
	// 人员现状弹出层关闭
	onPersonalStateClose: function() {
	  this.setData({
	    personalStateShow: false
	  });
	},
	// 人员现状选择确定
	onPersonalStateChange: function(e) {
	  let personalStateVal = 'personalStateInfo.value';
	  let personalStateInd = 'personalStateInfo.index';
	  let formPersonalState = 'formData.personalState';
	  this.setData({
	    [personalStateVal]: e.detail.value,
	    [personalStateInd]: e.detail.index,
	    [formPersonalState]: e.detail.index,
	    personalStateShow: false
	  });
	},
	// 供养情况 收缩面板
	setSupportAct: function(event) {
	  this.setData({
	    supportAct: event.detail
	  })
	},
	// 供养情况内容
	onSupportChange: function(event) {
	  let formInfo = 'formData.support';
	  this.setData({
	    [formInfo]: event.type == "blur" ? event.detail.value : event.detail
	  });
	},
	// 退役方式 收缩面板
	setQuitTypeAct: function(event) {
	  this.setData({
	    quitTypeAct: event.detail
	  })
	},
	// 退役方式内容
	onQuitTypeChange: function(event) {
	  let formInfo = 'formData.quitType';
	  this.setData({
	    [formInfo]: event.type == "blur" ? event.detail.value : event.detail
	  });
	},
	// 问题1 收缩面板   有没有外出其他城市打工经验？
	setQuestion1Act: function(event) {
	  this.setData({
	    question1Act: event.detail
	  })
	},
	// 问题1内容
	onQuestion1Change: function(event) {
	  let formInfo = 'formData.question1';
	  this.setData({
	    [formInfo]: event.type == "blur" ? event.detail.value : event.detail
	  });
	},
	// 问题2 收缩面板    你选择就业城市重点考虑因素？
	setQuestion2Act: function(event) {
	  this.setData({
	    question2Act: event.detail
	  })
	},
	// 问题2内容
	onQuestion2Change: function(event) {
	  let formInfo = 'formData.question2';
	  this.setData({
	    [formInfo]: event.type == "blur" ? event.detail.value : event.detail
	  });
	},
	// 问题3 收缩面板  你找一份工作大概多长时间，从什么渠道找？
	setQuestion3Act: function(event) {
	  this.setData({
	    question3Act: event.detail
	  })
	},
	// 问题3内容
	onQuestion3Change: function(event) {
	  let formInfo = 'formData.question3';
	  this.setData({
	    [formInfo]: event.type == "blur" ? event.detail.value : event.detail
	  });
	},
	// 问题4 收缩面板 你想从事的行业？理想的年薪？
	setQuestion4Act: function(event) {
	  this.setData({
	    question4Act: event.detail
	  })
	},
	// 问题4内容
	onQuestion4Change: function(event) {
	  let formInfo = 'formData.question4';
	  this.setData({
	    [formInfo]: event.type == "blur" ? event.detail.value : event.detail
	  });
	},
  // 走访状态 弹出层打开
  setVisit: function() {
    this.setData({
      visitShow: true
    });
  },
  // 走访状态 弹出层关闭
  onVisitClose: function() {
    this.setData({
      visitShow: false
    });
  },
  // 走访状态 选择确定
  onVisitChange: function(e) {
    let visitVal = 'visitInfo.value';
    let visitInd = 'visitInfo.index';
    let formVisit = 'formData.visit';
    this.setData({
      [visitVal]: e.detail.value,
      [visitInd]: e.detail.index + 1,
      [formVisit]: e.detail.index + 1,
      visitShow: false
    });
  },

  // 走访形式 弹出层打开
  setVisitType: function () {
    this.setData({
      typeShow: true
    });
  },
  // 走访形式 弹出层关闭
  onTypeClose: function () {
    this.setData({
      typeShow: false
    });
  },
  // 走访形式 选择确定
  onTypeChange: function (e) {
    let visitVal = 'typeInfo.value';
    let visitInd = 'typeInfo.index';
    let formVisit = 'formData.visitType';
    this.setData({
      [visitVal]: e.detail.value,
      [visitInd]: e.detail.index + 1,
      [formVisit]: e.detail.index + 1,
      typeShow: false
    });
  },

  // 是否有重大事故 弹出层打开
  setAccident: function() {
    this.setData({
      accidentShow: true
    });
  },
  // 是否有重大事故 弹出层关闭
  onAccidentClose: function() {
    this.setData({
      accidentShow: false
    });
  },
  // 是否有重大事故 选择确定
  onAccidentChange: function(e) {
    let accidentVal = 'accidentInfo.value';
    let accidentInd = 'accidentInfo.index';
    let formAccident = 'formData.accident';
    this.setData({
      [accidentVal]: e.detail.value,
      [accidentInd]: e.detail.index,
      [formAccident]: e.detail.index,
      accidentShow: false
    });
  },
  // 重大事故详情 收缩面板
  setAccDetaAct: function(event) {
    this.setData({
      accDetaAct: event.detail
    })
  },
  // 重大事故详情 内容
  onAccDetaChange: function(event) {
    let formInfo = 'formData.accDeta';
    this.setData({
      [formInfo]: event.type == "blur" ? event.detail.value : event.detail
    });
  },
  // 是否有慰问物资 弹出层打开
  setSupplies: function () {
    this.setData({
      suppliesShow: true
    });
  },
  // 是否有慰问物资 弹出层关闭
  onSuppliesClose: function () {
    this.setData({
      suppliesShow: false
    });
  },
  // 是否有慰问物资 选择确定
  onSuppliesChange: function (e) {
    let accidentVal = 'suppliesInfo.value';
    let accidentInd = 'suppliesInfo.index';
    let formAccident = 'formData.sympathySupplies';
    this.setData({
      [accidentVal]: e.detail.value,
      [accidentInd]: e.detail.index,
      [formAccident]: e.detail.index,
      suppliesShow: false
    });
  },
  // 慰问物资详情 收缩面板
  setSuppliesAct: function (event) {
    this.setData({
      suppliesAct: event.detail
    })
  },
  // 慰问物资详情 内容
  onSupDataChange: function (event) {
    let formInfo = 'formData.suppliesContent';
    this.setData({
      [formInfo]: event.type == "blur" ? event.detail.value : event.detail
    });
  },
  // 物资合计
  onMoneyChange: function (ev) {
    let formInfo = 'formData.suppliesMoney';
    let dataValue = ev.type == "blur" ? ev.detail.value : ev.detail
    dataValue = dataValue.replace(/[^\d.]/g, "");
    this.setData({
      [formInfo]: dataValue
    });
  },
  /**
   * 身份证号输入  失去焦点  获取采集表数据  回显部分数据
   */
  onBlurGetInfo: function(event) {
    if (!this.data.flag) {
      return;
    }
    let that = this;
    let params = {
      cardId: event.detail.value
    }
    if( !that.data.formData.name ) {
      return false
    }
    // call.postData('/admin/personalFilesBase/detail', params, function(res) {
    call.getData('/admin/OnePersonOneFile/querySorlderRecorderByNamaAndCradId?name='+ that.data.formData.name + '&sfzhm=' + event.detail.value,  function(res) { //  请求成功
      if (res.code == 200 && res.data) {
        that.onCardIdInit(res.data.baseInfoVO);
        that.visitInfoReturn(res.data)
      } else {
        return;
      }
    }, function(req) {});
  },
  dateHandle(data) {
    if ( data && data.length > 0 ) {
      let yyyy =Number( data.substring(0,4))
      let mm = Number(data.substring(4,6) )
      let dd = Number(data.substring(6,8))
      return yyyy + "/"+ mm + "/" +dd
    }else{
      return data
    }
  },
  visitInfoReturn: function(data) {
    const that = this;
    // bjVisitTimeAll: '', // 进京上访时间
    // gdVisitTimeAll: '', // 到省上访时间
    let bjTimeArr = [], gdTimeArr = [];
    if(data.bjHave && data.bjHave == 1 ) {
      let bjDateTimeArr = data.beijingtXinfangVOS;
      bjDateTimeArr.forEach(item => {
          bjTimeArr.push( that.dateHandle(item.time) )
      })
    }
      if(data.gdHave && data.gdHave == 1 ) {
      let gdDateTimeArr = data.guangdongXinfangVOS;
      gdDateTimeArr.forEach(item => {
          gdTimeArr.push( that.dateHandle(item.time) )
      })
    }
    that.setData({
      bjHave: (data.bjHave === 0 || data.bjHave === 1 )?  String(data.bjHave) : '', // 进京上访选择
      gdHave: (data.gdHave === 0 || data.gdHave === 1 )?  String(data.gdHave) : '', // 进京上访选择
      bjVisitTimeAll: bjTimeArr.join(),
      gdVisitTimeAll: gdTimeArr.join()
    })
  },
  onCardIdInit: function(data) {   // 数据回显
    // console.log(dataAll)
    // let data = dataAll.baseInfoVO

    let houseResultArr, hourseAreaArr, assisArr;
    let healthData = 'healthInfo.value';
    let faceData = 'faceInfo.value';
    let marStateData = 'maritalInfo.value';
    let personalStateData = 'personalStateInfo.value'; // 人员现状
    let workInfoData = 'workInfo.value';
    let unitPropertiesInfoData = 'unitPropertiesInfo.value';
    let occupationInfoData = 'occupationInfo.value';
    let professionInfoData = 'professionInfo.value';
    let incomeData = 'incomeInfo.value';
    let slavaData = 'isSlavaInfo.value';
    let oldAgeData = 'oldAgeInfo.value';
    let trainData = 'trainInfo.value'; // 参加培训
    let visitInfoData = 'visitInfo.value';
    let accidentInfoData = 'accidentInfo.value';
    let suppliesInfoData = 'suppliesInfo.value';
    let typeInfoData = 'typeInfo.value';
    let workTypeInfoData = 'workTypeInfo.value';
    let noWorkHalfYearInfoData = 'noWorkHalfYearInfo.value';
    // noWorkHalfYearInfo
    let reg = new RegExp("[\\u4E00-\\u9FFF]+","g");
    // console.log(this.data.formData)
    if (data && data.houseState && !reg.test( data.houseState ) ) {
      houseResultArr = data.houseState.split(',');
    }
    if (data && data.houseArea) {
      hourseAreaArr = data.houseArea.split(',');
      this.setData({
        houseArea: {
          house1: hourseAreaArr[0],
          house2: hourseAreaArr[1],
          house3: hourseAreaArr[2],
          house4: hourseAreaArr[3],
          house5: hourseAreaArr[4],
          house6: hourseAreaArr[5],
          house7: hourseAreaArr[6],
          house8: hourseAreaArr[7]
        }
      })
    }
    if (data.helpStatus ) {
      assisArr = data.helpStatus.split(',');
    }
    let regNum = /\d/;
    if (data) {
      this.setData({
        [healthData]: callTime.makeSelectOrChecked(data.health || '', callTime.dataDictionary().healthStatus),
        [faceData]: callTime.makeSelectOrChecked(data.zzmm || '', callTime.dataDictionary().politicalStatus),
        [marStateData]: callTime.makeSelectOrChecked(data.marState || '', callTime.dataDictionary().marriageStatus),
        [personalStateData]: callTime.makeSelectOrChecked(String(data.personalState) || '', callTime.dataDictionary().personalStateStatus),
        [workInfoData]: callTime.makeSelectOrChecked(data.empStatus || '', callTime.dataDictionary().empStatus),
        [workTypeInfoData]:callTime.makeSelectOrChecked(data.empStatusExtraI || '', callTime.dataDictionary().empStatusExtraI),
        [unitPropertiesInfoData]:callTime.makeSelectOrChecked(data.unitProperties || '', callTime.dataDictionary().unitPropertiesStatus),
        [occupationInfoData]:callTime.makeSelectOrChecked(data.occupation || '', callTime.dataDictionary().occupationStatus),
        [professionInfoData]:callTime.makeSelectOrChecked(data.profession || '', callTime.dataDictionary().professionStatus),
        [incomeData]: callTime.makeSelectOrChecked(data.incomeStatus || '', callTime.dataDictionary().incomeStatus),
        [slavaData]: this.yesNoDataHandle(data.gloryCard),
        [oldAgeData]:this.yesNoDataHandle( data.alold),
        [noWorkHalfYearInfoData]: this.yesNoDataHandle(data.empStatusExtraII),
				[trainData]: callTime.makeSelectOrChecked(String(data.train) || '', callTime.dataDictionary().trainStatus),
        [visitInfoData]: data.recStatus == 1 ? '在办' : data.recStatus == 2 ? '已办' : '',
        [accidentInfoData]: this.yesNoDataHandle(data.majorAccident) ,
        [suppliesInfoData]: this.yesNoDataHandle(data.sympathySupplies),
        [typeInfoData]: data.visitType == 1 ? '现场走访' : data.visitType == 2 ? '电话走访' : '',
        photoArray: data.spotImages || [],
        houseResult: houseResultArr || [],
        assisResult: assisArr || [],
        onWorkTypeCellShow: data.empStatus == 1 ? true:false ,
        noWorkTypeCellShow: data.empStatus == 2 ? true:false ,
        formData: {
          name: this.data.formData.name || data.name, // 姓名 @TODO 注意回填不能覆盖已填入数据
          cardId: data.cardId, // 身份证
          phone: this.data.formData.phone || data.tel || '', // 联系电话
					personalTel: this.data.formData.personalTel || data.personalTel || '', // 本人电话
          health: data.health || '', // 健康状况
          face: data.zzmm || '', //  政治面貌
          marital: data.marState || '', //  婚姻状况
          address: this.data.formData.address || data.address || '', // 家庭住址
          employment: data.empStatus || '', // 就业情况
          empStatusExtraI:data.empStatusExtraI || '', // 就业情况1级
          empStatusExtraII:(data.empStatusExtraII === "0" || data.empStatusExtraII === "1") ? Number( data.empStatusExtraII ) : '', // 无业情况
          unitProperties: data.unitProperties || '', // 工作单位性质
          occupation: data.occupation || '', // 职业类型
          profession: data.profession || '', // 从事行业
          workUnits: data.workSituation || '', // 工作单位
					workPosition: data.workPosition || '', // 工作职位
					lossDuration: data.lossDuration || '', // 下岗时长
					lossReason: data.lossReason || '', // 下岗原因
          room: data.roomNum || '', // 房间数
          house: reg.test( data.houseState ) ? '':data.houseState , // 住房状况 复选
          houseArea: data.hourseArea || '', // 住房面积 
          jobDemand: data.empDemand || '', //就业需求
          intention: data.entIntention || '', // 创业意向
          income: reg.test( data.incomeStatus ) ? '': data.incomeStatus, // 个人年收入
          isSlava: data.gloryCard || '', // 是否申请悬挂光荣牌
          applyTime: data.gloryApplyTime || '', // 申请时间
          hangTime: data.gloryUseTime || '', // 悬挂时间
          oldAge: reg.test( data.alold ) ? '' : data.alold , // 孤老情况
          train: data.train || '', // 培训情况
          schoolName: data.schoolName || '', // 学校名称
					major: data.major || '', // 就读专业
					studyDuration: data.studyDuration || '', // 就读时间
          assis: regNum.test( data.helpStatus ) ?  data.helpStatus : '', // 社会救助
          children: data.childStatus || '', // 子女情况
					capitalVisit: data.capitalVisit || '', // 进京上访回访情况
          provincialVisit: data.provincialVisit || '', // 到省上访回访情况
          capitalVisitFlag: (data.capitalVisitFlag === 0 || data.capitalVisitFlag === 1 )?  String(data.capitalVisitFlag) : '', // 进京上访选择
          capitalVisit: data.capitalVisit || '', // 进京上访回访情况
          capitalVisitTime: data.capitalVisitDate, // 进京上访时间
          provincialVisit: data.provincialVisit, // 到省上访回访情况
          provincialVisitFlag: (data.provincialVisitFlag === 0 || data.provincialVisitFlag === 1 ) ? String(data.provincialVisitFlag) : '', // 到省上访选择
          provincialVisitTime: data.provincialVisitDate, // 到省上访时间
          provincialName: data.provincialVisitAddress, // 到访省份名称
          // bjHave:  (data.bjHave === 0 || data.bjHave === 1 ) ? String(data.bjHave) : '', // 是否进京上访,
          // gdHave:  (data.gdHave === 0 || data.gdHave === 1 ) ? String(data.gdHave) : '', // 是否进京上访,
          mainDiff: data.majorDiff || '', // 主要困难
          thought: data.ideStatus || '', //思想状况
          theParty: data.joinParty || '', // 参加党组织活动
          welfare: data.joinPublic || '', // 参加公益活动
          majorFlag: (data.majorFlag === 0 || data.majorFlag === 1 ) ? String(data.majorFlag) : '', //服务事项开关
          contents: data.majorElements || [], // 主要内容
					personalState: reg.test( data.personalState ) ? '' : data.personalState || '', // 人员状态
					support: data.support || '', // 供养情况
					quitType: data.quitType || '', // 退役方式
					question1: data.question1 || '', // 问题1
					question2: data.question2 || '', // 问题2
					question3: data.question3 || '', // 问题3
					question4: data.question4 || '', // 问题4
          visit: data.recStatus || '', // 走访状态
          accident: data.majorAccident || '', //  是否重大事故
          accDeta: data.accidentContent || '', // 重大事故详情
          sympathySupplies: data.sympathySupplies || '', // 是否有慰问物资
          suppliesContent: data.suppliesContent || '', // 慰问物质详情
          suppliesMoney: data.suppliesMoney || '',// 慰问物资合计金额
          visitType: data.visitType,// 走访形式
          spotImages: data.spotImages,//现场照片
          employmentDetail: data.employment, // 就业情况详情
          familyPopulation:data.familyPopulation, // 家庭人口
          healthRemark: data.healthRemark, // 健康状况详情
          feedbackResults: data.feedbackResults, // 反馈结果
          householdIncome:data.householdIncome, // 家庭年收入
          housingStatus:data.housingStatus, // 住房状况
          mainAppeal:data.mainAppeal, // 主要诉求
          monthlyAllowance:data.monthlyAllowance, // 月生活补贴
          socialAssistance:data.socialAssistance, // 社会救助
          treatment:data.treatment, // 60岁待遇
            }
      });
    }
   

  },
  yesNoDataHandle(data) { // 是否回显处理
      if( data == 1 ) {
        return '是';
      }else if(data == 0) {
        return '否';
      }else {
        return '';
      }
  },

  // 442826195602292316

  onActiveChange:function(event){  //tab切换
    this.setData({
      addVisitActive: event.detail.index
    })
  },
  /**
   * 点击下一步
   */
  addStepNext: function() {
    let count = this.data.addVisitActive;
    if (count >= 2) return;
    count++;
    this.setData({
      addVisitActive: count
    })
  },
  /**
   * 提交
   */
  houseData() {
    let obj = '';
    let areaObj = '';
    
    let data = this.compare(this.data.houseResult);
    obj = data.join(',');
    var dataArr = [this.data.houseArea.house1, this.data.houseArea.house2, this.data.houseArea.house3, this.data.houseArea.house4, this.data.houseArea.house5, this.data.houseArea.house6, this.data.houseArea.house7, this.data.houseArea.house8];
    areaObj = dataArr.join(',');
    
    let formHouse = 'formData.house';
    let formHouseArea = 'formData.houseArea';
    this.setData({
      [formHouse]: obj,
      [formHouseArea]: areaObj
    });
  },
  addStepSubmit: function() {
    // console.log(this.data.formData.assis)
    console.log('formData',this.data.formData)
    // return
    let assisArr = [],assisArrNew=[];
    if( this.data.formData.assis.length > 0  ) {
      assisArr = this.data.formData.assis.split(',')
      assisArrNew = assisArr.filter((item) => {
        return  isNaN(Number(item)) == false
      })
    }
    this.data.formData.assis = assisArrNew.join(',');
    // console.log( assisArrNew )
    // return
    let that = this;
    that.houseData()
    let reg = new RegExp("[\\u4E00-\\u9FFF]+","g");
    if (!this.data.formData.name) {
      Toast('姓名不能为空！');
      return;
    }
    if (!this.data.formData.cardId) {
      Toast('身份证号不能为空！');
      return;
    }
    if (!this.data.formData.phone) {
      Toast('手机号不能为空！');
      return;
    }

    if (!this.data.formData.face || reg.test(this.data.formData.face) ) {
      Toast('政治面貌不能为空！');
      return;
    }
    if (!this.data.formData.marital || reg.test(this.data.formData.marital) ) {
      Toast('婚姻状态不能为空！');
      return;
    }
    if (!this.data.formData.address) {
      Toast('家庭住址不能为空！');
      return;
    }
    if (!this.data.workInfo.value) {
      Toast('就业情况不能为空！');
      return;
    }

    // let formWork = 'formData.employment';
    // let empStatusExtraI = 'formData.empStatusExtraI';
    // let empStatusExtraII = 'formData.empStatusExtraII';

    if( this.data.formData.employment == 1 ) { 
       if( this.data.formData.empStatusExtraI && this.data.formData.empStatusExtraI > 0 && this.data.formData.empStatusExtraI < 4  ){}else{
        Toast('在职情况不能为空！');
        return;
       }
    }
    if( this.data.formData.employment == 2 ) { 
      if( this.data.formData.empStatusExtraI && this.data.formData.empStatusExtraI > 3  ){}else{
       Toast('无业情况不能为空！');
       return;
      }
      if( this.data.formData.empStatusExtraII === 0 || this.data.formData.empStatusExtraII === 1  ){}else{
        Toast('半年内失业情况不能为空！');
        return;
       }
   }
    if (!this.data.formData.income) {
      Toast('个人年收入不能为空！');
      return;
    }
    if (!this.data.isSlavaInfo.value) {
      Toast('是否申请悬挂光荣牌不能为空！');
      return;
    }
    if (!this.data.oldAgeInfo.value) {
      Toast('孤老情况不能为空！');
      return;
    }
    // majorFlag
    if (!this.data.formData.majorFlag) {
      Toast('服务事项选择不能为空');
      return;
    }
    if (this.data.formData.majorFlag == 1 ) {
      if( !this.data.formData.contents[0].content ) {
        Toast('服务事项内容不能为空');
        return;
      }
    }

    if (!this.data.formData.visit || reg.test(this.data.formData.visit)) {
      Toast('走访状态不能为空！');
      return;
    }
    if (!this.data.formData.visitType ||  reg.test(this.data.formData.visitType)) {
      Toast('走访形式不能为空！');
      return;
    } else if (this.data.formData.visitType == 1) {
      let spotImages = "formData.spotImages";
      this.setData({
        [spotImages]: that.data.photoArray
      })
      if (this.data.formData.spotImages.length < 1) {
        Toast('现场照片不能为空！');
        return;
      }
    }
    // return;
    let params = {
      name: this.data.formData.name,
      cardId: this.data.formData.cardId,
      tel: this.data.formData.phone,
			personalTel: this.data.formData.personalTel,
      zzmm: this.data.formData.face,
      health: this.data.formData.health,
      marState: this.data.formData.marital,
      address: this.data.formData.address,
      empStatus: reg.test( this.data.formData.employment ) ? '' : this.data.formData.employment,
      empStatusExtraI: this.data.formData.empStatusExtraI,
      empStatusExtraII: this.data.formData.empStatusExtraII,
      profession: this.data.formData.profession,
      occupation: this.data.formData.occupation,
      unitProperties: this.data.formData.unitProperties,
      workSituation: this.data.formData.workUnits,
			workPosition: this.data.formData.workPosition, // 工作职位
			lossDuration: this.data.formData.lossDuration, // 下岗时长
			lossReason: this.data.formData.lossReason, // 下岗原因
      houseState:reg.test( this.data.formData.house ) ? '' : this.data.formData.house,
      houseArea: this.data.formData.houseArea,
      roomNum: this.data.formData.room,
      empDemand: this.data.formData.jobDemand,
      entIntention: this.data.formData.intention,
      incomeStatus: this.data.formData.income,
      gloryCard: this.data.formData.isSlava,
      gloryApplyTime: this.data.formData.applyTime,
      gloryUseTime: this.data.formData.hangTime,
      alold: this.data.formData.oldAge,
      train: this.data.formData.train,
			schoolName: this.data.formData.schoolName, // 学校名称
			major: this.data.formData.major, // 就读专业
			studyDuration: this.data.formData.studyDuration, // 就读时间
      helpStatus: this.data.formData.assis,
      childStatus: this.data.formData.children,
      capitalVisitFlag: this.data.formData.capitalVisitFlag, // 进京上访选择
      capitalVisit:  this.data.formData.capitalVisit || '', // 上访回访情况
      capitalVisitDate:this.data.formData.capitalVisitFlag == 1 ? this.data.formData.capitalVisitTime : '', // 进京上访时间
      provincialVisit:this.data.formData.provincialVisitFlag == 1 ? this.data.formData.provincialVisit : '', // 到省上访回访情况
      provincialVisitFlag: this.data.formData.provincialVisitFlag, // 到省上访选择
      provincialVisitDate: this.data.formData.provincialVisitFlag == 1 ? this.data.formData.provincialVisitTime : '', // 到省上访时间
      provincialVisitAddress: this.data.formData.provincialVisitFlag == 1 ? this.data.formData.provincialName : '', // 到访省份名称
      majorDiff: this.data.formData.mainDiff,
      ideStatus: this.data.formData.thought,
      joinParty: this.data.formData.theParty,
      joinPublic: this.data.formData.welfare,
      majorFlag: this.data.formData.majorFlag,
      majorElements: this.data.formData.majorFlag == 1 ? this.data.formData.contents : '',
			personalState: this.data.formData.personalState, // 人员状态
			support: this.data.formData.support, // 供养情况
			quitType: this.data.formData.quitType, // 退役方式
			question1: this.data.formData.question1 || '', // 问题1
			question2: this.data.formData.question2 || '', // 问题2
			question3: this.data.formData.question3 || '', // 问题3
			question4: this.data.formData.question4 || '', // 问题4
      recStatus: this.data.formData.visit,
      majorAccident: this.data.formData.accident, //  是否重大事故
      accidentContent: this.data.formData.accDeta, // 重大事故详情
      sympathySupplies: this.data.formData.sympathySupplies, // 是否有慰问物资
      suppliesContent: this.data.formData.suppliesContent, // 慰问物质详情
      suppliesMoney: this.data.formData.suppliesMoney,// 慰问物资合计金额
      visitType: this.data.formData.visitType,// 走访形式
      spotImages: this.data.formData.spotImages,//现场照片
      employment: this.data.formData.employmentDetail, // 就业情况详情
      familyPopulation:this.data.formData.familyPopulation, // 家庭人口
      healthRemark: this.data.formData.healthRemark, // 健康状况详情
      feedbackResults: this.data.formData.feedbackResults, // 反馈结果
      householdIncome: this.data.formData.householdIncome, // 家庭年收入
      housingStatus:this.data.formData.housingStatus, // 住房状况
      mainAppeal:this.data.formData.mainAppeal, // 主要诉求
      monthlyAllowance:this.data.formData.monthlyAllowance, // 月生活补贴
      socialAssistance:this.data.formData.socialAssistance, // 社会救助
      treatment:this.data.formData.treatment, // 60岁待遇
    };
   

    let postUrl = '';
    if (this.data.flag) {
      // 提交新增数据
      postUrl = '/admin/personalFilesRecord/create';
    } else {
      // 编辑
      postUrl = '/admin/personalFilesRecord/update';
      params.fileGuid = this.data.fileGuid;
      // params.visitTime = this.data.visitTime;
    }
    wx.showLoading();
    call.postData(postUrl, params, function (res) {
      if (res.code == 200) {
				let pages =getCurrentPages();//当前页面栈
				if (pages.length >1) {
					let beforePage = pages[pages.length- 2];//获取上一个页面实例对象

          if( beforePage.shows ) {
            beforePage.shows();//触发父页面中的方法
          }
				}
        wx.hideLoading();
        wx.navigateBack();
				
        // wx.navigateTo({
        //   url: '/pages/interview/index?tabs=0'
        // })
      } else {
        Toast(res.msg)
        wx.hideLoading();
      }
    }, function (req) { });



  }
})