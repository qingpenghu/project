const call = require("../../utils/request.js");
const callTime = require("../../utils/util.js");
const app = getApp();
import Notify from '../../vant-weapp/notify/notify';
Page({

  /**
   * 页面的初始数据
   */
  data: {
    detailsId: '',
    detailCard: '',
    addVisitActive: 0,
    healthArray: ['良好', '一般', '差'],
    healthShow: false,
    healthInfo: {
      index: '',
      value: ''
    },
    faceArray: ['中国共产党党员', '中国共产党预备党员', '中国共产主义青年团团员', '中国国民党革命委员会会员', '中国民主同盟盟员', '中国民主建国会会员', '中国民主促进会会员', '中国农工民主党党员', '中国致公党党员', '九三学社社员', '台湾民主自治同盟盟员', '无党派民主人士', '群众'],
    faceShow: false,
    faceInfo: {
      index: '',
      value: ''
    },
    maritalArray: ['未婚', '已婚', '丧偶', '离婚'],
    maritalShow: false,
    maritalInfo: {
      index: '',
      value: ''
    },
    workArray: ['无', '在职', '下岗', '失业', '无业', '离休', '退休', '创业', '务农', '学生'],
    workShow: false,
    workInfo: {
      index: '',
      value: ''
    },
    jobUnitsName: '',
    houseActive: '',
    houseResult: [],
    houseArea: {
      house1: '',
      house2: '',
      house3: '',
      house4: '',
      house5: '',
      house6: '',
      house7: '',
      house8: ''
    },
    jobDemandAct: '',
    intentionAct: '',
    incomeArray: ['0-10000元', '10001-30000元', '30001-50000元', '50001-120000元', '120000元以上'],
    incomeShow: false,
    incomeInfo: {
      index: '',
      value: ''
    },
    oldAgeArray: ['否', '是'],
    oldAgeShow: false,
    oldAgeInfo: {
      index: '',
      value: ''
    },
    isSlavaArray: ['否', '是'],
    isSlavaShow: false,
    isSlavaInfo: {
      index: '',
      value: ''
    },
    applyTimeShow: false,
    hangShow: false,
    applyCurrentDate: new Date().getTime(),
    minDate: new Date(1949, 10, 1).getTime(), // 1949-09-30凌晨24点整
    maxDate: new Date().getTime(),
    hangCurrentDate: new Date().getTime(),
    formatter(type, value) {
      if (type === 'year') {
        return `${value}年`;
      } else if (type === 'month') {
        return `${value}月`;
      }
      return value;
    },
    assisActive: '',
    assisResult: [],
    childrenAct: '',
    mainDiffAct: '',
    thoughtAct: '',
    thePartyAct: '',
    welfareAct: '',
    contentsAct: '',
    visitArray: ['在办', '已办'],
    visitShow: false,
    visitInfo: {
      index: '',
      value: ''
    },
    accidentArray: ['否', '是'],
    accidentShow: false,
    accidentInfo: {
      index: '',
      value: ''
    },
    accDetaAct: '',
    suppliesArray: ['否', '是'],
    suppliesShow: false,
    suppliesInfo: {
      index: '',
      value: ''
    },
    suppliesAct: '',
    formData: {
      name: '', // 姓名
      cardId: '', // 身份证
      phone: '', // 联系电话
      health: '', // 健康状况
      face: '', //  政治面貌
      marital: '', //  婚姻状况
      address: '', // 家庭住址
      employment: '', // 就业情况
      workUnits: '', // 工作单位或下岗
      room: '', // 房间数
      house: '', // 住房状况 复选
      houseArea: '', // 住房面积 
      jobDemand: '', //就业需求
      intention: '', // 创业意向
      income: '', // 个人年收入
      isSlava: '', // 是否申请悬挂光荣牌
      applyTime: '', // 申请时间
      hangTime: '', // 悬挂时间
      oldAge: '', // 孤老情况
      assis: '', // 社会救助
      children: '', // 子女情况
      mainDiff: '', // 主要困难
      thought: '', //思想状况
      theParty: '', // 参加党组织活动
      welfare: '', // 参加公益活动
      contents: '', // 主要内容
      visit: '', // 走访状态
      accident: '', //  是否重大事故
      accDeta: '', // 重大事故详情
      sympathySupplies:"", // 是否有慰问物资
      suppliesContent:'', // 慰问物质详情
      suppliesMoney:''// 慰问物资合计金额

    }

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(e) {
    // 获取url中file_guid的值
    let isId = e.id.trim();
    let isCardId = e.cardId.trim();
    this.setData({
      detailsId: isId,
      detailCard: isCardId
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {
    this.getData();
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  // 工作单位或下岗原因收缩面板打开
  setJobUnitsOrWhy: function(event) {
    this.setData({
      jobUnitsName: event.detail
    });
  },

  // 房屋状况及面积收缩面板控制
  setHouse: function(event) {
    this.setData({
      houseActive: event.detail
    });
  },


  // 就业需求收缩面板
  setJobDemandAct: function(event) {
    this.setData({
      jobDemandAct: event.detail
    });
  },
  // 创业意向收缩面板
  setIntentionAct: function(event) {
    this.setData({
      intentionAct: event.detail
    });
  },

  // 社会救助收缩面板
  setAssis: function(event) {
    this.setData({
      assisActive: event.detail
    })
  },
  
  // 子女情况 收缩面板
  setChildrenAct: function(event) {
    this.setData({
      childrenAct: event.detail
    })
  },

  // 主要困难 收缩面板
  setMainDiffAct: function(event) {
    this.setData({
      mainDiffAct: event.detail
    })
  },
 
  // 思想状况 收缩面板
  setThoughtAct: function(event) {
    this.setData({
      thoughtAct: event.detail
    })
  },
 
  // 参加党组织活动情况 收缩面板
  setThePartyAct: function(event) {
    this.setData({
      thePartyAct: event.detail
    })
  },
  
  // 参加公益活动情况 收缩面板
  setWelfareAct: function(event) {
    this.setData({
      welfareAct: event.detail
    })
  },
  
  // 服务事项主要内容 收缩面板
  setContentsAct: function(event) {
    this.setData({
      contentsAct: event.detail
    })
  },
 
  // 重大事故详情 收缩面板
  setAccDetaAct: function(event) {
    this.setData({
      accDetaAct: event.detail
    })
  },
  
  // 慰问物资详情 收缩面板
  setSuppliesAct: function (event) {
    this.setData({
      suppliesAct: event.detail
    })
  },
  
  

  /**
   * 获取采集表数据  回显部分数据
   */
  getData: function() {
    let that = this;
    let params = {
      fileGuid: this.data.detailsId
    }
    call.postData('/admin/personalFilesRecord/detail', params, function(res) {
      if (res.code == 200 && res.data) {
        that.onCardIdInit(res.data);
      } else {
        return;
      }
    }, function(req) {});
  },
  onCardIdInit: function(data) {   // 数据回显
    let houseResultArr, hourseAreaArr, assisArr;
    let healthData = 'healthInfo.value';
    let faceData = 'faceInfo.value';
    let marStateData = 'maritalInfo.value';
    let workInfoData = 'workInfo.value';
    let incomeData = 'incomeInfo.value';
    let slavaData = 'isSlavaInfo.value';
    let oldAgeData = 'oldAgeInfo.value';
    let visitInfoData = 'visitInfo.value';
    let accidentInfoData = 'accidentInfo.value';
    let suppliesInfoData = 'suppliesInfo.value';
    
    if (data.houseState) {
      houseResultArr = data.houseState.split(',');
    }
    if (data.houseArea) {
      hourseAreaArr = data.houseArea.split(',');
      this.setData({
        houseArea: {
          house1: hourseAreaArr[0],
          house2: hourseAreaArr[1],
          house3: hourseAreaArr[2],
          house4: hourseAreaArr[3],
          house5: hourseAreaArr[4],
          house6: hourseAreaArr[5],
          house7: hourseAreaArr[6],
          house8: hourseAreaArr[7]
        }
      })
    }
    if (data.helpStatus) {
      assisArr = data.helpStatus.split(',');
    }
    this.setData({
      [healthData]: callTime.makeSelectOrChecked(data.health || '', callTime.dataDictionary().healthStatus),
      [faceData]: callTime.makeSelectOrChecked(data.zzmm || '', callTime.dataDictionary().politicalStatus),
      [marStateData]: callTime.makeSelectOrChecked(data.marState || '', callTime.dataDictionary().marriageStatus),
      [workInfoData]: callTime.makeSelectOrChecked(data.empStatus || '', callTime.dataDictionary().empStatus),
      [incomeData]: callTime.makeSelectOrChecked(data.incomeStatus || '', callTime.dataDictionary().incomeStatus),
      [slavaData]: data.gloryCard == 1 ? '是' : '否',
      [oldAgeData]: data.alold == 1 ? '是' : '否',
      [visitInfoData]: data.recStatus == 1 ? '在办' : data.recStatus == 1 ? '已办' : '',
      [accidentInfoData]: data.majorAccident == 1 ? '是' : '否',
      [suppliesInfoData]: data.sympathySupplies == 1 ? '是' : '否',
      houseResult: houseResultArr,
      assisResult: assisArr,
      formData: {
        name: data.name, // 姓名
        cardId: data.cardId, // 身份证
        phone: data.tel || '', // 联系电话
        health: data.health || '', // 健康状况
        face: data.zzmm || '', //  政治面貌
        marital: data.marState || '', //  婚姻状况
        address: data.address || '', // 家庭住址
        employment: data.empStatus || '', // 就业情况
        workUnits: data.workSituation || '', // 工作单位或下岗
        room: data.roomNum || '', // 房间数
        house: data.houseState || '', // 住房状况 复选
        houseArea: data.hourseArea || '', // 住房面积 
        jobDemand: data.empDemand || '', //就业需求
        intention: data.entIntention || '', // 创业意向
        income: data.incomeStatus || '', // 个人年收入
        isSlava: data.gloryCard || '', // 是否申请悬挂光荣牌
        applyTime: data.gloryApplyTime || '', // 申请时间
        hangTime: data.gloryUseTime || '', // 悬挂时间
        oldAge: data.alold || '', // 孤老情况
        assis: data.helpStatus || '', // 社会救助
        children: data.childStatus || '', // 子女情况
        mainDiff: data.majorDiff || '', // 主要困难
        thought: data.ideStatus || '', //思想状况
        theParty: data.joinParty || '', // 参加党组织活动
        welfare: data.joinPublic || '', // 参加公益活动
        contents: data.majorElements || '', // 主要内容
        visit: data.recStatus || '', // 走访状态
        accident: data.majorAccident || '', //  是否重大事故
        accDeta: data.accidentContent || '', // 重大事故详情
        sympathySupplies: data.sympathySupplies || '', // 是否有慰问物资
        suppliesContent: data.suppliesContent || '', // 慰问物质详情
        suppliesMoney: data.suppliesMoney || ''// 慰问物资合计金额
      }
    });

  },
  // 442826195602292316

  onActiveChange:function(event){  //tab切换
    this.setData({
      addVisitActive: event.detail.index
    })
  },
})