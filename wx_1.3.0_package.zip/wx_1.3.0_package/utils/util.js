const formatTime = date => {
  const year = date.getFullYear()
  const month = date.getMonth() + 1
  const day = date.getDate()
  const hour = date.getHours()
  const minute = date.getMinutes()
  const second = date.getSeconds()

  return [year, month, day].map(formatNumber).join('/') + ' ' + [hour, minute, second].map(formatNumber).join(':')
}

const formatNumber = n => {
  n = n.toString()
  return n[1] ? n : '0' + n
}

/** 
 * 时间戳转化为年 月 日 时 分 秒 
 * number: 传入时间戳 
 * format：返回格式，支持自定义，但参数必须与formateArr里保持一致 
 */
const timestampFn = (number, format) => {

  var formateArr = ['Y', 'M', 'D', 'h', 'm', 's'];
  var returnArr = [];

  var date = new Date(number);
  returnArr.push(date.getFullYear());
  returnArr.push(formatNumber(date.getMonth() + 1));
  returnArr.push(formatNumber(date.getDate()));

  returnArr.push(formatNumber(date.getHours()));
  returnArr.push(formatNumber(date.getMinutes()));
  returnArr.push(formatNumber(date.getSeconds()));

  for (var i in returnArr) {
    format = format.replace(formateArr[i], returnArr[i]);
  }
  return format;
}
/** 
 * 数据回填匹配
 */
const makeSelectOrChecked = (key, objArr) => {
  var str = '';
  var arr = objArr.filter(function(m, i) {
    return key === m.value;
  })
  str = arr.length > 0 ? arr[0].title : '';
  return str;
}
const makeSelectOrCheckedDetailInfo = (key, objArr) => {
  var str = '';
  var arr = objArr.filter(function(m, i) {
    return key === m.value;
  })
  str = arr.length > 0 ? arr[0].title : key;
  return str;
}
/** 
 * 数据字典
 */
const dataDictionary = function() {
  var COMMON = {
    // 政治面貌
    politicalStatus: [{
        value: '01',
        title: '中国共产党党员'
      },
      {
        value: '02',
        title: '中国共产党预备党员'
      },
      {
        value: '03',
        title: '中国共产主义青年团团员'
      },
      {
        value: '04',
        title: '中国国民党革命委员会会员'
      },
      {
        value: '05',
        title: '中国民主同盟盟员'
      },
      {
        value: '06',
        title: '中国民主建国会会员'
      },
      {
        value: '07',
        title: '中国民主促进会会员'
      },
      {
        value: '08',
        title: '中国农工民主党党员'
      },
      {
        value: '09',
        title: '中国致公党党员'
      },
      {
        value: '10',
        title: '九三学社社员'
      },
      {
        value: '11',
        title: '台湾民主自治同盟盟员'
      },
      {
        value: '12',
        title: '无党派民主人士'
      },
      {
        value: '13',
        title: '群众'
      }
    ],
    // 人员类别
    perCategory: [{
        value: '1100',
        title: '军队转业干部'
      },
      {
        value: '1200',
        title: '退役士兵'
      },
      {
        value: '1300',
        title: '军队离退休干部和退休士官'
      },
      {
        value: '1400',
        title: '无军籍离退休职工'
      },
      {
        value: '0300',
        title: '三红'
      },
      {
        value: '0400',
        title: '复员军人'
      },
      {
        value: '0101',
        title: '残疾军人'
      },
      {
        value: '0104',
        title: '伤残民兵民工'
      },
      {
        value: '0201',
        title: '烈士遗属'
      },
      {
        value: '0202',
        title: '因公牺牲军人遗属'
      },
      {
        value: '0203',
        title: '病故军人遗属'
      },
      {
        value: '0204',
        title: '现役军人家属'
      }
    ],
    // 年收入状况
    incomeStatus: [{
        value: '1',
        title: '0-10000元'
      },
      {
        value: '2',
        title: '10001-30000元'
      },
      {
        value: '3',
        title: '30001-50000元'
      },
      {
        value: '4',
        title: '50001-120000元'
      },
      {
        value: '5',
        title: '120000元以上'
      }
    ],
    // 就业情况
    empStatus: [{
        value: '1',
        title: '在职'
      },
      {
        value: '2',
        title: '无业'
      },
      {
        value: '3',
        title: '务农'
      },
      {
        value: '4',
        title: '自主创业'
      },
      {
        value: '5',
        title: '继续教育'
      },
      {
        value: '6',
        title: '退休'
      },
      {
        value: '7',
        title: '创业'
      },
      {
        value: '8',
        title: '务农'
      },
      {
        value: '9',
        title: '学生'
      },
			{
			  value: '10',
			  title: '待业'
			},
      {
        value: '11', // 21
        title: '政府扶持就业'
      },
      {
        value: '12', // 22
        title: '灵活就业'
      },
      {
        value: '13', // 23
        title: '继续教育(含复读)' // 离退休
      },
      {
        value: '0',
        title: '无'
      }
    ],
    // 就业情况
    empStatusExtraI: [{
      value: '1',
      title: '政府扶持就业'
    },
    {
      value: '2',
      title: '自主就业'
    },
    {
      value: '3',
      title: '灵活就业'
    },
    {
      value: '4',
      title: '下岗'
    },
    {
      value: '5',
      title: '失业'
    },
    {
      value: '6',
      title: '待业'
    },
    {
      value: '7',
      title: '离休'
    },
    {
      value: '8',
      title: '退休'
    }
  ],
    // 行业类别
    professionStatus : [
      { value: '1', title: '采矿业' },
      { value: '2', title: '制造业' },
      { value: '3', title: '电力、热力、燃气及水生产和供应业' },
      { value: '4', title: '建筑业' },
      { value: '5', title: '批发和零售业' },
      { value: '6', title: '交通运输、仓储和邮政业' },
      { value: '7', title: '住宿和餐饮业' },
      { value: '8', title: '信息传输、软件和信息技术服务业' },
      { value: '9', title: '金融业' },
      { value: '10', title: '房地产业' },
      { value: '11', title: '租赁和商务服务业' },
      { value: '12', title: '科学研究和技术服务业' },
      { value: '13', title: '水利、环境和公共设施管理业' },
      { value: '14', title: '居民服务、修理和其他服务业' },
      { value: '15', title: '教育' },
      { value: '16', title: '卫生和社会工作' },
      { value: '17', title: '文化、体育和娱乐业' },
      { value: '18', title: '国际组织' },
      { value: '19', title: '军队' }
    ],
    // 职业类别
    occupationStatus : [
      { value: '1', title: 'IT/互联网/通信' },
      { value: '2', title: '销售/客服/市场' },
      { value: '3', title: '财务/人力资源/行政' },
      { value: '4', title: '项目/质量/高级管理' },
      { value: '5', title: '房产/建筑/物业管理' },
      { value: '6', title: '金融' },
      { value: '7', title: '采购/贸易/交通/物流' },
      { value: '8', title: '生产/制造' },
      { value: '9', title: '传媒/印刷/艺术/设计' },
      { value: '10', title: '咨询/法律/教育/翻译' },
      { value: '11', title: '服务业' },
      { value: '12', title: '能源/环保/农业' },
      { value: '13', title: '农/林/牧/渔业' },
      { value: '14', title: '公务员/事业单位/科研' },
      { value: '15', title: '考研/出国/参军/创业' },
      { value: '16', title: '医疗卫生' }
    ],
    // 工作单位性质
    unitPropertiesStatus : [
      { value: '1', title: '党政机关' },
      { value: '2', title: '事业单位' },
      { value: '3', title: '国有企业' },
      { value: '4', title: '民营企业' },
      { value: '5', title: '三资企业' },
      { value: '6', title: '其他' }
    ],
    // 婚姻状况
    marriageStatus: [{
        value: '10',
        title: '未婚'
      },
      {
        value: '20',
        title: '已婚'
      },
      {
        value: '30',
        title: '丧偶'
      },
      {
        value: '40',
        title: '离婚'
      }
    ],
		// 参加培训
		trainStatus: [{
		    value: '0',
		    title: '无培训'
		  },
		  {
		    value: '1',
		    title: '全员适应性培训'
		  },
		  {
		    value: '2',
		    title: '就业前培训'
		  }
		],
    // 人员现状
    personalStateStatus: [{
        value: '0',
        title: '正常'
      },
      {
        value: '1',
        title: '去世'
      },
      {
        value: '2',
        title: '迁出'
      }
    ],
    // 健康状况
    healthStatus: [{
        value: '01',
        title: '良好'
      },
      {
        value: '02',
        title: '一般'
      },
      {
        value: '03',
        title: '差'
      }
    ],
    // 社会救助
    socialRescue: [{
        value: '1',
        title: '低保'
      },
      {
        value: '2',
        title: '五保'
      },
      {
        value: '3',
        title: '建档立卡贫困户'
      },
      {
        value: '0',
        title: '无'
      }
    ],
    // 住房
    houseStatus: [{
        value: '0',
        title: '无'
      },
      {
        value: '1',
        title: '自建房'
      },
      {
        value: '2',
        title: '公有住房'
      },
      {
        value: '3',
        title: '经济适用房'
      },
      {
        value: '4',
        title: '公租房'
      },
      {
        value: '5',
        title: '廉租房'
      },
      {
        value: '6',
        title: '商品房'
      },
      {
        value: '7',
        title: '还建房'
      },
      {
        value: '8',
        title: '其他'
      }
    ],
    // 六必访
    sixMustVisit: [{
        value: '1',
        title: '建国前参加歌名的老战士、老革命及其配偶'
      },
      {
        value: '2',
        title: '“参战参试”退役军人'
      },
      {
        value: '3',
        title: '烈士遗属'
      },
      {
        value: '4',
        title: '伤残军人'
      },
      {
        value: '5',
        title: '二级功及以上'
      },
      {
        value: '6',
        title: '遭遇重大变故或遇到重大困难的现役和退役军人家庭'
      }
    ],
    // 退役方式
    soldierRetireMode: [{
        value: '1',
        title: '安排工作'
      },
      {
        value: '2',
        title: '自主就业'
      },
      {
        value: '6',
        title: '退休'
      },
      {
        value: '5',
        title: '供养'
      },
      {
        value: '7',
        title: '复原'
      }
    ],
    // 干部退役方式| // 干部类别
    cadresMetireMode: [{
        value: '1',
        title: '计划分配'
      },
      {
        value: '2',
        title: '自主择业'
      },
      {
        value: '3',
        title: '企业军转干部'
      },
      {
        value: '4',
        title: '自愿自行就业军转干部'
      },
      {
        value: '5',
        title: '军休干部'
      },
      {
        value: '6',
        title: '复原'
      }
    ],
    // 社会救助
    socialRescue: [
      { value: '1', title: '低保' },
      { value: '2', title: '五保' },
      { value: '3', title: '建档立卡贫困户' },
      { value: '0', title: '无' }
    ],
    // 职级
    cadresRank: [{
        value: '1',
        title: '排级'
      },
      {
        value: '2',
        title: '营级'
      },
      {
        value: '3',
        title: '连级'
      },
      {
        value: '4',
        title: '团级'
      },
      {
        value: '5',
        title: '师级'
      }
    ],
    // 优抚对象
    preferenceType: [{
        value: '0100',
        title: '伤残人员'
      },
      {
        value: '0400',
        title: '在乡老复原干部'
      },
      {
        value: '0500',
        title: '带病回乡退伍军人'
      },
      {
        value: '0600',
        title: '参战退役人员'
      },
      {
        value: '0602',
        title: '参试（涉核）退役人员'
      },
      {
        value: '0801',
        title: '烈士老年子女'
      },
      {
        value: '0700',
        title: '年满60周岁农村籍退役士兵 '
      },
      {
        value: '0201',
        title: '烈士遗属'
      },
      {
        value: '0202',
        title: '因公牺牲军人遗属'
      },
      {
        value: '0203',
        title: '病故军人遗属'
      },
      {
        value: '0000',
        title: '其他'
      }
    ],
    // 现状
    circumstances: [{
        value: '1',
        title: '安置后在岗',
        name: 'azhzg'
      },
      {
        value: '2',
        title: '安置后未在岗',
        name: 'azhwzg'
      },
      {
        value: '3',
        title: '应安置未安置',
        name: 'yazwaz'
      },
      {
        value: '4',
        title: '自谋职业',
        name: 'zmzy'
      },
      {
        value: '5',
        title: '回乡务农',
        name: 'hxwn'
      },
      {
        value: '6',
        title: '安置后下岗失业',
        name: 'azhxgsy'
      },
      {
        value: '7',
        title: '退休',
        name: 'tx'
      },
      {
        value: '0',
        title: '其他',
        name: 'qt'
      }
    ],
    // 诉求类型
    sqlx: [{
        value: '1',
        title: '提高待遇问题'
      },
      {
        value: '2',
        title: '确认身份问题'
      },
      {
        value: '3',
        title: '安排工作问题'
      },
      {
        value: '4',
        title: '解决“三难”问题'
      },
      {
        value: '5',
        title: '解决社保问题'
      },
      {
        value: '0',
        title: '其他'
      }
    ],
    // 从业类型
    cylx: [{
        value: '1',
        title: '机关单位'
      },
      {
        value: '2',
        title: '事业单位'
      },
      {
        value: '3',
        title: '国有企业'
      },
      {
        value: '4',
        title: '私营企业'
      },
      {
        value: '5',
        title: '个体经营'
      },
      {
        value: '6',
        title: '外出打工'
      },
      {
        value: '7',
        title: '公益性岗位'
      },
      {
        value: '0',
        title: '其他'
      }
    ],
    // 民族
    nationMap: [{
        value: '01',
        title: '汉族'
      },
      {
        value: '02',
        title: '蒙古族'
      },
      {
        value: '03',
        title: '回族'
      },
      {
        value: '04',
        title: '藏族'
      },
      {
        value: '05',
        title: '维吾尔族'
      },
      {
        value: '06',
        title: '苗族'
      },
      {
        value: '07',
        title: '彝族'
      },
      {
        value: '08',
        title: '壮族'
      },
      {
        value: '09',
        title: '布依族'
      },
      {
        value: '10',
        title: '朝鲜族'
      },
      {
        value: '11',
        title: '满族'
      },
      {
        value: '12',
        title: '侗族'
      },
      {
        value: '13',
        title: '瑶族'
      },
      {
        value: '14',
        title: '白族'
      },
      {
        value: '15',
        title: '土家族'
      },
      {
        value: '16',
        title: '哈尼族'
      },
      {
        value: '17',
        title: '哈萨克族'
      },
      {
        value: '18',
        title: '傣族'
      },
      {
        value: '19',
        title: '黎族'
      },
      {
        value: '20',
        title: '傈僳族'
      },
      {
        value: '21',
        title: '佤族'
      },
      {
        value: '22',
        title: '畲族'
      },
      {
        value: '23',
        title: '高山族'
      },
      {
        value: '24',
        title: '拉祜族'
      },
      {
        value: '25',
        title: '水族'
      },
      {
        value: '26',
        title: '东乡族'
      },
      {
        value: '27',
        title: '纳西族'
      },
      {
        value: '28',
        title: '景颇族'
      },
      {
        value: '29',
        title: '柯尔克孜族'
      },
      {
        value: '30',
        title: '土族'
      },
      {
        value: '31',
        title: '达斡尔族'
      },
      {
        value: '32',
        title: '仫佬族'
      },
      {
        value: '33',
        title: '羌族'
      },
      {
        value: '34',
        title: '布朗族'
      },
      {
        value: '35',
        title: '撤拉族'
      },
      {
        value: '36',
        title: '毛难族'
      },
      {
        value: '37',
        title: '仡佬族'
      },
      {
        value: '38',
        title: '锡伯族'
      },
      {
        value: '39',
        title: '阿昌族'
      },
      {
        value: '40',
        title: '普米族'
      },
      {
        value: '41',
        title: '塔吉克族'
      },
      {
        value: '42',
        title: '怒族'
      },
      {
        value: '43',
        title: '乌孜别克族'
      },
      {
        value: '44',
        title: '俄罗斯族'
      },
      {
        value: '45',
        title: '鄂温克族'
      },
      {
        value: '46',
        title: '崩龙族'
      },
      {
        value: '47',
        title: '保安族'
      },
      {
        value: '48',
        title: '裕固族'
      },
      {
        value: '49',
        title: '京族'
      },
      {
        value: '50',
        title: '塔塔尔族'
      },
      {
        value: '51',
        title: '独龙族'
      },
      {
        value: '52',
        title: '鄂伦春族'
      },
      {
        value: '53',
        title: '赫哲族'
      },
      {
        value: '54',
        title: '门巴族'
      },
      {
        value: '55',
        title: '珞巴族'
      },
      {
        value: '56',
        title: '基诺族'
      },
      {
        value: '57',
        title: '其他'
      },
      {
        value: '58',
        title: '外国血统中国籍人士'
      }
    ],
    // 文化程度
    cultureMap: [{
        value: '11',
        title: '博士'
      },
      {
        value: '12',
        title: '硕士'
      },
      {
        value: '20',
        title: '大学本科'
      },
      {
        value: '30',
        title: '大学专科（高职）'
      },
      {
        value: '40',
        title: '中专（中技）'
      },
      {
        value: '60',
        title: '高中'
      },
      {
        value: '70',
        title: '初中以下'
      }
    ],
    // 户籍类别
    registrationMap: [{
        value: '1',
        title: '农村（农业）'
      },
      {
        value: '2',
        title: '城镇（非农业）'
      }
    ],
    // 原职级  
    armyPostMap: [{
        value: 'PD',
        title: '排职以下'
      },
      {
        value: 'PZ',
        title: '排职'
      },
      {
        value: 'FL',
        title: '副连职'
      },
      {
        value: 'ZL',
        title: '正连职'
      },
      {
        value: 'FY',
        title: '副营职'
      },
      {
        value: 'ZY',
        title: '正营职'
      },
      {
        value: 'FT',
        title: '副团职'
      },
      {
        value: 'ZT',
        title: '正团职'
      },
      {
        value: 'FS',
        title: '副师职'
      },
      {
        value: 'ZS',
        title: '正师职'
      },
      {
        value: 'FJ',
        title: '副军职'
      },
      {
        value: 'ZJ',
        title: '正军职'
      },
      {
        value: '14',
        title: '十四级'
      },
      {
        value: '13',
        title: '十三级'
      },
      {
        value: '12',
        title: '十二级'
      },
      {
        value: '11',
        title: '十一级'
      },
      {
        value: '10',
        title: '十级'
      },
      {
        value: '09',
        title: '九级'
      },
      {
        value: '08',
        title: '八级'
      },
      {
        value: '07',
        title: '七级'
      },
      {
        value: '06',
        title: '六级'
      },
      {
        value: '05',
        title: '五级'
      },
      {
        value: '04',
        title: '四级'
      },
      {
        value: '03',
        title: '三级'
      },
      {
        value: 'BS',
        title: '办事员'
      },
      {
        value: 'EK',
        title: '二级科员'
      },
      {
        value: 'YK',
        title: '一级科员'
      },
      {
        value: 'FK',
        title: '副科级'
      },
      {
        value: 'ZK',
        title: '正科级'
      },
      {
        value: 'FC',
        title: '副处级'
      },
      {
        value: 'ZC',
        title: '正处级'
      },
      {
        value: 'JF',
        title: '副局级'
      },
      {
        value: 'JZ',
        title: '正局级'
      },
      {
        value: 'DF',
        title: '按副军职待遇'
      },
      {
        value: 'DZ',
        title: '按正军职待遇'
      },
      {
        value: 'DQ',
        title: '副大军区职待遇'
      },
      {
        value: 'QT',
        title: '其他'
      }
    ],
    // 安置单位性质
    resettleUnitNatureMap: [{
        value: '1',
        title: '行政机关'
      },
      {
        value: '2',
        title: '事业单位'
      },
      {
        value: '3',
        title: '企业'
      },
      {
        value: '0',
        title: '其他'
      }
    ],
    // 退役安置方式
    resettleMode2: [{
        value: '1',
        title: '安排工作'
      },
      {
        value: '2',
        title: '自主就业'
      },
      {
        value: '3',
        title: '自谋职业'
      },
      {
        value: '4',
        title: '国家供养'
      },
      {
        value: '5',
        title: '回乡生产'
      },
      {
        value: '6',
        title: '符合转业条件选择复员'
      },
      {
        value: '7',
        title: '按政策取消待遇'
      },
      {
        value: '8',
        title: '复工复学'
      }
    ],
    //原衔级
    armyRank: [{
        value: '1',
        title: '义务兵'
      },
      {
        value: '2',
        title: '初级士官'
      },
      {
        value: '3',
        title: '中级士官'
      },
      {
        value: '4',
        title: '高级士官'
      },
      {
        value: '5',
        title: '志愿兵'
      }
    ],
    // 伤残等级
    disgrd: [{
        value: '01',
        title: '一级'
      },
      {
        value: '02',
        title: '二级'
      },
      {
        value: '03',
        title: '三级'
      },
      {
        value: '04',
        title: '四级'
      },
      {
        value: '05',
        title: '五级'
      },
      {
        value: '06',
        title: '六级'
      },
      {
        value: '07',
        title: '七级'
      },
      {
        value: '08',
        title: '八级'
      },
      {
        value: '09',
        title: '九级'
      },
      {
        value: '10',
        title: '十级'
      }
    ],
    // 军休类别
    arpType: [{
        value: '1',
        title: '离休干部'
      },
      {
        value: '2',
        title: '退休干部'
      },
      {
        value: '3',
        title: '退休士官'
      },
      {
        value: '4',
        title: '退休改离休'
      }
    ],
    // 成为军队职工方式
    armyWorkerWay: [{
        value: '1',
        title: '招工'
      },
      {
        value: '2',
        title: '地方调入'
      },
      {
        value: '3',
        title: '兵改工'
      },
      {
        value: '4',
        title: '军转安置'
      },
      {
        value: '5',
        title: '随军安置'
      },
      {
        value: '6',
        title: '征地农转工'
      },
      {
        value: '7',
        title: '接收大中专毕业生'
      },
      {
        value: '8',
        title: '其他'
      }
    ],
    // 原职级  待定
    armyPost: [{
        value: 'Z2',
        title: '专业技术二级'
      },
      {
        value: 'Z3',
        title: '专业技术三级'
      },
      {
        value: 'Z4',
        title: '专业技术四级'
      },
      {
        value: 'Z5',
        title: '专业技术五级'
      },
      {
        value: 'Z6',
        title: '专业技术六级'
      },
      {
        value: 'Z7',
        title: '专业技术七级'
      },
      {
        value: 'Z8',
        title: '专业技术八级'
      },
      {
        value: 'Z9',
        title: '专业技术九级'
      },
      {
        value: 'Z10',
        title: '专业技术十级'
      },
      {
        value: 'Z11',
        title: '专业技术十一级'
      },
      {
        value: 'Z12',
        title: '专业技术十二级'
      },
      {
        value: 'Z13',
        title: '专业技术十三级'
      },
      {
        value: 'G3',
        title: '管理三级'
      },
      {
        value: 'G4',
        title: '管理四级'
      },
      {
        value: 'G5',
        title: '管理五级'
      },
      {
        value: 'G6',
        title: '管理六级'
      },
      {
        value: 'G7',
        title: '管理七级'
      },
      {
        value: 'G8',
        title: '管理八级'
      },
      {
        value: 'G9',
        title: '管理九级'
      },
      {
        value: 'G10',
        title: '管理十级'
      },
      {
        value: 'J1',
        title: '技术工一级'
      },
      {
        value: 'J2',
        title: '技术工二级'
      },
      {
        value: 'J3',
        title: '技术工三级'
      },
      {
        value: 'J4',
        title: '技术工四级'
      },
      {
        value: 'J5',
        title: '技术工五级'
      },
      {
        value: 'ZGJ',
        title: '正高级'
      },
      {
        value: 'FGJ',
        title: '副高级'
      },
      {
        value: 'ZLY',
        title: '助理级'
      },
      {
        value: 'YJ',
        title: '员级'
      },
      {
        value: 'ZJ',
        title: '正局'
      },
      {
        value: 'FJ',
        title: '副局'
      },
      {
        value: 'ZC',
        title: '正处'
      },
      {
        value: 'FC',
        title: '副处'
      },
      {
        value: 'ZK',
        title: '正科'
      },
      {
        value: 'FK',
        title: '副科'
      },
      {
        value: 'KY',
        title: '科员'
      },
      {
        value: 'BSY',
        title: '办事员'
      },
      {
        value: 'GJJ',
        title: '高级技师'
      },
      {
        value: 'JS',
        title: '技师'
      },
      {
        value: 'JG',
        title: '技工'
      },
      {
        value: 'GGG',
        title: '高级工'
      },
      {
        value: 'ZGG',
        title: '中级工'
      },
      {
        value: 'CGG',
        title: '初级工'
      },
      {
        value: 'PG',
        title: '普通工'
      }
    ],
    //安置计划批次
    resettlePlanOrder: [{
        value: '01',
        title: '无'
      },
      {
        value: '02',
        title: '一批'
      },
      {
        value: '03',
        title: '二批'
      },
      {
        value: '04',
        title: '三批'
      },
      {
        value: '05',
        title: '四批'
      },
      {
        value: '06',
        title: '五批'
      },
      {
        value: '07',
        title: '六批'
      },
      {
        value: '08',
        title: '2015年度'
      },
      {
        value: '09',
        title: '2017年度'
      }
    ],
    //所购房改住房性质
    buyHrhNature: [{
        value: '1',
        title: '军队安置住房'
      },
      {
        value: '2',
        title: '军队经济适用住房'
      },
      {
        value: '3',
        title: '军队集资房'
      },
      {
        value: '4',
        title: '军队安居工程房'
      },
      {
        value: '5',
        title: '军队售房区现住房'
      },
      {
        value: '6',
        title: '地方经济适用住房'
      },
      {
        value: '7',
        title: '单位统购商品房'
      },
      {
        value: '8',
        title: '共有产权房'
      },
      {
        value: '9',
        title: '限价商品房'
      },
      {
        value: '0',
        title: '其他房改住房'
      }
    ],
    // 医疗保险：
    medInsuranceMap: [{
        value: '1',
        title: '城乡居民基本医疗保险'
      },
      {
        value: '2',
        title: '职工基本医疗保险'
      },
      {
        value: '3',
        title: '公费医疗'
      },
      {
        value: '4',
        title: '无'
      }
    ],
    // 养老保险：
    endInsuranceMap: [{
        value: '1',
        title: '城乡居民社会养老保险'
      },
      {
        value: '2',
        title: '职工基本养老保险'
      },
      {
        value: '3',
        title: '离退休金'
      },
      {
        value: '4',
        title: '无'
      }
    ],
    // 主要困难
    demandDiffMap: [{
        value: '1',
        title: '就业'
      },
      {
        value: '2',
        title: '生活'
      },
      {
        value: '3',
        title: '住房'
      },
      {
        value: '4',
        title: '医疗'
      },
      {
        value: '5',
        title: '养老'
      },
      {
        value: '6',
        title: '教育'
      },
      {
        value: '0',
        title: '其他'
      }
    ],
    // 主要诉求
    demandTypeMap: [{
        value: '1',
        title: '提高待遇问题'
      },
      {
        value: '2',
        title: '确认身份问题'
      },
      {
        value: '3',
        title: '安排工作问题'
      },
      {
        value: '4',
        title: '解决“三难”问题'
      },
      {
        value: '5',
        title: '解决社保问题'
      },
      {
        value: '0',
        title: '其他'
      }
    ],
    // 立功受奖情况：
    armyAwardMap: [{
        value: '1',
        title: '八一勋章'
      },
      {
        value: '2',
        title: '大军区以上荣誉称号'
      },
      {
        value: '3',
        title: '一等功'
      },
      {
        value: '4',
        title: '二等功'
      },
      {
        value: '5',
        title: '三等功'
      },
      {
        value: '6',
        title: '全军士官优秀人才奖'
      },
      {
        value: '7',
        title: '其他'
      },
      {
        value: '0',
        title: '无'
      }
    ],
    // 家庭购买房改住房情况
    buyHrhStatusMap: [{
        value: '1',
        title: '已购房'
      },
      {
        value: '2',
        title: '已确定购房意向'
      },
      {
        value: '0',
        title: '未购房'
      }
    ],
    // 供养情况
    supStatusMap: [{
        value: '1',
        title: '分散供养'
      },
      {
        value: '2',
        title: '集中供养'
      },
      {
        value: '0',
        title: '无'
      }
    ],
    // 供养单位
    supUnitMap: [{
        value: '1',
        title: '荣康医院'
      },
      {
        value: '2',
        title: '复退军人精神病院'
      },
      {
        value: '3',
        title: '复退军人慢性病疗养院'
      },
      {
        value: '4',
        title: '光荣院'
      },
      {
        value: '5',
        title: '社会福利机构'
      },
      {
        value: '6',
        title: '军休所'
      },
      {
        value: '0',
        title: '其他'
      }
    ],
    // 待遇情况：
    treatStatusMap: [{
        value: '1',
        title: '在乡'
      },
      {
        value: '2',
        title: '离休'
      },
      {
        value: '3',
        title: '退休'
      },
      {
        value: '0',
        title: '无'
      }
    ],
    // 伤残性质：
    diskindMap: [{
        value: '01',
        title: '因战'
      },
      {
        value: '02',
        title: '因公'
      },
      {
        value: '03',
        title: '因病'
      }
    ],
    // 烈士安葬地：
    marBuryPlaceMap: [{
        value: '1',
        title: '境内'
      },
      {
        value: '2',
        title: '境外'
      },
      {
        value: '3',
        title: '不清楚'
      }
    ],
    // 与烈士关系： 与因公牺牲军人关系
    marRelationMap: [{
        value: '01',
        title: '配偶'
      },
      {
        value: '02',
        title: '父母（抚养人）'
      },
      {
        value: '03',
        title: '子女'
      },
      {
        value: '04',
        title: '兄弟姐妹'
      }
    ],
    // 优抚待遇情况：
    marTreatStatusMap: [{
        value: '1',
        title: '定期抚恤金'
      },
      {
        value: '2',
        title: '定期生活补助金'
      },
      {
        value: '0',
        title: '不享受'
      }
    ],
    // 现役军人职级：
    aspRankMap: [{
        value: '1',
        title: '军官'
      },
      {
        value: '2',
        title: '士官'
      },
      {
        value: '3',
        title: '义务兵'
      }
    ],
    //redarmyType    三红
    redarmyTypeMap: [{
        value: '0301',
        title: '退伍红军老战士'
      },
      {
        value: '0302',
        title: '西路军红军老战士'
      },
      {
        value: '0303',
        title: '红军失散人员'
      }
    ]
  };
  return COMMON;
}

// 匹配性别
const getSex = key => {
  var num = parseInt(key);
  if (1 === num) {
    return '男';
  } else if (2 === num) {
    return '女';
  }
  return '';
}

module.exports = {
  formatTime: formatTime,
  timestampFn: timestampFn,
  dataDictionary: dataDictionary,
  getSex: getSex,
  makeSelectOrChecked: makeSelectOrChecked,
  makeSelectOrCheckedDetailInfo:makeSelectOrCheckedDetailInfo
}