const call = require("../../../utils/request.js");
const callTime = require("../../../utils/util.js");
import Toast from '../../../vant-weapp/toast/toast';
let app = getApp();
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    selectObjectList: {
		  type: Array,
		  value: []
    },
    selectActiveListDetail: {
      type: Array,
		  value: []
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    // selectObjectList: [],
    hasMore: true,
    params: {
      theme: "",
      location: '',
      status:'1', // 已发布活动
      pageable: {
        page: 1,
        rows: 20
      },
    },
    hasMore:true, // 活动更多数据flag
    activeList: [],
    activeResultDetail:[],
    activeResult: [],
    toView: 'green',
  },
  /**
   * 组件挂载后执行 ready
   */
  ready: function() {
    // wx.showLoading();
    let that = this;
    this.setData({
      activeResultDetail:that.data.selectActiveListDetail || [],
      activeResult: that.data.selectActiveList || []
    })
    
  },

  /**
   * 组件的方法列表
   */
  methods: {
    loadData(data) {
      var that = this
      if (!that.data.hasMore) {
        return
      }
      call.postData('/interview/list', this.data.params, function (res) { //  请求成功
        if (res.code == 200) {
          if (that.data.params.pageable.page == 1) {
            that.data.activeList = []
          }
          if (res.data.page < res.data.totalPages) {
            that.data.params.pageable.page++
          }
          that.data.hasMore = res.data.page < res.data.totalPages
          if (res.data.content && res.data.content.length > 0) {
            that.data.activeList = that.data.activeList.concat(res.data.content)
          }
          that.setData({
            activeList: that.data.activeList,
            hasMore: that.data.hasMore
          })
        } else {
          Toast(res.msg);
        }
      })
    }, 
    updateData(data){ // g更新数据
      // console.log('propsDataFn', data )
      const that = this
      that.setData({
        activeResultDetail:data.activeResultDetail || [],
        activeResult: data.activeResult || []
      })
      
       this.loadData();
    },
    activePrimary: function () { // 活动列表搜索
      this.data.hasMore = true
      this.data.params.pageable.page = 1
      this.loadData();
    },
    activeConfim(){ // 向父组件传值
      const that = this;
      // console.log("activeConfim",that.data)
      this.triggerEvent("getActiveData", {activeResult:that.data.activeResult,activeResultDetail:that.data.activeResultDetail,addShow:'1'})
    },
    onChangeObject(event) { // 列表 复选事件
      this.setData({
        objectResult: event.detail
      });
    },
  
    onChangeActive(event) { // 活动列表 复选事件
      // console.log(event)
      this.setData({
        activeResult: event.detail
      });
      // console.log( this.data.activeResult )
    },
  
    toggle(event) { // 活动列表  内容点击 复选按钮切换点击事件
      const { index,item } = event.currentTarget.dataset;
      // console.log('event',event)
      const checkbox = this.selectComponent(`.checkboxes-${index}`);
      checkbox.toggle();
      this.activeSelectList(item)
    },
    activeLoop(e){ // 每个单选按钮的实例
      // console.log('e',e.currentTarget.dataset.item)
      this.activeSelectList(e.currentTarget.dataset.item)
    },
    activeSelectList(data) {
      const that = this
      let activeResultArr = that.data.activeResult
      let activeResultArrFlag =   activeResultArr.filter(item => item == data.id) 
      if( activeResultArrFlag.length < 1 ) {
        that.setData({
          activeResultDetail:that.data.activeResultDetail.filter(item => item.id != data.id) 
        })
      }else{
        that.setData({
          activeResultDetail:[...that.data.activeResultDetail,data]
        })
      }
      // console.log("activeResultDetail",that.data.activeResultDetail)
      
    },
    onChangeTitle(event) {
      const that = this;
      let paramsTheme = 'params.theme'
      that.setData({
        [paramsTheme] : event.type == "change" ? event.detail : event.detail.value
      })
    },
    objectListLower(e) {
      // console.log('滚动到底部',e)
      this.loadData()
    },
  }
})