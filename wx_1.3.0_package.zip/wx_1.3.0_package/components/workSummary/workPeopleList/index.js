const call = require("../../../utils/request.js");
const callTime = require("../../../utils/util.js");
import Toast from '../../../vant-weapp/toast/toast';
let app = getApp();
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    selectObjectList: {
		  type: Array,
		  value: []
		}
  },

  /**
   * 组件的初始数据
   */
  data: {
    // selectObjectList: [],
    hasMore: true,
    show:true,
    params:{
      pageable: {
        page: 1,
        rows: 10
      },
      page:1,
      pageSize:10,
      name:'',
      cardId:''
    },
    objectResult:[], // 已选择对象id集合
    objectResultDetail:[], // 已选择对象详细信息集合
  },
  /**
   * 组件挂载后执行 ready
   */
  ready: function() {
    // wx.showLoading();
    let that = this;
    // console.log( that.data.selectObjectList )
    // this.loadData();
  },

  /**
   * 组件的方法列表
   */
  methods: {
    updateData(data) {
      const that = this;
      this.loadData();
      that.setData({
        objectResult:data.objectResult || [],
        objectResultDetail:data.objectResultDetail || []
      })
    },
    loadData(data) {
      var that = this
      if (!that.data.hasMore) {
        return
      }
      // call.postData('/admin/personalFilesBase/list', this.data.params, function (res) { //  请求成功
      this.data.params.page = this.data.params.pageable.page;
      this.data.params.pageSize = this.data.params.pageable.rows;
      call.postData('/admin/OnePersonOneFile/queryOnePersonOneFileList', this.data.params, function (res) { //  请求成功
        if (res.code == 200) {
          if (that.data.params.pageable.page == 1) {
            that.data.objectList = []
          }
          if (res.data.page < res.data.totalPages) {
            that.data.params.pageable.page++
          }
          that.data.hasMore = res.data.page < res.data.totalPages
          if (res.data.content && res.data.content.length > 0) {
            that.data.objectList = that.data.objectList.concat(res.data.content)
          }
          that.setData({
            objectList: that.data.objectList,
            hasMore: that.data.hasMore
          })
        } else {
          Toast(res.msg);
        }
      })
    },
    objectPrimary: function () { // 活动列表搜索
      this.data.hasMore = true
      this.data.params.pageable.page = 1
      this.loadData();
    },
    objectConfim(){ // 向父组件传值
      const that = this;
      console.log("111S")
      this.triggerEvent("getObjectData", {objectResult:that.data.objectResult,objectResultDetail:that.data.objectResultDetail,addShow:'1'})
    },
    onChangeObject(event) { // 列表 复选事件
      this.setData({
        objectResult: event.detail
      });
    },
  
    toggle(event) { //  内容点击 复选按钮切换点击事件
      const { index,item } = event.currentTarget.dataset;
      const checkbox = this.selectComponent(`.checkboxes-${index}`);
      checkbox.toggle();
      this.objectSelectList(item) // 存储当前点击的对象
    },
    objectLoop(e){ // 每个单选按钮的实例
      // console.log('objectLoop',e.currentTarget.dataset.item)
      this.objectSelectList(e.currentTarget.dataset.item)
    },

    objectSelectList(data) { ///存储当前点击的对象
      const that = this
      let objectResultArr = that.data.objectResult
      let objectResultArrFlag =   objectResultArr.filter(item => item == data.fileGuid) // 判断增加或删除 []代表删除
      if( objectResultArrFlag.length < 1 ) {
        that.setData({
          objectResultDetail:that.data.objectResultDetail.filter(item => item.fileGuid != data.fileGuid) 
        })
      }else{
        that.setData({
          objectResultDetail:[...that.data.objectResultDetail,data] // 选中对象详细信息数组
        })
      }

      // console.log("objectResultDetail",that.data.objectResultDetail)
    },
    onChangeTitle(event) {
      const that = this
      let paramsName = 'params.name'
      console.log(event)
      that.setData({
        [paramsName] : event.type == "change" ? event.detail : event.detail.value
      })
    },
    onChangeCardId (event) {
      const that = this
      let paramsCardId = 'params.cardId'
      console.log(event)
      that.setData({
        [paramsCardId] : event.type == "change" ? event.detail :  event.detail.value
      })
    },
  
    objectListLower(e) {
      // console.log('滚动到底部',e)
      this.loadData()
    },
    saveObjectFn() {
      this.triggerEvent("getObjectData", {likeflag:"aaa",likecount:"cc"})
    },
  }
})