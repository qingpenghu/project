// components/interviewList/index.js
const call = require("../../utils/request.js");
const callTime = require("../../utils/util.js");
let app = getApp();
import Toast from '../../vant-weapp/toast/toast';

Component({
  /**
   * 组件的属性列表
   */
  properties: {
    slidingListShow: {
      type: Boolean,
      value: true
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    evaluationNormData: [],
    hasMore: true,
    params: {
      examineName: '',
      pageable: {
        rows: 15,
        page: 1
      },
      page: 1,
      pageSize: 15
    },
    queryInputName: '',

  },
  /**
   * 组件挂载后执行 ready
   */
  ready: function () {
    // this.getData();
  },

  /**
   * 组件的方法列表
   */
  methods: {
    getData: function () {
      let that = this;
      if (!that.data.hasMore) {
        return
      }
      // call.postData('/admin/personalFilesBase/list', that.data.params, function (res) {
      call.postData('/admin/examine/list', that.data.params, function (res) {
        if (res.code != 200) {
          Toast(res.msg);
          return false;
        } else {
          if (that.data.params.pageable.page == 1) {
            that.data.evaluationNormData= [];
            wx.hideLoading();
            if (res.data && res.data.total <= that.data.params.pageable.rows) {
              that.setData({
                hasMore: false
              })
            }
          } else {
            if (res.data && that.data.params.pageable.page >= res.data.totalPages) {
              that.data.hasMore = false;
            }
          }
          that.data.params.pageable.page++;
          that.data.params.page++;
          that.data.evaluationNormData = that.data.evaluationNormData.concat(res.data.content || []);
          that.setData({
            evaluationNormData: that.data.evaluationNormData,
            hasMore: that.data.hasMore
          })
        }
        
      }, function (req) { Toast(req.msg); })
    },
    showLoadingMore: function () {
      this.setData({
        hasMore: this.data.hasMore
      })
    },
    hideLoadingMore: function () {
      this.setData({
        hasMore: this.data.hasMore
      })
    },
    onContactButton: function () {
      // 触底时父页面调用
      var that = this;
      // 显示加载图标
      this.showLoadingMore();
      this.getData();
    },
    onChangeName(event) {
      // event.detail 为当前输入的值   input 姓名的value
      this.setData({
        queryInputName: event.type == "blur" ? event.detail.value : event.detail
      });
    },

    cleanInfoFn() {
      //  清空搜索内容
      this.setData({
        queryInputName: '',
       
        params: {
          examineName: '',
          pageable: {
            rows: 10,
            page: 1
          },
          page: 1,
          pageSize: 10
        }
      });
    },
    submitInfoFn() {
      // 提交搜索条件
      var that = this;
      this.setData({
        hasMore: true,
        params: {
          examineName: that.data.queryInputName,
          pageable: {
            rows: 15,
            page: 1
          },
          page: 1,
          pageSize: 15
        }
      });
      this.getData();
    },
    jumpDetail(e) {
      let id = e.currentTarget.dataset.id
      if( id ) {
        wx.navigateTo({
          url: '/pages/workSummary/checkAppraiseDetail/index?type=detail&id='+id,
        })
      }else{
        Toast("参数缺失");
      }
    }
  }
})