// components/interviewSixVisit/index.js
const call = require("../../utils/request.js");
const callTime = require("../../utils/util.js");
let app = getApp();
import Toast from '../../vant-weapp/toast/toast';

Component({
  /**
   * 组件的属性列表
   */
  properties: {
    // slidingSixShow: {
    //   type: Boolean,
    //   value: true
    // }
  },

  /**
   * 组件的初始数据
   */
  data: {
    interviewSixInfo: [],
    hasMoreSix: true,
    params: {
      lbf1: '',
      lbf2: '',
      lbf3: '',
      lbf4: '',
      lbf5: '',
      lbf6: '',
      mustVisit: '1',
      name: '',
      cardId: '',
      pageable: {
        rows: 10,
        page: 1
      }
    },
    isName: '',
    isCardId: '',
    interSixColumns: ['建国前参加革命老战士，老革命及其配偶', '“参战参试”退役军人', '烈士遗属', '伤残军人', '二等功及以上', '遭遇重大变故或遇到重大困难的现役和退役军人家庭'],
    sixSesult: []
  },
  /**
   * 组件挂载后执行 ready
   */
  ready: function() {
    // wx.showLoading();
    // this.getData();
  },

  /**
   * 组件的方法列表
   */
  methods: {
    getData: function() {
      let that = this;
      if (!that.data.hasMoreSix) {
        return
      }
      call.postData('/admin/personalFilesBase/list', that.data.params, function(res) {
        if( res.code == 200){
          if (that.data.params.pageable.page == 1) {
            wx.hideLoading();
            if (res.data && res.data.total <= that.data.params.pageable.rows) {
              that.setData({
                hasMoreSix: false
              })
            }
          } else {
            if (res.data && that.data.params.pageable.page >= res.data.totalPages) {
              that.data.hasMoreSix = false;
            }
          }
          that.data.params.pageable.page++;
          that.data.interviewSixInfo = that.data.interviewSixInfo.concat(res.data.content || []);
          that.data.interviewSixInfo.forEach(function (item, index) {
            // item.cardImg = call.hostUrl + '/admin/image/get?imageId=' + item.cardImage || '/images/person_avatar.png';
            item.cardImg = item.cardImageUrl || '/images/person_avatar.png';
            item.personType = callTime.makeSelectOrChecked(item.personType || '', callTime.dataDictionary().perCategory);
          })
          that.setData({
            interviewSixInfo: that.data.interviewSixInfo,
            hasMoreSix: that.data.hasMoreSix
          })
        } else {
          Toast(res.msg);
          return false;
        }
        
      }, function(req) {})
    },
    showLoadingMore: function() {
      this.setData({
        hasMoreSix: this.data.hasMoreSix
      })
    },
    hideLoadingMore: function() {
      this.setData({
        hasMoreSix: this.data.hasMoreSix
      })
    },
    onContactButton: function() {
      var that = this;
      // 显示加载图标
      this.showLoadingMore();
      this.getData();
    },
    onChangeName(event) {
      // event.detail 为当前输入的值   input 姓名的value
      this.setData({
        isName: event.type == "blur" ? event.detail.value : event.detail
      });
    },
    onChangeCardId(event) {
      // event.detail 为当前输入的值   input 身份证号的value
      this.setData({
        isCardId: event.type == "blur" ? event.detail.value : event.detail
      });
    },
    // 复选条件
    onSixChange(event) {
      let that = this;
      let lbf1 = "params.lbf1";
      let lbf2 = "params.lbf2";
      let lbf3 = "params.lbf3";
      let lbf4 = "params.lbf4";
      let lbf5 = "params.lbf5";
      let lbf6 = "params.lbf6";
      this.setData({
        [lbf1]: 0,
        [lbf2]: 0,
        [lbf3]: 0,
        [lbf4]: 0,
        [lbf5]: 0,
        [lbf6]: 0
      })
      event.detail.forEach(function(item, index) {
        if (item == 0) {
          that.setData({ [lbf1]: 1 })
        }
        if (item == 1) {
          that.setData({ [lbf2]: 1 })
        }
        if (item == 2) {
          that.setData({ [lbf3]: 1 })
        }
        if (item == 3) {
          that.setData({ [lbf4]: 1 })
        }
        if (item == 4) {
          that.setData({ [lbf5]: 1 })
        }
        if (item == 5) {
          that.setData({ [lbf6]: 1 })
        }
      })
      this.setData({
        sixSesult: event.detail
      });
    },
    // 单元格模拟点击checkbox
    checkToggle(event) {
      const {
        index
      } = event.currentTarget.dataset;
      const checkbox = this.selectComponent(`.checkboxes-${index}`);
      checkbox.toggle();
    },
    noop() {},

    cleanInfoFn() {
      //  清空搜索内容
      this.setData({
        isCardId: '',
        isName: '',
        sixSesult: [],
        params: {
          lbf1: '',
          lbf2: '',
          lbf3: '',
          lbf4: '',
          lbf5: '',
          lbf6: '',
          name: '',
          mustVisit: '1',
          cardId: '',
          pageable: {
            rows: 10,
            page: 1
          }
        }
      });
    },
    submitInfoFn() {
      // 提交搜索条件
      var that = this;
      let name = "params.name";
      let cardId = "params.cardId";
      let mustVisit = "params.mustVisit";
      let pageable = "params.pageable";
      this.setData({
        interviewSixInfo: [],
        hasMoreSix: true,
        [name]: that.data.isName,
        [cardId]: that.data.isCardId,
        [mustVisit]: '1',
        [pageable]: {
          rows: 10,
          page: 1
        }
      });
      this.getData();
    },
    checkDetails(e) {
      wx.navigateTo({
        url: '/pages/personDetails/index?id= ' + e.currentTarget.dataset.id + '&cardId=' + e.currentTarget.dataset.cardid + '&name=' + e.currentTarget.dataset.name 
      })
    }
  }
})