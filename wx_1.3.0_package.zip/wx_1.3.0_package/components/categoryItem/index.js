Component({
  options: {
    styleIsolation: 'apply-shared' 
  },
  /** 
   * 组件的属性列表 
   */
  properties: {
    text: {            // 属性名  
      type: String,
      value: ''
    },
    image: {
      type: String,
      value: ''
    },
    url: {
      type: String,
      value: ''
    },
    message: {
      type: String,
      value: ''
    },
  },
  /** 
   * 组件的初始数据 
   */
  data: {
    
  },
  /** 
   * 组件的方法列表 
   */
  methods: {
    onClickCategory(e) {
      let message = e.currentTarget.dataset['message'];
      wx.showToast({
        title: message,
        icon: "none",
        duration: 1000
      })
    }
  }
})