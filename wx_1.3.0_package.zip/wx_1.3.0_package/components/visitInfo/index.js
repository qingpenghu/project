// components/visitInfo/index.js
const call = require("../../utils/request.js");
const callData = require("../../utils/util.js");
let app = getApp();

import Toast from '../../vant-weapp/toast/toast';

Component({
  /**
   * 组件的属性列表
   */
  properties: {
    detailsId: {
      type: String,
      value: ''
    },
    detailCard: {
      type: String,
      value: ''
    },
    name: {
      type: String,
      value: ''
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    visitInfoArr: [],
    hasMore: true,
    fileGuid: '',
    params: {
      cardId: '',
      pageable: {
        rows: 10,
        page: 1
      }
    },
		isRefresh: false, // 是否需要刷新页面，更新数据
  },

  /**
   * 组件挂载后执行 ready
   */
  ready: function() {
    let that = this;
    let paramCardId = 'params.cardId'
    this.setData({
      fileGuid: that.data.detailsId.trim(),
      [paramCardId]: that.data.detailCard.trim()
    });
    this.getData();
  },
  /**
   * 组件的方法列表
   */
  methods: {
    getData() {
      let that = this;
      if (!that.data.hasMore) {
        return
      }
      call.postData('/admin/personalFilesRecord/list', this.data.params, function(res) { //  请求成功
        if (res.code == 200) {
          if (that.data.params.pageable.page == 1) {
            wx.hideLoading();
            if (res.data && res.data.total <= that.data.params.pageable.rows) {
              that.setData({
                hasMore: false
              })
            }
          } else {
            if (res.data && that.data.params.pageable.page >= res.data.totalPages) {
              that.data.hasMore = false;
            }
          }
          that.data.params.pageable.page++;
					if(that.data.isRefresh){
						that.data.isRefresh = false;
					}
					that.data.visitInfoArr = that.data.visitInfoArr.concat(res.data.content || []);
          
          // that.data.visitInfoArr.forEach(function(item,index){
          //   // item.cardImg = call.hostUrl + '/admin/image/get?imageId=' + item.cardImage || '/images/person_avatar.png';
          //   item.cardImg = call.hostUrl + item.cardImageUrl || '/images/person_avatar.png';
          // })
          that.setData({
            visitInfoArr: that.data.visitInfoArr,
            hasMore: that.data.hasMore
          })
        } else {
          Toast(res.msg)
        }

      }, function(req) {}) //  请求失败
    },
    showLoadingMore: function() {
      this.setData({
        hasMore: this.data.hasMore
      })
    },
    hideLoadingMore: function() {
      this.setData({
        hasMore: this.data.hasMore
      })
    },
    onContactButton: function() {
      // 触底时父页面调用
      var that = this;
      // 显示加载图标
      this.showLoadingMore();
      this.getData();
    },
    checkDetails(e) {
      wx.navigateTo({
        url: '/pages/addVisitInfo/index?id=' + e.currentTarget.dataset.id + '&cardId=' + e.currentTarget.dataset.cardid + '&name=' + this.data.name
      })
    },
    addPersonInfo(e) {
      wx.navigateTo({
        url: '/pages/addVisitInfo/index?cardId=' + this.data.params.cardId + '&name=' + this.data.name
      })
    },
		getNewData: function(){
			let that = this;
			that.setData({
				visitInfoArr: [],
				fileGuid: that.data.fileGuid,
			  hasMore: true,
			  params: {
					cardId: that.data.params.cardId,
			    pageable: {
			      rows: 10,
			      page: 1
			    }
			  },
			  isRefresh: false, // 是否需要刷新页面，更新数据
			})
			that.getData();
		}
  }
})