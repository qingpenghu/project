// components/interviewList/index.js
const call = require("../../../utils/request.js");
const callTime = require("../../../utils/util.js");
let app = getApp();
import Toast from '../../../vant-weapp/toast/toast';
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    planId: {
      type: String,
      value: ''
    },
		content: {
		  type: String,
		  value: ''
		},
		images: {
		  type: Array,
		  value: []
		},
		videos: {
		  type: Array,
		  value: []
		},
		showImgs: {
			type: Array,
			value: []
		},
		id: {
			type: String,
			value: ''
		},
		isCreator: {
			type: String,
			value: ''
		}
  },

  /**
   * 组件的初始数据
   */
  data: {
		content: '', // 活动记录内容
    images: [], // 活动记录图片数组
    videos: [], // 活动记录视频数组
		showImgs: [], // 图片预览时需要的数组
		id: '', // 走访活动报告的id
		// isCreator: false,
    hasMore: true,
    params: {
      planId: ''
	},
	photoArray:[],
	videosArray:[],
	imageUpdateBtn:true, // 上传图片按钮开关
  },
	onLoad: function(e) {
		// 获取url中传过来的值 isCreator
		// this.setData({
		//   isCreator: e.isCreator == 'true' ? true : false
		// })
	},
  /**
   * 组件挂载后执行 ready
   */
  ready: function() {
    wx.showLoading();
		let formPlanId = "params.planId";
		let that = this;
		this.setData({
			[formPlanId]: that.data.planId.trim() || '',
			// isCreator: Boolean(that.data.isCreator)
		})
    this.getData();
  },

  /**
   * 组件的方法列表
   */
  methods: {
    getData: function() {
      let that = this;
      call.getData('/interview/report/info?id=' + this.data.params.planId, function(res) {
        if (that.data) {
          wx.hideLoading();
        }
				if (res.code == 1102) { // 该走访报告不存在
					Toast({
						message: '该走访报告不存在',
						selector: '#van-toast',
						context: that
					});
					return false;
				}
				if(res.code != 200){
					Toast({
						message: '数据获取失败，请重试',
						selector: '#van-toast',
						context: that
					});
					return false;
				}
				that.data.content = res.data.content || ''; // 活动记录内容
        that.data.photoArray = res.data.images || []; // 活动记录图片
        that.data.videos = res.data.videos || []; // 活动记录视频
				that.data.id = res.data.id || []; // 
				
				let imgArr = res.data.images || [];
				imgArr.map(function(item){
					that.data.showImgs.push(item.url)
				})
				
				that.data.hasMore = false;
				
			that.setData({
				content: that.data.content,
				photoArray: that.data.photoArray,
				videos: that.data.videos,
				videosArray:that.data.videos,
				id: that.data.id,
				hasMore: that.data.hasMore,
				imageUpdateBtn: that.data.photoArray.length > 10 ? false:true ,
			})
      }, function(req) {})
    },
		
		previewImageItem: function (e) { // 预览上传图片
			var current = e.target.dataset.src;
			wx.previewImage({
			  current: current, // 当前显示图片的http链接  
			  urls: this.data.showImgs // 需要预览的图片http链接列表  
			})
		  },
		  /**
		 * 删除图片
		 */
		closeImgFn:function(e){
			let that = this;
			let index = e.currentTarget.dataset.dix;
			this.data.photoArray.splice(index,1);
			this.setData({
			photoArray: that.data.photoArray,
			imageUpdateBtn: that.data.photoArray.length > 10 ? false:true ,
			})
		},
		contentChange: function(e) { // 输入框监听事件
			this.setData({
			  content: e.detail.value || ''
			})
		},
		formSubmit: function(e) { // 保存走访活动记录内容
			let that = this;
			let imgIds = [], videoIds= [];
			wx.showLoading()
			that.data.photoArray.map(item => {
				imgIds.push(item.fileId);
			})
			that.data.videosArray.map(item => {
				videoIds.push(item.fileId);
			})
			setTimeout(function(){
				let params = {
					// interviewId: that.data.planId || '', // 计划ID
					id: e.currentTarget.dataset.id || '', // 活动报告ID
					content: that.data.content || e.currentTarget.dataset.value || '',
					imageIds:imgIds.join(),// 活动图片
					videoIds:videoIds.join(), // 活动视频
				};
				// let $url = params.id ? '/miniprogram/interview/report/update' : '/interview/report/create';
				let $url = params.id ? '/interview/report/update' : '/interview/report/create';
				call.postData($url, params, function(res) {
					Toast({
						message: '保存成功',
						selector: '#van-toast',
						context: that
					});
					wx.hideLoading()
				}, function(req) {})
			}, 600);
		},
    showLoadingMore: function() {
      this.setData({
        hasMore: this.data.hasMore
      })
    },
    hideLoadingMore: function() {
      this.setData({
        hasMore: this.data.hasMore
      })
	},
	openCamera: function(){
		let that = this;
		let count = 10-this.data.photoArray.length;
		wx.chooseImage({
		  count: count,
		  sizeType: ['original', 'compressed'],
		  sourceType: ['album', 'camera'],
		  success(res) {
			// tempFilePath可以作为img标签的src属性显示图片
			
			let tempFilePaths = res.tempFilePaths;
			tempFilePaths.forEach(function(item,index){
			  wx.showLoading()
			  wx.uploadFile({
				url: call.hostUrl + '/admin/image/uploadFile', //仅为示例，非真实的接口地址
				header: call.getHeader(),
				filePath: item,
				name: 'file',
				success(res) {
				  wx.hideLoading()
				  let data = JSON.parse(res.data);
				  if (data.code != 200) {
					Toast("上传失败，" + data.msg + "！");
					return false;
				  }
				  let imageFile= {
					  url: data.data.url,
					  id: data.data.fileId,
					  fileId:data.data.fileId,
				  }
				  that.data.photoArray.push(imageFile);
				  that.data.showImgs.push(data.data.url)
				  if (that.data.photoArray.length > 50){
					that.data.photoArray = that.data.photoArray.slice(0, 49);
				  }
				  that.setData({
					photoArray: that.data.photoArray,
					imageUpdateBtn: that.data.photoArray.length > 10 ? false:true ,
				  });
				},
				fail(req) {
				  wx.hideLoading()
				  Toast(req.msg);
				}
			  })
			});
		  }, fail(){
			wx.hideLoading()
		  }
		})
	  },
	  chooseVideoFn: function() {
		  const that = this;
		wx.chooseVideo({
			sourceType: ['album','camera'],
			maxDuration: 15,
			camera: 'back',
			compressed:true,
			success(res) {
				console.log(res)
			// return
				let videoSize = (res.size / 1024 / 1024 );
				if( videoSize > 25 ) {
					Toast("上传视频文件过大")
					return 
				}
				console.log( 'videoSize',videoSize )
				let tempFilePath = res.tempFilePath;
				wx.showLoading()
				wx.uploadFile({
					url: call.hostUrl + '/admin/image/uploadFile', //仅为示例，非真实的接口地址
					header: call.getHeader(),
					filePath: tempFilePath,
					name: 'file',
					success(res) {
						wx.hideLoading()
						let data = JSON.parse(res.data);
						if (data.code != 200) {
						Toast("上传失败，" + data.msg + "！");
						return false;
						}
						let videosFile= {
							url: data.data.url,
							id: data.data.fileId,
							fileId:data.data.fileId,
						}
						that.data.videosArray=[videosFile];

						// that.data.videosArray.push(videosFile)
					  
						Toast("上传成功");
							that.setData({
							videosArray: that.data.videosArray
						});
					},
					fail(req) {
						wx.hideLoading()
						Toast(req.msg);
					}
				  
				});

			}, fail(){
				wx.hideLoading()
			  }
		})
	  },
	  audioPlay: function (param) { 
		  console.log("params",param)
		  if( param.type == 'play' ) {
			wx.createInnerAudioContext('myVideo').play()
		  }
		 
	   },
	   audioError: function (err) {
		   console.log(err)
	   },
	  openCameraVideo: function() {
		const that = this;
		if( that.data.videosArray.length > 0) {
			wx.showModal({
				title: '提示',
				content: '上传视频将覆盖原视频,是否确认上传？',
				success (res) {
					if( res.confirm ) {
						that.chooseVideoFn()
					}
				}
			  })
		}else{
			that.chooseVideoFn()
		}
		
		
	  }
	  
  }
})