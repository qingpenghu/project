// components/interviewList/index.js
const call = require("../../../utils/request.js");
const callTime = require("../../../utils/util.js");
let app = getApp();
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    planId: {
      type: String,
      value: ''
    },
		totalConsolationInfo: {
		  type: Object,
		  value: {}
		},
		consolationInfo: {
		  type: Array,
		  value: []
		}
  },

  /**
   * 组件的初始数据
   */
  data: {
		totalConsolationInfo: {},
    consolationInfo: [],
    hasMore: true,
    params: {
      planId: ''
    },
  },
  /**
   * 组件挂载后执行 ready
   */
  ready: function() {
    wx.showLoading();
		let formPlanId = "params.planId";
		let that = this;
		this.setData({
			[formPlanId]: that.data.planId.trim() || ''
		})
    this.getData();
  },

  /**
   * 组件的方法列表
   */
  methods: {
    getData: function() {
      let that = this;
      call.getData('/interview/consolation?id=' + this.data.params.planId, function(res) {
        if (that.data && that.data.totalConsolationInfo) {
          wx.hideLoading();
        }
				that.data.totalConsolationInfo = res.data.totalConsolationInfo || {};
        that.data.consolationInfo = that.data.consolationInfo.concat(res.data.consolationInfo || []);
				that.data.hasMore = false;
        that.setData({
          totalConsolationInfo: that.data.totalConsolationInfo,
          consolationInfo: that.data.consolationInfo,
          hasMore: that.data.hasMore
        })
      }, function(req) {})
    },
    showLoadingMore: function() {
      this.setData({
        hasMore: this.data.hasMore
      })
    },
    hideLoadingMore: function() {
      this.setData({
        hasMore: this.data.hasMore
      })
    }
  }
})