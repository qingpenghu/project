// components/interviewList/index.js
const call = require("../../../utils/request.js");
const callTime = require("../../../utils/util.js");
const QQMapWX = require("../../../libs/qqmap-wx-jssdk.js");
let app = getApp();

import Toast from '../../../vant-weapp/toast/toast';

// 实例化API核心类
var qqmapsdk = new QQMapWX({
	key: 'NT2BZ-FEZKJ-TRYF4-K3Q4A-W3SCE-SIBEN' // 必填
});
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    planId: {
      type: String,
      value: ''
    },
		visitorLoadShow: {
		  type: Boolean,
		  value: true
		}
  },

  /**
   * 组件的初始数据
   */
  data: {
    interviewListInfo: [],
    hasMore: true,
    params: {
      planId: ''
    },
  },
  /**
   * 组件挂载后执行 ready
   */
  ready: function() {
    wx.showLoading();
		let formPlanId = "params.planId";
		let that = this;
		this.setData({
			[formPlanId]: that.data.planId.trim() || ''
		})
    this.getData();
  },

  /**
   * 组件的方法列表
   */
  methods: {
    getData: function() {
      let that = this;
      call.getData('/interview/veterans?id=' + this.data.params.planId, function(res) {
        if (res.data && res.data.intervieweeList) {
          wx.hideLoading();
        }
        that.data.interviewListInfo = res.data.intervieweeList || [];
				that.data.hasMore = false;
        that.setData({
          interviewListInfo: that.data.interviewListInfo,
          hasMore: that.data.hasMore
        })
      }, function(req) {})
    },
		callPhone: function(e) { // 在走访对象列表内点击电话按钮
			if(e.currentTarget.dataset.tel){
				wx.makePhoneCall({
					phoneNumber: e.currentTarget.dataset.tel,
				})
			}
		},
		mapNavigation: function(e) { // 走访人员地址导航
			let that= this;
			let location = e.currentTarget.dataset.location || '';
			console.log('location', location)
			
			//调用地址解析接口
			qqmapsdk.geocoder({
				//获取表单传入地址
				address: location, //地址参数，例：固定地址，address: '北京市海淀区彩和坊路海淀西大街74号'
				success: function(res) {//成功后的回调
					var res = res.result;
					var latitude = res.location.lat;
					var longitude = res.location.lng;
					console.log('res', res)
					wx.openLocation({
						latitude,
						longitude,
						name: location,
						scale: 18
					})
					
					//根据地址解析在地图上标记解析地址位置
					// _this.setData({ // 获取返回结果，放到markers及poi中，并在地图展示
					// 	markers: [{
					// 		id: 0,
					// 		title: res.title,
					// 		latitude: latitude,
					// 		longitude: longitude,
					// 		iconPath: './resources/placeholder.png',//图标路径
					// 		width: 20,
					// 		height: 20,
					// 		callout: { //可根据需求是否展示经纬度
					// 			content: latitude + ',' + longitude,
					// 			color: '#000',
					// 			display: 'ALWAYS'
					// 		}
					// 	}],
					// 	poi: { //根据自己data数据设置相应的地图中心坐标变量名称
					// 		latitude: latitude,
					// 		longitude: longitude
					// 	}
					// });
				},
				fail: function(error) {
					Toast({
						// message: '目标地址过于精简无法定位',
						message: error.message,
						selector: '#van-toast',
						context: that
					});
				},
				complete: function(res) {
				}
			})
		},
    showLoadingMore: function() {
      this.setData({
        hasMore: this.data.hasMore
      })
    },
    hideLoadingMore: function() {
      this.setData({
        hasMore: this.data.hasMore
      })
    },
    onContactButton: function() {
      // 触底时父页面调用
      var that = this;
      // 显示加载图标
      this.showLoadingMore();
      this.getData();
    },
    checkDetails(e) {
      wx.navigateTo({
        url: '/pages/personDetails/index?id= ' + e.currentTarget.dataset.id + '&cardId=' + e.currentTarget.dataset.cardid + '&name=' + e.currentTarget.dataset.name
      })
    }
  }
})