// components/interviewList/index.js
const call = require("../../../utils/request.js");
const callTime = require("../../../utils/util.js");
let app = getApp();
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    planId: {
      type: String,
      value: ''
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    interviewListInfo: [],
    hasMore: true,
    params: {
      planId: ''
    },
  },
  /**
   * 组件挂载后执行 ready
   */
  ready: function() {
    wx.showLoading();
		let formPlanId = "params.planId";
		let that = this;
		this.setData({
			[formPlanId]: that.data.planId.trim() || ''
		})
    this.getData();
  },

  /**
   * 组件的方法列表
   */
  methods: {
    getData: function() {
      let that = this;
      call.getData('/interview/interviewers?id=' + this.data.params.planId, function(res) {
        if (that.data && that.data.interviewerList) {
          wx.hideLoading();
        }
        that.data.interviewListInfo = that.data.interviewListInfo.concat(res.data.interviewerList || []);
				that.data.hasMore = false;
        that.setData({
          interviewListInfo: that.data.interviewListInfo,
          hasMore: that.data.hasMore
        })
      }, function(req) {})
    },
		callPhone: function(e) { // 在随访人员列表内点击电话按钮
			if(e.currentTarget.dataset.mobilephone){
				wx.makePhoneCall({
					phoneNumber: e.currentTarget.dataset.mobilephone,
				})
			}
		},
    showLoadingMore: function() {
      this.setData({
        hasMore: this.data.hasMore
      })
    },
    hideLoadingMore: function() {
      this.setData({
        hasMore: this.data.hasMore
      })
    },
    onContactButton: function() {
      // 触底时父页面调用
      var that = this;
      // 显示加载图标
      this.showLoadingMore();
      this.getData();
    },
    // checkDetails(e) {
    //   console.log(e)
    //   wx.navigateTo({
    //     url: '/pages/personDetails/index?id= ' + e.currentTarget.dataset.id + '&type=1&cardId=' + e.currentTarget.dataset.cardid
    //   })
    // }
  }
})