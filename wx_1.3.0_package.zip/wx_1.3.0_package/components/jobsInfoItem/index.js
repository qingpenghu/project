Component({
  options: {
    styleIsolation: 'apply-shared' 
  },
  /** 
   * 组件的属性列表 
   */
  properties: {
    num: {            // 属性名  
      type: String,
      value: ''
    },
    text: {
      type: String,
      value: ''
    }
  },
  /** 
   * 组件的初始数据 
   */
  data: {
    
  },
  /** 
   * 组件的方法列表 
   */
  methods: {
  //   showToast(text, time) {
  //     this.setData({
  //       toastShow: !this.data.toastShow,
  //       text: text
  //     })
  //   }
  }
})