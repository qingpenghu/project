// components/interviewHaveDown/index.js
const call = require("../../utils/request.js");
const callTime = require("../../utils/util.js");
let app = getApp();
import Toast from '../../vant-weapp/toast/toast';

Component({
  /**
   * 组件的属性列表
   */
  properties: {
    slidingDownShow: {
      type: Boolean,
      value: true
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    evaluationAnalyzeData: [],
    hasMore: true,
    params: {
      examineName:"",
      pageable: {
        rows: 15,
        page: 1
      }
    },

  },
  /**
   * 组件挂载后执行 ready
   */
  ready: function () {
    // wx.showLoading();
    // this.getData();
  },

  /**
   * 组件的方法列表
   */
  methods: {
    getData: function () {
      let that = this;
      if (!that.data.hasMore) {
        return
      }
      call.postData('/admin/examine/statistics', that.data.params, function (res) {
        if (res.code == 200) {
          if (that.data.params.pageable.page == 1) {
            that.data.evaluationAnalyzeData =  []
            wx.hideLoading();
            if (res.data && res.data.total <= that.data.params.pageable.rows) {
              that.setData({
                hasMore: false
              })
            }
          } else {
            if (res.data && that.data.params.pageable.page >= res.data.totalPages) {
              that.data.hasMore = false;
            }
          }
          that.data.params.pageable.page++;
          that.data.evaluationAnalyzeData = that.data.evaluationAnalyzeData.concat(res.data.content || []);
          that.setData({
            evaluationAnalyzeData: that.data.evaluationAnalyzeData,
            hasMore: that.data.hasMore
          })
        } else {
          Toast(res.msg);
          return false;
        }
      }, function (req) {})
    },
    showLoadingMore: function () {
      this.setData({
        hasMore: this.data.hasMore
      })
    },
    hideLoadingMore: function () {
      this.setData({
        hasMore: this.data.hasMore
      })
    },
    onContactButton: function () { // 触底加载更多
      var that = this;
      // 显示加载图标
      this.showLoadingMore();
      this.getData();
    },
    onChangeName(event) {
      // event.detail 为当前输入的值   input 姓名的value
      this.setData({
        queryInputName: event.type == "blur" ? event.detail.value : event.detail
      });
    },
    cleanInfoFn() {
      //  清空搜索内容
      this.setData({
        queryInputName:'',
        params: {
          examineName:'',
          pageable: {
            rows: 10,
            page: 1
          }
        }
      });
    },
    submitInfoFn() {
      // 提交搜索条件
      let that = this;
     
      this.setData({
        hasMore: true,
        params: {
          examineName: that.data.queryInputName,
          pageable: {
            rows: 15,
            page: 1
          }
        },
      });
      this.getData();
    },
    jumpDetail(e) {
      let item = e.currentTarget.dataset.item;
      let that = this;
      wx.setStorage({
        key: 'evaluationAnalyzeDetail',
        data: item,
      })
      wx.navigateTo({
        url: '/pages/examineEvaluation/evaluationAnalyzeDetail/index'
      })
    }
  }
})