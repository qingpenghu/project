// components/interviewList/index.js
const call = require("../../utils/request.js");
const callTime = require("../../utils/util.js");
let app = getApp();
import Toast from '../../vant-weapp/toast/toast';

Component({
  /**
   * 组件的属性列表
   */
  properties: {
    slidingListShow: {
      type: Boolean,
      value: true
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    interviewListInfo: [],
    hasMore: true,
    params: {
      name: '',
      cardId: '',
      joinStartTime: '',
      joinEndTime: '',
      quitStartTime: '',
      quitEndTime: '',
      pageable: {
        rows: 10,
        page: 1
      },
      page: 1,
      pageSize: 10
    },
    queryInputName: '',
    queryInputCardId: '',
    enrolStartTime: '',
    enrolEndTime: '',
    retirementStartTime: '',
    retirementEndTime: '',
    enrolStartFlag: false,
    enrolEndFlag: false,
    retireStartFlag: false,
    retireEndFlag: false,
    enrolStartPicker: {
      currentDate: new Date().getTime(),
      minDate: new Date(1949, 10, 1).getTime(), // 1949-09-30凌晨24点整
      maxDate: new Date().getTime()
    },
    enrolEndPicker: {
      currentDate: new Date().getTime(),
      minDate: new Date(1949, 10, 1).getTime(), // 1949-09-30凌晨24点整
      maxDate: new Date().getTime()
    },
    relStartPicker: {
      currentDate: new Date().getTime(),
      minDate: new Date(1949, 10, 1).getTime(), // 1949-09-30凌晨24点整
      maxDate: new Date().getTime()
    },
    relEndPicker: {
      currentDate: new Date().getTime(),
      minDate: new Date(1949, 10, 1).getTime(), // 1949-09-30凌晨24点整
      maxDate: new Date().getTime()
    },
    pickerTimeFormatter(type, value) {
      if (type === 'year') {
        return `${value}年`;
      } else if (type === 'month') {
        return `${value}月`;
      }
      return value;
    }
  },
  /**
   * 组件挂载后执行 ready
   */
  ready: function () {
    // this.getData();
  },

  /**
   * 组件的方法列表
   */
  methods: {
    getData: function () {
      let that = this;
      if (!that.data.hasMore) {
        return
      }
      // call.postData('/admin/personalFilesBase/list', that.data.params, function (res) {
      call.postData('/admin/OnePersonOneFile/queryOnePersonOneFileList', that.data.params, function (res) {
        if (res.code != 200) {
          Toast(res.msg);
          return false;
        } else {
          if (that.data.params.pageable.page == 1) {
            wx.hideLoading();
            if (res.data && res.data.total <= that.data.params.pageable.rows) {
              that.setData({
                hasMore: false
              })
            }
          } else {
            if (res.data && that.data.params.pageable.page >= res.data.totalPages) {
              that.data.hasMore = false;
            }
          }
          that.data.params.pageable.page++;
          that.data.params.page++;
          that.data.interviewListInfo = that.data.interviewListInfo.concat(res.data.content || []);
          that.data.interviewListInfo.forEach(function (item, index) {
            // item.cardImg = call.hostUrl + '/admin/image/get?imageId=' + item.cardImage || '/images/person_avatar.png';
            item.cardImg = item.cardImageUrl || '/images/person_avatar.png';
            item.personType = callTime.makeSelectOrChecked(item.personType || '', callTime.dataDictionary().perCategory);
          })
          that.setData({
            interviewListInfo: that.data.interviewListInfo,
            hasMore: that.data.hasMore
          })
        }
        
      }, function (req) { Toast(req.msg); })
    },
    showLoadingMore: function () {
      this.setData({
        hasMore: this.data.hasMore
      })
    },
    hideLoadingMore: function () {
      this.setData({
        hasMore: this.data.hasMore
      })
    },
    onContactButton: function () {
      // 触底时父页面调用
      var that = this;
      // 显示加载图标
      this.showLoadingMore();
      this.getData();
    },
    onChangeName(event) {
      // event.detail 为当前输入的值   input 姓名的value
      this.setData({
        queryInputName: event.type == "blur" ? event.detail.value : event.detail
      });
    },
    onChangeCardId(event) {
      // event.detail 为当前输入的值   input 身份证号的value
      this.setData({
        queryInputCardId: event.type == "blur" ? event.detail.value : event.detail
      });
    },
    onEnrolStartTime(event) {
      //  开始时间获取焦点 打开底部时间选择弹出层
      this.setData({
        enrolStartFlag: true
      });
    },
    onEnrolStartTimeClose() {
      // 关闭底部时间弹出层
      this.setData({
        enrolStartFlag: false
      });
    },
    onEnrolConfirmStartTime(event) {
      // 时间选择 完成的确定
      let that = this;
      this.setData({
        enrolStartPicker: {
          currentDate: event.detail,
          minDate: new Date(1949, 10, 1).getTime(), // 1949-09-30凌晨24点整
          maxDate: new Date().getTime()
        },
        enrolStartTime: callTime.timestampFn(event.detail, 'Y/M/D'),
        enrolStartFlag: false
      });
    },
    onEnrolEndTime(event) {
      //  开始时间获取焦点 打开底部时间选择弹出层
      this.setData({
        enrolEndFlag: true
      });
    },
    onEnrolEndTimeClose() {
      // 关闭底部时间弹出层
      this.setData({
        enrolEndFlag: false
      });
    },
    onEnrolConfirmEndTime(event) {
      // 时间选择 完成的确定
      let that = this;
      this.setData({
        enrolEndPicker: {
          currentDate: event.detail,
          minDate: new Date(1949, 10, 1).getTime(), // 1949-09-30凌晨24点整
          maxDate: new Date().getTime()
        },
        enrolEndTime: callTime.timestampFn(event.detail, 'Y/M/D'),
        enrolEndFlag: false
      });
    },

    onRelStartTime(event) {
      //  结束时间获取焦点 打开底部时间选择弹出层
      this.setData({
        retireStartFlag: true
      });
    },
    onRelEndTimeClose() {
      // 关闭底部时间弹出层
      this.setData({
        retireStartFlag: false
      });
    },
    onRelConfirmStartTime(event) {
      // 时间选择 完成的确定
      let that = this;
      this.setData({
        relStartPicker: {
          currentDate: event.detail,
          minDate: new Date(1949, 10, 1).getTime(), // 1949-09-30凌晨24点整
          maxDate: new Date().getTime()
        },
        retirementStartTime: callTime.timestampFn(event.detail, 'Y/M/D'),
        retireStartFlag: false
      });
    },
    onRelEndTime(event) {
      //  结束时间获取焦点 打开底部时间选择弹出层
      this.setData({
        retireEndFlag: true
      });
    },
    onEndTimeClose() {
      // 关闭底部时间弹出层
      this.setData({
        retireEndFlag: false
      });
    },
    onConfirmEndTime(event) {
      // 时间选择 完成的确定
      let that = this;
      this.setData({
        relEndPicker: {
          currentDate: event.detail,
          minDate: new Date(1949, 10, 1).getTime(), // 1949-09-30凌晨24点整
          maxDate: new Date().getTime()
        },
        retirementEndTime: callTime.timestampFn(event.detail, 'Y/M/D'),
        retireEndFlag: false
      });
    },
    cleanInfoFn() {
      //  清空搜索内容
      this.setData({
        queryInputName: '',
        queryInputCardId: '',
        enrolStartTime: '',
        enrolEndTime: '',
        retirementStartTime: '',
        retirementEndTime: '',
        params: {
          name: '',
          cardId: '',
          joinStartTime: '',
          joinEndTime: '',
          quitStartTime: '',
          quitEndTime: '',
          pageable: {
            rows: 10,
            page: 1
          },
          page: 1,
          pageSize: 10
        }
      });
    },
    submitInfoFn() {
      // 提交搜索条件
      var that = this;

      let joinStartTimeArr, joinStartTimeStr, joinEndTimeArr, joinEndTimeStr, quitStartTimeArr, quitStartTimeStr, quitEndTimeArr, quitEndTimeStr;
      if (that.data.enrolStartTime) {
        joinStartTimeArr = that.data.enrolStartTime.split('/');
        joinStartTimeStr = joinStartTimeArr.join('');
      }
      if (that.data.enrolEndTime) {
        joinEndTimeArr = that.data.enrolEndTime.split('/');
        joinEndTimeStr = joinEndTimeArr.join('');
      }
      if (that.data.retirementStartTime) {
        quitStartTimeArr = that.data.retirementStartTime.split('/');
        quitStartTimeStr = quitStartTimeArr.join('');
      }
      if (that.data.retirementEndTime) {
        quitEndTimeArr = that.data.retirementEndTime.split('/');
        quitEndTimeStr = quitEndTimeArr.join('');
      }

      this.setData({
        interviewListInfo: [],
        hasMore: true,
        params: {
          name: that.data.queryInputName,
          cardId: that.data.queryInputCardId,
          joinStartTime: joinStartTimeStr,
          joinEndTime: joinEndTimeStr,
          quitStartTime: quitStartTimeStr,
          quitEndTime: quitEndTimeStr,
          pageable: {
            rows: 10,
            page: 1
          },
          page: 1,
          pageSize: 10
        }
      });
      this.getData();
    },
    checkDetails(e) {
      wx.navigateTo({
        url: '/pages/personDetails/index?id= ' + e.currentTarget.dataset.id + '&cardId=' + e.currentTarget.dataset.cardid + '&name='+ e.currentTarget.dataset.name
      })
    }
  }
})