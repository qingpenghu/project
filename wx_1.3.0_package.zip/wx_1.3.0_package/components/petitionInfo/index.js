// components/visitInfo/index.js
const call = require("../../utils/request.js");
const callData = require("../../utils/util.js");
let app = getApp();
import Toast from '../../vant-weapp/toast/toast';

Component({
  /**
   * 组件的属性列表
   */
  properties: {
    detailsId: {
      type: String,
      value: ''
    },
    detailCard: {
      type: String,
      value: ''
    },
    name: {
      type: String,
      value:''
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    visitInfoArr: [],
    hasMore: true,
    fileGuid: '',
    params: {
      veteransId: '',
      pageable: {
        rows: 10,
        page: 1
      }
    }

  },

  /**
   * 组件挂载后执行 ready
   */
  ready: function() {
    let that = this;
    let paramVeteranid = 'params.veteransId'
    this.setData({
      // [paramVeteranid]: 'ea7db54e1d56469f9b81950682aceerr'
      [paramVeteranid]: that.data.detailsId.trim() || ''
    });
    // this.getData();
    wx.removeStorage({
      key: 'petitionDetail'
    })
  },
  /**
   * 组件的方法列表
   */
  methods: {
    getData() {
      let that = this;
      if (!that.data.hasMore) {
        return
      }
      call.getData('/admin/ComplaintReporting/queryXFRecordListByNamaAndCradId?name=' + that.data.name + '&sfzhm=' + that.data.detailCard, function(res) { //  请求成功
        if (res.code == 200) {
          wx.hideLoading();
          let dataList = res.data.data;
          if( dataList && Array.isArray( dataList ) ) {
            dataList.forEach(item => {
              item.time = that.dateHandle(item.time)
              item.retiredTime = that.dateHandle(item.retiredTime)
              item.militaryTime = that.dateHandle(item.militaryTime)
            })
          }else{
            dataList=[]
          }
          that.setData({
            hasMore: false,
            visitInfoArr:dataList
          })
        } else {
          Toast(res.msg)
        }

      }, function(req) {}) //  请求失败
    },
    showLoadingMore: function() {
      this.setData({
        hasMore: this.data.hasMore
      })
    },
    hideLoadingMore: function() {
      this.setData({
        hasMore: this.data.hasMore
      })
    },
    // onContactButton: function() {
    //   // 触底时父页面调用
    //   var that = this;
    //   // 显示加载图标
    //   this.showLoadingMore();
    //   this.getData();
    // },
    checkDetails(e) {
      let that = this;
      wx.setStorage({
        key: 'petitionDetail',
        data: e.currentTarget.dataset.item,
      })
      wx.navigateTo({ //  跳转走访计划活动
        url: '/pages/petitionDetail/index'
      })
    },
    dateHandle(data) {
      if ( data && data.length > 0 ) {
        let yyyy =Number( data.substring(0,4))
        let mm = Number(data.substring(4,6) )
        let dd = Number(data.substring(6,8))
        return yyyy + "/"+ mm + "/" +dd
      }else{
        return data
      }
    }
  }
})