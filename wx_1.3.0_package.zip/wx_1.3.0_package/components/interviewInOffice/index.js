// components/interviewInOffice/index.js
const call = require("../../utils/request.js");
const callTime = require("../../utils/util.js");
let app = getApp();
import Toast from '../../vant-weapp/toast/toast';

Component({
  /**
   * 组件的属性列表
   */
  properties: {
    slidingInOffShow: {
      type: Boolean,
      value: true
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    interviewOfficeInfo: [],
    hasMoreOffice: true,
    params: {
      recStatus:'1',
      startTime:'',
      endTime:'',
      pageable: {
        rows: 10,
        page: 1
      }
    },
    queryInputStartTime: '',
    queryInputEndTime: '',
    pickerTimeStartFlag: false,
    pickerTimeEndFlag: false,
    datetimeStartPicker: {
      currentDate: new Date().getTime(),
      minDate: new Date(1949, 10, 1).getTime(), // 1949-09-30凌晨24点整
      maxDate: new Date().getTime()
    },
    datetimeEndPicker: {
      currentDate: new Date().getTime(),
      minDate: new Date(1949, 10, 1).getTime(), // 1949-09-30凌晨24点整
      maxDate: new Date().getTime()
    },
    pickerTimeFormatter(type, value) {
      if (type === 'year') {
        return `${value}年`;
      } else if (type === 'month') {
        return `${value}月`;
      }
      return value;
    }
  },
  /**
   * 组件挂载后执行 ready
   */
  ready: function () {
    // wx.showLoading();
    // this.getData();
  },

  /**
   * 组件的方法列表
   */
  methods: {
    getData: function () {
      let that = this;
      if (!that.data.hasMoreOffice) {
        return
      }
      call.postData('/admin/personalFilesRecord/list', that.data.params, function (res) {
        if (res.code == 200) {
          if (that.data.params.pageable.page == 1) {
            wx.hideLoading();
            if (res.data && res.data.total <= that.data.params.pageable.rows) {
              that.setData({
                hasMoreOffice: false
              })
            }
          } else {
            if (res.data && that.data.params.pageable.page >= res.data.totalPages) {
              that.data.hasMoreOffice = false;
            }
          }
          that.data.params.pageable.page++;
          that.data.interviewOfficeInfo = that.data.interviewOfficeInfo.concat(res.data.content || []);
          that.data.interviewOfficeInfo.forEach(function (item, index) {
            item.cardImg = item.cardImageUrl || '/images/person_avatar.png';
            item.personType = callTime.makeSelectOrChecked(item.personType || '', callTime.dataDictionary().perCategory);
          })
          that.setData({
            interviewOfficeInfo: that.data.interviewOfficeInfo,
            hasMoreOffice: that.data.hasMoreOffice
          })
        } else {
          Toast(res.msg);
          return false;
        }
      }, function (req) { })
    },
    showLoadingMore: function () {
      this.setData({
        hasMoreOffice: this.data.hasMoreOffice
      })
    },
    hideLoadingMore: function () {
      this.setData({
        hasMoreOffice: this.data.hasMoreOffice
      })
    },
    onContactButton: function () {
      var that = this;

      // 显示加载图标
      that.showLoadingMore();
      that.getData();
    },
    onFocusStartTime(event) {
      //  开始时间获取焦点 打开底部时间选择弹出层
      this.setData({
        pickerTimeStartFlag: true
      });
    },
    onStartTimeClose() {
      // 关闭底部时间弹出层
      this.setData({
        pickerTimeStartFlag: false
      });
    },
    onConfirmStartTime(event) {
      // 时间选择 完成的确定
      let that = this;
      this.setData({
        datetimeStartPicker: {
          currentDate: event.detail,
          minDate: new Date(1949, 10, 1).getTime(), // 1949-09-30凌晨24点整
          maxDate: new Date().getTime()
        },
        queryInputStartTime: callTime.timestampFn(event.detail, 'Y/M/D'),
        pickerTimeStartFlag: false
      });
    },
    onFocusEndTime(event) {
      //  结束时间获取焦点 打开底部时间选择弹出层
      this.setData({
        pickerTimeEndFlag: true
      });
    },
    onEndTimeClose() {
      // 关闭底部时间弹出层
      this.setData({
        pickerTimeEndFlag: false
      });
    },
    onConfirmEndTime(event) {
      // 时间选择 完成的确定
      let that = this;
      this.setData({
        datetimeEndPicker: {
          currentDate: event.detail,
          minDate: new Date(1949, 10, 1).getTime(), // 1949-09-30凌晨24点整
          maxDate: new Date().getTime()
        },
        queryInputEndTime: callTime.timestampFn(event.detail, 'Y/M/D'),
        pickerTimeEndFlag: false
      });
    },
    cleanInfoFn() {
      //  清空搜索内容
      this.setData({
        queryInputStartTime: '',
        queryInputEndTime: '',
        params: {
          recStatus: '1',
          startTime: '',
          endTime: '',
          pageable: {
            rows: 10,
            page: 1
          }
        }
      });
    },
    submitInfoFn() {
      // 提交搜索条件
      let that = this;
      let startTimeArr, endTimeArr, startTimeStr, endTimeStr;
      if (that.data.queryInputStartTime) {
        startTimeArr = that.data.queryInputStartTime.split('/');
        startTimeStr = startTimeArr.join('');
      }
      if (that.data.queryInputEndTime) {
        endTimeArr = that.data.queryInputEndTime.split('/');
        endTimeStr = endTimeArr.join('');
      }
      this.setData({
        interviewOfficeInfo: [],
        hasMoreOffice: true,
        params: {
          recStatus: '1',
          startTime: startTimeStr,
          endTime: endTimeStr,
          pageable: {
            rows: 10,
            page: 1
          }
        },
      });
      this.getData();
    },
    checkDetails(e) {
      wx.navigateTo({
        url: '/pages/personDetails/index?id= ' + e.currentTarget.dataset.id + '&cardId=' + e.currentTarget.dataset.cardid + '&veteransId=' + e.currentTarget.dataset.veteransid + '&name=' + e.currentTarget.dataset.name
      })
    }
  }
})