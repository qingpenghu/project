// components/basicInfo/index.js
const call = require("../../utils/request.js");
const callData = require("../../utils/util.js");
let app = getApp();
import Toast from '../../vant-weapp/toast/toast';

Component({
  /**
   * 组件的属性列表
   */
  properties: {
    detailsId: {
      type: String,
      value: ''
    },
    detailCard: {
      type: String,
      value: ''
    },
    name: {
      type: String,
      value:''
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    fileGuid: '',
    cardId: '',
    baseInfoVO: {}, // 基本信息
    cadresInfoVO: {}, // 军队转业干部
    soldierInfoVO: {}, //退役士兵
    retiredInfoVO: {}, //军队离退休干部和退休士官
    noMilitaryInfoVO: {}, //军队无军籍离退休职工
    redArmyInfoVO: {}, // 退伍红军老战士
    demobilizationInfoVO: {}, //复员军人
    disabledInfoVO: {}, //残疾军人
    disabledWorkersInfoVO: {}, //伤残民兵民工
    martyrInfoVO: {}, //烈士遗属
    diedOnDutyInfoVO: {}, //因公牺牲军人遗属
    illnessInfoVO: {}, //病故军人遗属
    activeInfoVO: {}, //现役军人家属
    flag1: false,
    flag2: false,
    flag3: false,
    flag4: false,
    flag5: false,
    flag6: false,
    flag7: false,
    flag8: false,
    flag9: false,
    flag10: false,
    flag11: false,
    flag12: false
  },
  /**
   * 组件挂载后执行 ready
   */
  ready: function() {
    let that = this;
    this.setData({
      fileGuid: that.data.detailsId.trim(),
      cardId: that.data.detailCard.trim(),
      name: that.data.name.trim()
    });
    this.getData();
  },

  /**
   * 组件的方法列表
   */
  methods: {
    getData() {
      let that = this;
      let params = {
        cardId: this.data.cardId
      }
      // call.postData('/admin/personalFilesBase/detail', params, function(res) { //  请求成功
      call.getData('/admin/OnePersonOneFile/querySorlderRecorderByNamaAndCradId?name='+ that.data.name + '&sfzhm=' + that.data.cardId,  function(res) { //  请求成功
        if (res.code == 200) {
          // console.log("res",res)
          if (res.data) {
            // that.baseInfoFnUpdate(res.data)
            if (res.data.baseInfoVO) {
              // 基楚信息
              that.baseInfoFn(res.data.baseInfoVO);
            }
            if (res.data.cadresInfoVO) {
              //军队转业干部
              that.cadresInfoFn(res.data.cadresInfoVO);
            }
            if (res.data.soldierInfoVO) {
              //退役士兵
              that.soldierInfoFn(res.data.soldierInfoVO);
            }
            if (res.data.retiredInfoVO) {
              //军队离退休干部和退休士官
              that.retiredInfoFn(res.data.retiredInfoVO);
            }
            if (res.data.noMilitaryInfoVO) {
              //军队无军籍离退休职工
              that.noMilitaryInfoFn(res.data.noMilitaryInfoVO);
            }
            if (res.data.redArmyInfoVO) {
              //退伍红军老战士
              that.redArmyInfoFn(res.data.redArmyInfoVO);
            }
            if (res.data.demobilizationInfoVO) {
              //复员军人
              that.demobilizationInfoFn(res.data.demobilizationInfoVO);
            }
            if (res.data.disabledInfoVO) {
              //残疾军人
              that.disabledInfoFn(res.data.disabledInfoVO);
            }
            if (res.data.disabledWorkersInfoVO) {
              //伤残民兵民工
              that.disabledWorkersInfoFn(res.data.disabledWorkersInfoVO);
            }
            if (res.data.martyrInfoVO) {
              //烈士遗属
              that.martyrInfoFn(res.data.martyrInfoVO);
            }
            if (res.data.diedOnDutyInfoVO) {
              //因公牺牲军人遗属
              that.diedOnDutyInfoFn(res.data.diedOnDutyInfoVO);
            }
            if (res.data.illnessInfoVO) {
              //病故军人遗属
              that.illnessInfoFn(res.data.illnessInfoVO);
            }
            if (res.data.activeInfoVO) {
              //现役军人家属
              that.activeInfoFn(res.data.activeInfoVO);
            }
          }
        } else {
          Toast(res.msg)
        }

      }, function(req) {}) //  请求失败
    },
    baseInfoFnUpdate(data) {
      let baseInfoVO = data;
      console.log("data",data)
      baseInfoVO.sex = data.xb == 1 ? "男" : data.xb == 2 ? "女" : "-"; // 性别
      baseInfoVO.visionId = data.sfzhm; // 身份证号
      baseInfoVO.name = data.name; // 姓名
      baseInfoVO.zzmm = data.zzmm; // 政治面貌
      baseInfoVO.birth = data.csrq; // 出生日期
      baseInfoVO.tel = data.sjhm;  // 联系方式
      baseInfoVO.houseState = data.zfzk; // 住房状况
      baseInfoVO.household = data.hjlb;  // 户籍类别
      baseInfoVO.health = data.xm;  // 健康状况
      baseInfoVO.address = data.jtzzGx; // 居住地址
      baseInfoVO.marState = data.hyzk; // 婚姻状态
      baseInfoVO.houseArea = data.mj; // 房屋面积
      // baseInfoVO.roomNum = data.xm; // 自建房数量
      baseInfoVO.empStatus = data.xjyzt; // 就业情况
      baseInfoVO.incomeStatus = data.grnsr; // 个人年收入
      baseInfoVO.workUnit = data.xgzdw; // 工作单位
      baseInfoVO.empdemand = data.xjyzt; // 就业需求
      // baseInfoVO.entintention = data.xm; // 创业需求
      // baseInfoVO.gloryCard = data.xm; // 是否申请悬挂光荣牌
      // baseInfoVO.gloryAppTime = data.xm; // 光荣牌申请时间
      baseInfoVO.gloryUseTime = data.ffsj; // 光荣牌悬挂时间
      baseInfoVO.alold = data.glqk; // 是否孤老
      baseInfoVO.otherCard = data.sfga; // 是否港澳
      // baseInfoVO.agent = data.xm; // 是否代办
      baseInfoVO.homeAddrTitle = data.jtzz; // 家庭住址
      baseInfoVO.domicile = data.hjd; // 户籍地
      baseInfoVO.issuedOrg = data.qfjg; // 签发机关
      baseInfoVO.medInsurance = data.yldbx; // 医疗保险
      baseInfoVO.endInsurance = data.ylbx; // 养老保险
      baseInfoVO.demandDiff = data.demandDiff; // 主要困难
      baseInfoVO.demandType = data.demandType; // 主要诉求
      baseInfoVO.hasPenGrant = data.gjfxbzj; // 享受国家抚恤补助金情况
      baseInfoVO.hasDisGrant = data.cjrlxbt; // 享受残疾人两项补贴
      baseInfoVO.personnelType = data.rylb; // 人员类别
      baseInfoVO.helpStatus = data.shjzzk; // 社会救助

      let houseArea = [];
      if (baseInfoVO.mj && baseInfoVO.mj.length >= 1) { // 房屋面积处理
        houseArea = data.mj.split(",");
        houseArea = houseArea.filter(function(s) {
          let str = s && s.trim();
          return str;
        });
        if (houseArea.length >= 1) {
          houseArea.forEach(item => {
            item = item + "平";
            baseInfoVO.houseArea = item + ",";
          });
          baseInfoVO.houseArea = baseInfoVO.houseArea.slice(0, baseInfoVO.houseArea.length - 1);
        } else {
          baseInfoVO.houseArea = "-";
        }
      };

      baseInfoVO.medInsurance = callData.makeSelectOrChecked(
        data.medInsurance,
        callData.dataDictionary().medInsuranceMap
      ); //医疗保险：
      baseInfoVO.endInsurance = callData.makeSelectOrChecked(
        data.endInsurance,
        callData.dataDictionary().endInsuranceMap
      ); //养老保险：

      this.setData({
        baseInfoVO:baseInfoVO
      })
       
    },
    // 基础信息
    baseInfoFn(data) {
      let baseInfoVO = data;
      baseInfoVO.sex = data.sex == 1 ? "男" : data.sex == 2 ? "女" : "-"; // 性别
      baseInfoVO.otherCard =
        data.otherCard == 1 ? "是" : data.otherCard == 0 ? "否" : "-"; // 是否港澳
      baseInfoVO.gloryCard =
        data.gloryCard == 1 ? "是" : data.gloryCard == 0 ? "否" : "-"; // 是否申请悬挂光荣牌
      baseInfoVO.agent =
        data.agent == 1 ? "是" : data.agent == 0 ? "否" : "-"; // 是否代办
      baseInfoVO.hasDisGrant =
        data.hasDisGrant == 1 ? "是" : data.hasDisGrant == 0 ? "否" : "-"; // 享受残疾人两项补贴
      baseInfoVO.hasPenGrant =
        data.hasPenGrant == 1 ? "是" : data.hasPenGrant == 0 ? "否" : "-"; // 享受国家抚恤补助金情况
      baseInfoVO.narDisabled =
        data.narDisabled == 1 ? "是" : data.narDisabled == 0 ? "否" : "-"; // 是否伤残
      baseInfoVO.orph =
        data.orph == 1 ? "是" : data.orph == 0 ? "否" : "-"; // 孤儿情况：
      baseInfoVO.alold =
        data.alold == 1 ? "是" : data.alold == 0 ? "否" : "-"; // 孤老

      baseInfoVO.zzmm = callData.makeSelectOrCheckedDetailInfo(
        data.zzmm,
        callData.dataDictionary().politicalStatus
      ); //政治面貌
      baseInfoVO.nation = callData.makeSelectOrCheckedDetailInfo(
        data.nation,
        callData.dataDictionary().nationMap
      ); //民族
      baseInfoVO.household = callData.makeSelectOrCheckedDetailInfo(
        data.household,
        callData.dataDictionary().registrationMap
      ); //户籍类别
      baseInfoVO.health = callData.makeSelectOrCheckedDetailInfo(
        data.health,
        callData.dataDictionary().healthStatus
      ); //健康状况
      baseInfoVO.marState = callData.makeSelectOrCheckedDetailInfo(
        data.marState,
        callData.dataDictionary().marriageStatus
      ); //婚姻状况
      baseInfoVO.education = callData.makeSelectOrCheckedDetailInfo(
        data.education,
        callData.dataDictionary().cultureMap
      ); //文化程度
      baseInfoVO.medInsurance = callData.makeSelectOrCheckedDetailInfo(
        data.medInsurance,
        callData.dataDictionary().medInsuranceMap
      ); //医疗保险：
      baseInfoVO.endInsurance = callData.makeSelectOrCheckedDetailInfo(
        data.endInsurance,
        callData.dataDictionary().endInsuranceMap
      ); //养老保险：
      baseInfoVO.incomeStatus = callData.makeSelectOrCheckedDetailInfo(
        data.incomeStatus,
        callData.dataDictionary().incomeStatus
      ); //年收入

      baseInfoVO.demandDiff = callData.makeSelectOrCheckedDetailInfo(
        data.demandDiff,
        callData.dataDictionary().demandDiffMap
      ); //主要困难
      baseInfoVO.demandType = callData.makeSelectOrCheckedDetailInfo(
        data.demandType,
        callData.dataDictionary().demandTypeMap
      ); //主要诉求
      baseInfoVO.empStatus = callData.makeSelectOrCheckedDetailInfo(
        data.empStatus,
        callData.dataDictionary().empStatus
      ); //就业情况

      baseInfoVO.helpStatus = this.makeString(
        data.helpStatus,
        callData.dataDictionary().socialRescue
      ); //社会救助
      let houseArea = [];
      if (baseInfoVO.houseArea && baseInfoVO.houseArea.length >= 1) {
        houseArea = data.houseArea.split(",");
        houseArea = houseArea.filter(function(s) {
          let str = s && s.trim();
          return str;
        });
        if (houseArea.length >= 1) {
          houseArea.forEach(item => {
            item = item + "平";
            baseInfoVO.houseArea = item + ",";
          });
          baseInfoVO.houseArea = baseInfoVO.houseArea.slice(0, baseInfoVO.houseArea.length - 1);
        } else {
          baseInfoVO.houseArea = "-";
        }
      }

      let houseStateArr = [];
      if (data.houseState && data.houseState.length >= 1) {
        houseStateArr = data.houseState.split(",");
        houseStateArr = houseStateArr.filter(function(s) {
          return s && s.trim();
        });
        let houseState = houseStateArr.join(',');
        baseInfoVO.houseState = this.makeString(
          houseState,
          callData.dataDictionary().houseStatus
        ); //房屋状况：
      }







      let personnelType = [];
      personnelType[0] = callData.makeSelectOrCheckedDetailInfo(
        data.f1,
        callData.dataDictionary().perCategory
      ); //人员类别
      personnelType[1] = callData.makeSelectOrCheckedDetailInfo(
        data.f2,
        callData.dataDictionary().perCategory
      ); //人员类别
      personnelType[2] = callData.makeSelectOrCheckedDetailInfo(
        data.f3,
        callData.dataDictionary().perCategory
      ); //人员类别
      personnelType[3] = callData.makeSelectOrCheckedDetailInfo(
        data.f4,
        callData.dataDictionary().perCategory
      ); //人员类别
      personnelType[4] = callData.makeSelectOrCheckedDetailInfo(
        data.f5,
        callData.dataDictionary().perCategory
      ); //人员类别
      personnelType[5] = callData.makeSelectOrCheckedDetailInfo(
        data.f6,
        callData.dataDictionary().perCategory
      ); //人员类别
      personnelType = personnelType.filter(function(s) {
        return s && s.trim();
      });
      baseInfoVO.personnelType = personnelType.join(",");

      this.setData({
        baseInfoVO: baseInfoVO
      })
    },
    //军队转业干部
    cadresInfoFn(data) {
      let cadresInfoVO = data;
      if (data.armyYears) {
        cadresInfoVO.armyYears = cadresInfoVO.armyYears + "年";
      }

      cadresInfoVO.resettleUnitNature = callData.makeSelectOrChecked(
        data.resettleUnitNature,
        callData.dataDictionary().resettleUnitNatureMap
      ); //安置单位性质：

      cadresInfoVO.armyPost = callData.makeSelectOrChecked(
        data.armyPost,
        callData.dataDictionary().armyPostMap
      ); //原职级：

      cadresInfoVO.armyAward = this.makeString(
        data.armyAward,
        callData.dataDictionary().armyAwardMap
      ); //立功受奖

      cadresInfoVO.resettleMode = callData.makeSelectOrChecked(
        data.resettleMode,
        callData.dataDictionary().resettleMode2
      ); //退役安置方式


      this.setData({
        flag1: true,
        cadresInfoVO: cadresInfoVO
      })
    },
    //退役士兵
    soldierInfoFn(data) {
      let soldierInfoVO = data;
      if (data.armyYears) {
        soldierInfoVO.armyYears = soldierInfoVO.armyYears + "年";
      }
      soldierInfoVO.joinEduTrain =
        data.joinEduTrain == 1 ? "是" : data.joinEduTrain == 0 ? "否" : "-"; // 参加政府组织的教育培训状况
      soldierInfoVO.inArmyHhtype = callData.makeSelectOrChecked(
        data.inArmyHhtype,
        callData.dataDictionary().registrationMap
      ); //入伍时户籍性质：
      soldierInfoVO.armyAward = this.makeString(
        data.armyAward,
        callData.dataDictionary().armyAwardMap
      ); //立功受奖
      soldierInfoVO.armyRank = callData.makeSelectOrChecked(
        data.armyRank,
        callData.dataDictionary().armyRank
      ); //原衔级：
      soldierInfoVO.resettleMode = callData.makeSelectOrChecked(
        data.resettleMode,
        callData.dataDictionary().resettleMode2
      ); //退役安置方式
      soldierInfoVO.resettleUnitNature = callData.makeSelectOrChecked(
        data.resettleUnitNature,
        callData.dataDictionary().resettleUnitNatureMap
      ); //安置单位性质：
      this.setData({
        flag2: true,
        soldierInfoVO: soldierInfoVO
      })
    },
    //军队离退休干部和退休士官
    retiredInfoFn(data) {
      let retiredInfoVO = data;
      retiredInfoVO.arpType = callData.makeSelectOrChecked(
        data.arpType,
        callData.dataDictionary().arpType
      ); //军休类别：
      retiredInfoVO.resettleUnitNature = callData.makeSelectOrChecked(
        data.resettleUnitNature,
        callData.dataDictionary().resettleUnitNatureMap
      ); //安置单位性质：
      retiredInfoVO.resettleMode = callData.makeSelectOrChecked(
        data.resettleMode,
        callData.dataDictionary().resettleMode2
      ); //退役安置方式
      this.setData({
        flag3: true,
        retiredInfoVO: retiredInfoVO
      })
    },
    //军队无军籍离退休职工
    noMilitaryInfoFn(data) {
      let noMilitaryInfoVO = data;
      noMilitaryInfoVO.buyHrhSubject =
        data.buyHrhSubject == 1 ?
        "本人" :
        data.buyHrhSubject == 2 ?
        "配偶" :
        "-"; // 购房主体：
      noMilitaryInfoVO.armyPost = callData.makeSelectOrChecked(
        data.armyPost,
        callData.dataDictionary().armyPostMap
      ); //原职级：
      noMilitaryInfoVO.armyAward = this.makeString(
        data.armyAward,
        callData.dataDictionary().armyAwardMap
      ); //立功受奖
      noMilitaryInfoVO.resettleUnitNature = callData.makeSelectOrChecked(
        data.resettleUnitNature,
        callData.dataDictionary().resettleUnitNatureMap
      ); //安置单位性质：
      noMilitaryInfoVO.armyWorkerWay = callData.makeSelectOrChecked(
        data.armyWorkerWay,
        callData.dataDictionary().armyWorkerWay
      ); //成为军队职工方式
      noMilitaryInfoVO.resettlePlanOrder = callData.makeSelectOrChecked(
        data.resettlePlanOrder,
        callData.dataDictionary().resettlePlanOrder
      ); //安置计划批次
      noMilitaryInfoVO.buyHrhStatus = callData.makeSelectOrChecked(
        data.buyHrhStatus,
        callData.dataDictionary().buyHrhStatusMap
      ); //家庭购买房改住房情况
      noMilitaryInfoVO.buyHrhNature = callData.makeSelectOrChecked(
        data.buyHrhNature,
        callData.dataDictionary().buyHrhNature
      ); //所购房改住房性质
      this.setData({
        flag4: true,
        noMilitaryInfoVO: noMilitaryInfoVO
      })
    },
    //退伍红军老战士
    redArmyInfoFn(data) {
      let redArmyInfoVO = data;
      redArmyInfoVO.redarmyType = callData.makeSelectOrChecked(
        data.redarmyType,
        callData.dataDictionary().redarmyTypeMap
      ); //原衔级：
      redArmyInfoVO.supStatus = callData.makeSelectOrChecked(
        data.supStatus,
        callData.dataDictionary().supStatusMap
      ); //供养情况
      redArmyInfoVO.supUnit = callData.makeSelectOrChecked(
        data.supUnit,
        callData.dataDictionary().supUnitMap
      ); //供养单位
      redArmyInfoVO.treatStatus = callData.makeSelectOrChecked(
        data.treatStatus,
        callData.dataDictionary().treatStatusMap
      ); //待遇情况：
      this.setData({
        flag5: true,
        redArmyInfoVO: redArmyInfoVO
      })
    },
    //复员军人
    demobilizationInfoFn(data) {
      let demobilizationInfoVO = data;
      demobilizationInfoVO.armyPost = callData.makeSelectOrChecked(
        data.armyPost,
        callData.dataDictionary().armyPostMap
      ); //原职级：
      demobilizationInfoVO.armyAward = this.makeString(
        data.armyAward,
        callData.dataDictionary().armyAwardMap
      ); //立功受奖
      demobilizationInfoVO.supStatus = callData.makeSelectOrChecked(
        data.supStatus,
        callData.dataDictionary().supStatusMap
      ); //供养情况
      demobilizationInfoVO.supUnit = callData.makeSelectOrChecked(
        data.supUnit,
        callData.dataDictionary().supUnitMap
      ); //供养单位
      demobilizationInfoVO.treatStatus = callData.makeSelectOrChecked(
        data.treatStatus,
        callData.dataDictionary().treatStatusMap
      ); //待遇情况：
      this.setData({
        flag6: true,
        demobilizationInfoVO: demobilizationInfoVO
      })
    },
    //残疾军人
    disabledInfoFn(data) {
      let disabledInfoVO = data;
      disabledInfoVO.mill =
        data.mill == 1 ? "是" : data.mill == 0 ? "否" : "-"; // 是否精神病评残：
      disabledInfoVO.supStatus = callData.makeSelectOrChecked(
        data.supStatus,
        callData.dataDictionary().supStatusMap
      ); //供养情况
      disabledInfoVO.supUnit = callData.makeSelectOrChecked(
        data.supUnit,
        callData.dataDictionary().supUnitMap
      ); //供养单位

      disabledInfoVO.disgrd = callData.makeSelectOrChecked(
        data.disgrd,
        callData.dataDictionary().disgrd
      ); //伤残等级
      disabledInfoVO.diskind = callData.makeSelectOrChecked(
        data.diskind,
        callData.dataDictionary().diskindMap
      ); //伤残性质：
      this.setData({
        flag7: true,
        disabledInfoVO: disabledInfoVO
      })
    },
    //伤残民兵民工
    disabledWorkersInfoFn(data) {
      let disabledWorkersInfoVO = data;

      disabledWorkersInfoVO.supStatus = callData.makeSelectOrChecked(
        data.supStatus,
        callData.dataDictionary().supStatusMap
      ); //供养情况
      disabledWorkersInfoVO.supUnit = callData.makeSelectOrChecked(
        data.supUnit,
        callData.dataDictionary().supUnitMap
      ); //供养单位

      disabledWorkersInfoVO.disgrd = callData.makeSelectOrChecked(
        data.disgrd,
        callData.dataDictionary().disgrd
      ); //伤残等级
      disabledWorkersInfoVO.diskind = callData.makeSelectOrChecked(
        data.diskind,
        callData.dataDictionary().diskindMap
      ); //伤残性质：
      this.setData({
        flag8: true,
        disabledWorkersInfoVO: disabledWorkersInfoVO
      })
    },
    //烈士遗属
    martyrInfoFn(data) {
      let martyrInfoVO = data;
      martyrInfoVO.marSex =
        data.marSex == 1 ? "男" : data.marSex == 2 ? "女" : "-"; // 烈士性别
      martyrInfoVO.marIsTakecard =
        data.marIsTakecard == 1 ? "是" : data.marIsTakecard == 0 ? "否" : "-"; // 是否是持证人：

      martyrInfoVO.marBuryPlace = callData.makeSelectOrChecked(
        data.marBuryPlace,
        callData.dataDictionary().marBuryPlaceMap
      ); //烈士安葬地：
      martyrInfoVO.marRelation = callData.makeSelectOrChecked(
        data.marRelation,
        callData.dataDictionary().marRelationMap
      ); //与烈士关系：
      martyrInfoVO.marTreatStatus = callData.makeSelectOrChecked(
        data.marTreatStatus,
        callData.dataDictionary().marTreatStatusMap
      ); //优抚待遇情况：
      this.setData({
        flag9: true,
        martyrInfoVO: martyrInfoVO
      })
    },
    //因公牺牲军人遗属
    diedOnDutyInfoFn(data) {
      let diedOnDutyInfoVO = data;

      diedOnDutyInfoVO.ddaSex =
        data.ddaSex == 1 ? "男" : data.ddaSex == 2 ? "女" : "-"; // 因公牺牲军人性别
      diedOnDutyInfoVO.ddaIsTakecard =
        data.ddaIsTakecard == 1 ? "是" : data.ddaIsTakecard == 0 ? "否" : "-"; // 是否是持证人：

      diedOnDutyInfoVO.ddaTreatStatus = callData.makeSelectOrChecked(
        data.ddaTreatStatus,
        callData.dataDictionary().marTreatStatusMap
      ); //优抚待遇情况：

      diedOnDutyInfoVO.ddaRelation = callData.makeSelectOrChecked(
        data.ddaRelation,
        callData.dataDictionary().marRelationMap
      ); //与因公牺牲军人关系
      this.setData({
        flag10: true,
        diedOnDutyInfoVO: diedOnDutyInfoVO
      })
    },
    //病故军人遗属
    illnessInfoFn(data) {
      let illnessInfoVO = data;

      illnessInfoVO.diaSex =
        data.diaSex == 1 ? "男" : data.diaSex == 2 ? "女" : "-"; // 病故军人性别
      illnessInfoVO.diaIsTakecard =
        data.diaIsTakecard == 1 ? "是" : data.diaIsTakecard == 0 ? "否" : "-"; // 是否是持证人：

      illnessInfoVO.diaRelation = callData.makeSelectOrChecked(
        data.diaRelation,
        callData.dataDictionary().marRelationMap
      ); //牺牲军人关系
      illnessInfoVO.diaTreatStatus = callData.makeSelectOrChecked(
        data.diaTreatStatus,
        callData.dataDictionary().marTreatStatusMap
      ); //优抚待遇情况：
      this.setData({
        flag11: true,
        illnessInfoVO: illnessInfoVO
      })
    },
    //现役军人家属
    activeInfoFn(data) {
      let activeInfoVO = data;
      activeInfoVO.aspSex =
        data.aspSex == 1 ? "男" : data.aspSex == 2 ? "女" : "-"; // 现役军人性别
      activeInfoVO.aspFollow =
        data.aspFollow == 1 ? "是" : data.aspFollow == 0 ? "否" : "-"; // 是否随军：

      activeInfoVO.aspRelation = callData.makeSelectOrChecked(
        data.aspRelation,
        callData.dataDictionary().marRelationMap
      ); //与现役军人关系：
      activeInfoVO.aspRank = callData.makeSelectOrChecked(
        data.aspRank,
        callData.dataDictionary().aspRankMap
      ); //现役军人职级：
      this.setData({
        flag12: true,
        activeInfoVO: activeInfoVO
      })
    },










    makeString(key, objArr) { //   checked    选中多个  ,分隔处理   对应字典表数据
      let str = "";
      if (!key) {
        return str;
      }
      let keyArr = key.split(",");
      keyArr.forEach(function(item) {
        let arr = objArr.filter(function(m, i) {
          return item === m.value;
        });
        str += (arr.length > 0 ? arr[0].title : "") + ",";
      });
      str = str.slice(0, str.length - 1);
      return str;
    }

  }
})