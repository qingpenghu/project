// components/visitInfo/index.js
const call = require("../../utils/request.js");
const callData = require("../../utils/util.js");
let app = getApp();
import Toast from '../../vant-weapp/toast/toast';

Component({
  /**
   * 组件的属性列表
   */
  properties: {
    detailsId: {
      type: String,
      value: ''
    },
    detailCard: {
      type: String,
      value: ''
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    visitInfoArr: [],
    hasMore: true,
    fileGuid: '',
    params: {
      veteransId: '',
      pageable: {
        rows: 10,
        page: 1
      }
    }

  },

  /**
   * 组件挂载后执行 ready
   */
  ready: function() {
    let that = this;
    let paramVeteranid = 'params.veteransId'
    this.setData({
      // [paramVeteranid]: 'ea7db54e1d56469f9b81950682aceerr'
      [paramVeteranid]: that.data.detailsId.trim() || ''
    });
    this.getData();
  },
  /**
   * 组件的方法列表
   */
  methods: {
    getData() {
      let that = this;
      if (!that.data.hasMore) {
        return
      }
      call.postData('/interview/veteran/reports', this.data.params, function(res) { //  请求成功
        if (res.code == 200) {
          if (that.data.params.pageable.page == 1) {
            wx.hideLoading();
            if (res.data && res.data.total <= that.data.params.pageable.rows) {
              that.setData({
                hasMore: false
              })
            }
          } else {
            if (res.data && that.data.params.pageable.page >= res.data.totalPages) {
              that.data.hasMore = false;
            }
          }
          that.data.params.pageable.page++;
          that.data.visitInfoArr = that.data.visitInfoArr.concat(res.data.content || []);
          that.setData({
            visitInfoArr: that.data.visitInfoArr,
            hasMore: that.data.hasMore
          })
        } else {
          Toast(res.msg)
        }

      }, function(req) {}) //  请求失败
    },
    showLoadingMore: function() {
      this.setData({
        hasMore: this.data.hasMore
      })
    },
    hideLoadingMore: function() {
      this.setData({
        hasMore: this.data.hasMore
      })
    },
    onContactButton: function() {
      // 触底时父页面调用
      var that = this;
      // 显示加载图标
      this.showLoadingMore();
      this.getData();
    },
    checkDetails(e) {
      wx.navigateTo({ //  跳转走访计划活动
        url: '/pages/visitActive/index?reportId= ' + e.currentTarget.dataset.id + '&fileGuid=' + this.data.params.veteransId + '&cardId=' + e.currentTarget.dataset.cardid
      })
    }

  }
})